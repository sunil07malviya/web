﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data;

namespace ISPL.CSC.Web.General
{
    public partial class TabDetails : BasePage
    {
        private const string STATUS_KEY = "STATUS_KEY";

        private const string MSLNO_KEY = "MSLNO_KEY";
        private const string TAB_KEY = "TAB_KEY";
        private const string PAGE_KEY = "PAGE_KEY";
        private const string HEADER_KEY = "HEADER_KEY";
        private const string PAGE_INDEX = "PAGE_INDEX";

        protected void Page_Load(object sender, EventArgs e)
        {
            ViewState[MSLNO_KEY] = Request["MSLNO"].ToString();

            // Modified on 02-Jan-2010
            pLoadTabs();
            if (!IsPostBack)
            {
                pBindTransactionDetails();
                pBindGrid(null, null);
            }
            else
            {
                if (gvDetails.TopPagerRow != null)
                    if (gvDetails.TopPagerRow.Visible == true)
                        pBindGrid(null, null);
            }
        }
        private void pBindTransactionDetails()
        {
            int MenuSlNo = MenuID;
            Model.Masters.LOVViewInfo myLOVViewInfo = SQLServerDAL.Masters.LOVView.GetLOVViewInfo(MenuSlNo);

            string lstrQuery = myLOVViewInfo.Query;

            lstrQuery = lstrQuery.Replace("WHERE ", "Where " + myLOVViewInfo.PrimaryKeyFieldName + " = " + ViewState[MSLNO_KEY].ToString() + " And ");
            lstrQuery = lstrQuery.Replace("@USERID", "'" + LoginUserInfo.UserID.ToString() + "'");
            lstrQuery = lstrQuery.Replace("@BRANCHID", LoginUserInfo.BranchID.ToString());

            // Modified on 02-Jan-2010
            //DataTable dt = general.GetDataTable(lstrQuery); // Old code
            DataTable dt;
            if (ViewState[HEADER_KEY] == null)
            {
                dt = SQLServerDAL.General.GetDataTable(lstrQuery);
                ViewState[HEADER_KEY] = dt;
            }
            else
                dt = (DataTable)ViewState[HEADER_KEY];

            HtmlTableCell hcDetail = new HtmlTableCell();
            HtmlTable htNew = new HtmlTable();
            htNew.CellPadding = 2;
            htNew.CellSpacing = 2;
            htNew.Attributes.Add("style", "font-family: Tahoma; color: #0066cc; font-size: 8.25pt;");

            HtmlTableRow hrDetail = new HtmlTableRow();

            hrDetail.Attributes.Add("style", "text-align: center; ");

            int Count = (dt.Columns.Count > 4 ? 4 : dt.Columns.Count - 1);

            for (int i = 0; i < Count; i++)
            {
                string lstrValue = dt.Rows[0][i].ToString();

                if (lstrValue.Length > 0)
                {
                    hcDetail.Controls.Add(new LiteralControl(dt.Columns[i].ColumnName + ":&nbsp;"));

                    if (dt.Columns[i].DataType.ToString() == "System.DateTime" && lstrValue != "")
                        hcDetail.Controls.Add(new LiteralControl(Convert.ToDateTime(lstrValue).ToString("dd-MMM-yyyy")));
                    else
                        hcDetail.Controls.Add(new LiteralControl(lstrValue));

                    hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));

                    hrDetail.Cells.Add(hcDetail);
                }
            }
            DataTable dt1;
            switch (MenuSlNo)
            {
                case 50024: //Supplier PO
                    lstrQuery = "SELECT SUM(TD_PO_QTY)as [Tot Qty],SUM(TD_PO_AMOUNT) as [Tot Value] from TD_EOU_PO INNER JOIN TM_EOU_PO on TM_PO_SLNO=TD_PO_MSLNO WHERE TM_PO_SLNO =  " + ViewState[MSLNO_KEY].ToString() + "GROUP BY TM_PO_SLNO";
                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);
                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                    }
                    break;
                case 50209: // Wastage Managaement
                    lstrQuery = "SELECT SUM(TD_WASTAGE_QTY) as [Tot Qty] FROM TM_EOU_WASTAGE INNER JOIN TD_EOU_WASTAGE ON TM_WASTAGE_SLNo=TD_WASTAGE_TMSLNO WHERE TM_WASTAGE_SLNO = " + ViewState[MSLNO_KEY].ToString() + " GROUP BY TM_WASTAGE_SLNO";
                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);
                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                    }
                    break;

                case 50056: //Scrap Invoice
                    lstrQuery = "SELECT SUM(Td_SCRAPINV_Qty) as [Tot Qty] FROM TM_SCRAPINV INNER JOIN TD_SCRAPINV ON TM_SCRAPINV_SLNO=TD_SCRAPINV_TMSLNO WHERE TM_SCRAPINV_SLNO=" + ViewState[MSLNO_KEY].ToString() + " GROUP BY TM_SCRAPINV_SLNO";
                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);
                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                    }
                    break;
                case 50034: // Import/Local STP Approval
                    lstrQuery = "select sum(TD2_APPLN_Qty) as [Tot Qty], sum(TD2_APPLN_AssblValue) as [Tot Assbl.Val], sum(TD2_APPLN_DutyAmt)as [Tot Duty] from TD2_EOU_APPLN "
                    + " inner join TD1_EOU_APPLN on TD2_APPLN_InvSlNo = TD1_APPLN_SlNo "
                    + " inner join TM_EOU_APPLN on TD1_APPLN_MSlNo = Tm_Appln_SlNo where Tm_Appln_SlNo = " + ViewState[MSLNO_KEY].ToString() + "group by Tm_Appln_SlNo";

                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);

                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;" + dt1.Rows[0][2].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    break;

                case 50044: // Local Goods Receipt
                    lstrQuery = "select sum(TD2_AB_QtyRecd) as [Tot Qty], sum(TD2_AB_IVal) as [Tot Assbl.Val], sum(TD2_AB_DtAmt)as [Tot Duty] from td2_eou_are3 "
                    + " inner join td1_eou_are3 on td1_ab_invcd = td2_ab_invcd "
                    + " inner join tm_eou_are3 on tm_ab_cd = td1_ab_cd where tm_ab_cd = " + ViewState[MSLNO_KEY].ToString() + "group by tm_ab_cd";

                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);
                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;" + dt1.Rows[0][2].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    break;

                case 50043: // Imported Goods Receipt (BE)
                    lstrQuery = "select sum(TD2_AB_QtyRecd) as [Tot Qty], sum(TD2_AB_AsblVal) as [Tot Assbl.Val], sum(TD2_AB_DtAmt)as [Tot Duty] from td2_eou_be "
                    + " inner join td1_eou_be on td1_ab_invcd = td2_ab_invcd "
                    + " inner join tm_eou_be on tm_ab_cd = td1_ab_cd where tm_ab_cd = " + ViewState[MSLNO_KEY].ToString() + "group by tm_ab_cd";

                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);

                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;" + dt1.Rows[0][2].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    break;

                case 50035: // Procurement Certificate
                    lstrQuery = "select sum(TD2_PROC_QtyRecd) as [Tot Qty], sum(TD2_PROC_AsblVal) as [Tot Assbl.Val], sum(TD2_PROC_DtAmt)as [Tot Duty] from TD2_EOU_PROC "
                    + " inner join TD1_EOU_PROC on td2_proc_invcd = td1_proc_invcd "
                    + " inner join TM_EOU_PROC on td1_proc_cd = tm_proc_slno where tm_proc_slno = " + ViewState[MSLNO_KEY].ToString() + "group by tm_proc_slno";

                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);

                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;" + dt1.Rows[0][2].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    break;

                case 50037: // CT3 Certificate
                    lstrQuery = "select sum(Td_Ct3_Qty) as [Tot Qty], sum(Td_Ct3_Value) as [Tot Val], sum(Td_Ct3_DutyAmt)as [Tot Duty] from TD_EOU_CT3 "
                    + " inner join TM_EOU_CT3 on td_ct3_cd = tm_ct3_cd where tm_ct3_cd = " + ViewState[MSLNO_KEY].ToString() + "group by tm_ct3_cd";

                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);

                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;" + dt1.Rows[0][2].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    break;

                case 50061: // Debonding
                    lstrQuery = "select sum(TD_DB_Qty) as [Tot Qty], sum(TD_DB_AsblVal) as [Tot Assbl.Val], sum(TD_DB_DtAmt)as [Tot Duty] from TD_EOU_DB "
                    + " inner join TM_EOU_DB on td_db_cd = tm_db_cd where tm_db_cd = " + ViewState[MSLNO_KEY].ToString() + "group by tm_db_cd";

                    dt1 = SQLServerDAL.General.GetDataTable(lstrQuery);

                    if (dt1.Rows.Count != 0)
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;" + dt1.Rows[0][0].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;" + dt1.Rows[0][1].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;" + dt1.Rows[0][2].ToString()));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    else
                    {
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[0].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[1].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl(dt1.Columns[2].ColumnName + ":&nbsp;"));
                        hcDetail.Controls.Add(new LiteralControl("&nbsp;|&nbsp;"));
                    }
                    break;
            }

            htNew.Rows.Add(hrDetail);
            lblTranDetails.Controls.Add(htNew);
        }
        private void pLoadTabs()
        {
            DataTable myTable = SQLServerDAL.GridView.GetGridQueryByMenuID(Convert.ToInt32(MenuID));

            if (Request["TAB"] != null && ViewState[TAB_KEY] == null)
                ViewState[TAB_KEY] = Request["TAB"].ToString();
            if (Request["MSLNO_KEY"] != null && ViewState[MSLNO_KEY] == null)
                ViewState[MSLNO_KEY] = Request["MSLNO_KEY"].ToString();

            if (myTable.Rows.Count > 0)
            {
                string lstrLIStart = "<li id='{0}' class='{1}'>";
                string lstrLIEnd = "</li>";

                headertab.Controls.Clear();
                headertab.Controls.Add(new LiteralControl("<ul id='list'>"));
                for (int i = 0; i < myTable.Rows.Count; i++)
                {
                    if (i == 0 && ViewState[TAB_KEY] == null)
                        ViewState[TAB_KEY] = myTable.Rows[i][3].ToString();

                    if (ViewState[TAB_KEY].Equals(myTable.Rows[i][3].ToString()))
                        headertab.Controls.Add(new LiteralControl(String.Format(lstrLIStart, "tab-" + i.ToString(), "current")));
                    else
                        headertab.Controls.Add(new LiteralControl(String.Format(lstrLIStart, "tab-" + i.ToString(), "")));

                    LinkButton lnkButton = new LinkButton();
                    lnkButton.Text = myTable.Rows[i][0].ToString();
                    lnkButton.ID = i.ToString();
                    lnkButton.CommandArgument = myTable.Rows[i][3].ToString();
                    //lnkButton.CommandName = myTable.Rows[i][1].ToString();  //Query
                    lnkButton.Command += new CommandEventHandler(lnkButton_Command);
                    lnkButton.OnClientClick = "fnToggleTabs(this.offsetParent);";

                    headertab.Controls.Add(lnkButton);
                    headertab.Controls.Add(new LiteralControl(lstrLIEnd));
                }
                headertab.Controls.Add(new LiteralControl("</ul>"));
            }
        }
        protected void lnkButton_Command(object sender, CommandEventArgs e)
        {
            ViewState[TAB_KEY] = e.CommandArgument;

            pLoadTabs();

            // Modified on 02-Jan-2010
            pBindTransactionDetails();

            if (ViewState["SortExpression"] == null)
                ViewState["SortExpression"] = string.Empty;

            pBindGrid(ViewState["SortExpression"].ToString(), GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");

            //if (gvDetails.Rows.Count > 0)
            //{
            //    ifrmDetails.Attributes["src"] = ViewState[PAGE_KEY].ToString() + gvDetails.DataKeys[0].Value + "&MenuID=" + MenuID + "&tab=" + ViewState[TAB_KEY].ToString();
            //}
        }
        private void pBindGrid(string sortExpression, string direction)
        {
            //string x = ViewState[TAB_KEY].ToString();
            Model.GridViewInfo myGridViewInfo = SQLServerDAL.GridView.GetGridQueryByID(Convert.ToInt32(ViewState[TAB_KEY].ToString()));
            ViewState[PAGE_KEY] = myGridViewInfo.Page.Trim();

            btnAdd.Visible = (myGridViewInfo.AddFlag == "Y" ? true : false);
            SearchDetails.Visible = (myGridViewInfo.AddFlag == "Y" ? true : false);

            btnAdd.Attributes.Add("onclick", "fnHideMenu(true); fnOpenPage('-1','" + ViewState[PAGE_KEY].ToString() + "0&MenuID=" + MenuID + "&Tab=" + ViewState[TAB_KEY].ToString() + "&MSLNO=" + ViewState[MSLNO_KEY].ToString() + "');");

            lblHeading.InnerText = myGridViewInfo.Caption;

            DataTable dt = SQLServerDAL.GridView.GetGridQueryByMenu(Convert.ToInt32(ViewState[TAB_KEY].ToString()), LoginUserInfo.BranchID, Convert.ToInt32(ViewState[MSLNO_KEY].ToString()), Convert.ToInt32(MenuID));

            dt.DefaultView.RowFilter = "";

            ViewState["PageCaption"] = "Total Record(s): " + dt.Rows.Count.ToString();

            if (txtSearch.Text.Length != 0)
            {
                string lstrRowFilter = string.Empty;

                if (ViewState["SortExpression"] == null)
                    ViewState["SortExpression"] = string.Empty;

                //string lstrRowFilter = string.Empty;
                if (string.IsNullOrEmpty(ViewState["SortExpression"].ToString()))
                {
                    foreach (DataColumn objDC in dt.Columns)
                    {
                        switch (objDC.DataType.ToString())
                        {
                            case "System.String":
                                if (lstrRowFilter.Length == 0)
                                    lstrRowFilter = "([" + objDC.ColumnName + "] LIKE '*" + txtSearch.Text.Trim() + "*'";
                                else
                                    lstrRowFilter += " OR [" + objDC.ColumnName + "] LIKE '*" + txtSearch.Text.Trim() + "*'";
                                break;
                            case "System.Int32":
                            case "System.Double":
                                double ltmpNumber = 0;
                                try
                                {
                                    ltmpNumber = Convert.ToDouble(txtSearch.Text);
                                }
                                catch
                                {
                                    ltmpNumber = 0;
                                }
                                if (ltmpNumber > 0)
                                {
                                    if (lstrRowFilter.Length == 0)
                                        lstrRowFilter = "([" + objDC.ColumnName + "] = " + txtSearch.Text.Trim() + "";
                                    else
                                        lstrRowFilter += " OR [" + objDC.ColumnName + "] = " + txtSearch.Text.Trim() + "";
                                }
                                break;
                        }
                    }
                }
                else
                {
                    int colIndex = -1;
                    foreach (DataControlField tmpDC in gvDetails.Columns)
                    {
                        if (tmpDC.SortExpression == ViewState["SortExpression"].ToString())
                        {
                            colIndex = gvDetails.Columns.IndexOf(tmpDC);
                            break;
                        }
                    }
                    DataColumn objDC = dt.Columns[colIndex];
                    switch (objDC.DataType.ToString())
                    {
                        case "System.String":
                            lstrRowFilter = "([" + objDC.ColumnName + "] LIKE '*" + txtSearch.Text.Trim() + "*'";
                            break;
                        case "System.Int32":
                        case "System.Double":
                            lstrRowFilter = "([" + objDC.ColumnName + "] = " + txtSearch.Text.Trim() + "";
                            break;
                    }
                }
                lstrRowFilter += lstrRowFilter.Length > 0 ? ")" : "";

                dt.DefaultView.RowFilter = lstrRowFilter;
            }
            if (dt.DefaultView.RowFilter.Length != 0)
                ViewState["PageCaption"] += "&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;Filtered: " + dt.DefaultView.Count.ToString();

            gvDetails.DataKeyNames = new string[] { dt.Columns[dt.Columns.Count - 1].ColumnName };

            gvDetails.Columns.Clear();
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                DataColumn objDC = dt.Columns[i];

                BoundField objBC = new BoundField();
                objBC.DataField = objDC.ColumnName;
                objBC.HeaderText = objDC.ColumnName;
                objBC.SortExpression = objDC.ColumnName;
                objBC.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                objBC.ItemStyle.HorizontalAlign = HorizontalAlign.Center;

                objBC.HeaderStyle.CssClass = (i == 0 ? "first" : "");
                objBC.ItemStyle.CssClass = (i == 0 ? "first" : "row");
                objBC.DataFormatString = WebComponents.FormatString.InputDataType(objDC.DataType.ToString());

                objBC.HtmlEncode = false;

                if (i == dt.Columns.Count - 1) objBC.Visible = false;

                gvDetails.Columns.Add(objBC);
            }
            //gvDetails.SelectedIndex = -1;

            if (direction == null)
            {
                direction = " ASC";
            }
            if (string.IsNullOrEmpty(sortExpression)) //&& direction == null)
            {
                sortExpression = dt.Columns[dt.Columns.Count - 1].ColumnName;
                //direction = " ASC";
            }

            if (!string.IsNullOrEmpty(sortExpression) && direction != null)
                dt.DefaultView.Sort = sortExpression + direction;

            gvDetails.AllowPaging = true;
            gvDetails.PagerSettings.Visible = false;
            gvDetails.AllowSorting = true;

            if (dt.DefaultView.Count == 0)
                gvDetails.DataSource = AddDummyData(dt.Clone());
            else
                gvDetails.DataSource = dt.DefaultView;

            if (PageDropDownList.SelectedIndex != -1)
                gvDetails.PageIndex = PageDropDownList.SelectedIndex;

            //GridViewRow pagerRow = gvDetails.TopPagerRow;
            //if (pagerRow != null)
            //{
            //    DropDownList pageList = (DropDownList)pagerRow.Cells[0].FindControl("PageDropDownList");

            //    // Set the PageIndex property to display that page selected by the user.
            //    gvDetails.PageIndex = pageList.SelectedIndex;

            //    Session["Page_Index"] = pageList.SelectedIndex;
            //    //gvDetails.PageIndex = pageList.SelectedIndex;
            //}

            if (PageDropDownList.SelectedValue != "")
            {
                int PageList = Convert.ToInt32(PageDropDownList.SelectedValue.ToString());
                Session["Page_Index"] = PageList - 1;
            }
            // To retain pageindex after a detail is added/modified
            if (Session["Page_Index"] != null)
                gvDetails.PageIndex = Convert.ToInt32(Session["Page_Index"].ToString());

            gvDetails.DataBind();
        }
        protected void gvDetails_DataBound(object sender, EventArgs e)
        {
            // Retrieve the pager row.
            //GridViewRow pagerRow = gvDetails.TopPagerRow;

            //// Retrieve the DropDownList and Label controls from the row.
            //DropDownList pageList = (DropDownList)pagerRow.Cells[0].FindControl("PageDropDownList");
            //Label pageLabel = (Label)pagerRow.Cells[0].FindControl("CurrentPageLabel");
            //Label pageCaption = (Label)pagerRow.Cells[0].FindControl("lblCaption");

            //if (pageList != null)
            //{
            //    // Create the values for the DropDownList control based on 
            //    // the  total number of pages required to display the data
            // source.
            PageDropDownList.ClearSelection();
            PageDropDownList.Items.Clear();
            for (int i = 0; i < gvDetails.PageCount; i++)
            {

                // Create a ListItem object to represent a page.
                int pageNumber = i + 1;
                ListItem item = new ListItem(pageNumber.ToString());

                // If the ListItem object matches the currently selected
                // page, flag the ListItem object as being selected. Because
                // the DropDownList control is recreated each time the pager
                // row gets created, this will persist the selected item in
                // the DropDownList control.   
                if (i == gvDetails.PageIndex)
                {
                    item.Selected = true;
                }

                // Add the ListItem object to the Items collection of the 
                // DropDownList.
                PageDropDownList.Items.Add(item);
            }

            // Calculate the current page number.
            int currentPage = gvDetails.PageIndex + 1;

            // Update the Label control with the current page information.
            CurrentPageLabel.Text = //"Page " + currentPage.ToString() +
              " of " + gvDetails.PageCount.ToString();

            lblCaption.Text = ViewState["PageCaption"].ToString();
        }
        protected void gvDetails_PreRender(object sender, System.EventArgs e)
        {
            try
            {
                if (gvDetails.PageCount == 1)
                    gvDetails.PagerSettings.Visible = true;
                else
                    gvDetails.PagerSettings.Visible = true;
            }
            catch
            {
                throw;
            }
        }
        protected void Page_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (ViewState["SortExpression"] == null)
                ViewState["SortExpression"] = string.Empty;
            if (gvDetails.PageIndex == 1) Session["P"] = 0;
            pBindGrid(ViewState["SortExpression"].ToString(), GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");
        }
        private DataTable AddDummyData(DataTable dtClone)
        {
            DataRow newRow = dtClone.NewRow();
            string Type = dtClone.Columns[0].DataType.ToString();
            if (Type == "System.String")
                newRow[0] = "No Records Found!";

            dtClone.Rows.Add(newRow);

            return dtClone;
        }
        protected void gvDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            System.Web.UI.WebControls.GridView gridView = (System.Web.UI.WebControls.GridView)sender;

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (gvDetails.DataKeys[e.Row.RowIndex].Values[0].ToString().Length > 0)
                    e.Row.Attributes.Add("onclick", "fnHideMenu(true); fnOpenPage('" + e.Row.ClientID + "', '" + ViewState[PAGE_KEY].ToString() + gvDetails.DataKeys[e.Row.RowIndex].Value + "&MenuID=" + MenuID + "&Tab=" + ViewState[TAB_KEY].ToString() + "&MSLNO=" + ViewState[MSLNO_KEY].ToString() + "');");
            }

            if (ViewState["SortExpression"] != null)
            {
                int cellIndex = -1;
                foreach (DataControlField field in gridView.Columns)
                {
                    if (field.SortExpression == ViewState["SortExpression"].ToString())
                    {
                        cellIndex = gridView.Columns.IndexOf(field);
                        break;
                    }
                }
                if (cellIndex > -1)
                {
                    if (e.Row.RowType == DataControlRowType.Header)
                    {
                        e.Row.Cells[cellIndex].CssClass +=
                            (GridViewSortDirection == SortDirection.Ascending
                            ? " sortasc" : " sortdesc");
                    }
                }
            }
        }
        protected void gvDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDetails.PageIndex = e.NewPageIndex;

            if (ViewState["SortExpression"] == null)
                ViewState["SortExpression"] = string.Empty;

            pBindGrid(ViewState["SortExpression"].ToString(), GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");
        }
        protected void gvDetails_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                string sortExpression = e.SortExpression;
                ViewState["SortExpression"] = sortExpression;

                if (GridViewSortDirection == SortDirection.Ascending)
                {
                    GridViewSortDirection = SortDirection.Descending;
                    pBindGrid(sortExpression, " DESC");
                }
                else
                {
                    GridViewSortDirection = SortDirection.Ascending;
                    pBindGrid(sortExpression, " ASC");
                }
            }
            catch
            {
                throw;
            }
        }
        private SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;
                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }
        protected void imgBacktoHeader_Click(object sender, ImageClickEventArgs e)
        {
            Model.Masters.LOVViewInfo myLOVViewInfo = SQLServerDAL.Masters.LOVView.GetLOVViewInfo(Convert.ToInt32(MenuID));

            Response.Redirect("../" + myLOVViewInfo.Page + ViewState[MSLNO_KEY].ToString() + "&MenuID=" + MenuID);
        }
        protected void imgBacktoGrid_Click(object sender, ImageClickEventArgs e)
        {
            string url = "~/DetailsView.aspx?MenuId=" + MenuID;
            Response.Redirect(url, true);
        }
        protected void btnSearch_Click(object sender, ImageClickEventArgs e)
        {
            if (ViewState["SortExpression"] == null)
                ViewState["SortExpression"] = string.Empty;

            pBindGrid(ViewState["SortExpression"].ToString(), GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");
        }
        protected void btnRefresh_Click(object sender, ImageClickEventArgs e)
        {
            txtSearch.Text = "";
            ViewState["SortExpression"] = null;
            if (ViewState["SortExpression"] == null)
                ViewState["SortExpression"] = string.Empty;

            pBindGrid(ViewState["SortExpression"].ToString(), GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");
        }
    }
}
