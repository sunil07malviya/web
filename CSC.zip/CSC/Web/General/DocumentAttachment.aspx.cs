﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISPL.CSC.Web.General
{
    public partial class DocumentAttachment : BasePage
    {
        private const string STATUS_KEY = "STATUS_KEY";
        private const string DETAIL_KEY = "DETAIL_KEY";
        private const string TRAN_TYPE_KEY = "TRAN_TYPE_KEY";
        private const string MSLNO = "MSLNO";
        private const string TAB_KEY = "tab";

        private Model.DocAttachInfo myDocAttach = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.btDocAttach.EditButtonClick += new EventHandler(btDocAttach_EditButtonClick);
            this.btDocAttach.DeleteButtonClick += new EventHandler(btDocAttach_DeleteButtonClick);
            this.btDocAttach.SubmitButtonClick += new EventHandler(btDocAttach_SubmitButtonClick);
            this.btDocAttach.CancelButtonClick += new EventHandler(btDocAttach_CancelButtonClick);

            if (!IsPostBack)
            {
                btDocAttach.SubmitOnClientClick = "javascript:return showWait('" + UploadFile.ClientID + "');";

                ViewState[TAB_KEY] = Request["tab"].ToString();
                ViewState[MSLNO] = WebComponents.CleanString.InputText(Request["MSLNO"].ToString(), 50);
                ViewState[TRAN_TYPE_KEY] = WebComponents.CleanString.InputText(Request["TranType"].ToString(), 50);
                ViewState[DETAIL_KEY] = WebComponents.CleanString.InputText(Request["ID"].ToString(), 50);

                myDocAttach = SQLServerDAL.DocAttach.GetDocAttachByID(Convert.ToInt32(ViewState[DETAIL_KEY].ToString()), false);
                if (myDocAttach == null)
                {
                    ViewState[STATUS_KEY] = "Add";
                    btDocAttach.ButtonClicked = "Add";
                    btDocAttach.MenuID = MenuID;
                    ViewState[DETAIL_KEY] = new Model.DocAttachInfo();
                    pClearControls();
                    pUnLockControls();
                    lnkClick.Visible = false;
                    UploadFile.Visible = true;
                    lblSelect.Visible = true;
                }
                else
                {
                    ViewState[STATUS_KEY] = "View";
                    btDocAttach.ButtonClicked = "View";
                    btDocAttach.MenuID = MenuID;
                    ViewState[DETAIL_KEY] = myDocAttach;
                    pLockControls();
                    pBindDetailData();
                    lnkClick.Visible = true;
                    UploadFile.Visible = false;
                    lblSelect.Visible = false;
                }
            }
        }
        private void pBindDetailData()
        {
            myDocAttach = (Model.DocAttachInfo)ViewState[DETAIL_KEY];
            //SQLServerDAL.DocAttach iaDocAttach = new SQLServerDAL.DocAttach();
            //myDocAttach = iaDocAttach.GetDocAttachByID(id, false);

            //ViewState[DETAIL_KEY] = myDocAttach;
            //myDocAttach = (Model.DocAttachInfo)ViewState[DETAIL_KEY];

            txtDescription.Text = myDocAttach.Remarks;
            //txtFileName.Text = myDocAttach.FileName;
        }
        private void pClearControls()
        {
            txtDescription.Text = "";
            txtFileName.Text = "";
            lnkClick.PostBackUrl = "";
        }
        private void pLockControls()
        {
            txtDescription.ReadOnly = true;
            txtFileName.ReadOnly = true;
        }
        private void pUnLockControls()
        {
            txtDescription.ReadOnly = false;
            txtFileName.ReadOnly = true;
        }
        private void pToggleControls(bool lblnValue)
        {
            //lblSelect.Visible = false;
            //UploadFile.Visible = false;
            //lblFileName.Visible = false;
            //txtFileName.Visible = false;
            //if (lblnValue == true)
            //{
            //    lblSelect.Visible = true;
            //    UploadFile.Visible = true;
            //}
            //else
            //{
            //    lblFileName.Visible = true;
            //    txtFileName.Visible = true;
            //}
        }
        private void pMapControls()
        {
            //myDocAttach = (Model.DocAttachInfo)ViewState[DETAIL_KEY];


            //myDocAttach.BranchID = LoginUserInfo.BranchID;
            //myDocAttach.TranMSlNo = Convert.ToInt32(ViewState[MSLNO].ToString());
            //myDocAttach.TranType = ViewState[TRAN_TYPE_KEY].ToString();

            //myDocAttach.Remarks = WebComponents.CleanString.InputText(txtDescription.Text, txtDescription.MaxLength);

            //if (ViewState[STATUS_KEY].ToString() == "Add" && UploadFile.PostedFile.FileName.Length >= 0)
            //{
            //    int len = UploadFile.PostedFile.ContentLength;
            //    myDocAttach.FileName = FileName(UploadFile.PostedFile.FileName);
            //    myDocAttach.ContentType = UploadFile.PostedFile.ContentType;
            //    myDocAttach.SizeinKB = UploadFile.PostedFile.ContentLength;

            //    byte[] file = new byte[len];
            //    UploadFile.PostedFile.InputStream.Read(file, 0, len);
            //    myDocAttach.File = file;
            //}

            //ViewState[DETAIL_KEY] = myDocAttach;
        }
        private string FileName(string FileNameWithPath)
        {
            string fileName;
            int indx = FileNameWithPath.LastIndexOf(@"\") + 1;
            if (indx == 1)
                fileName = FileNameWithPath;
            else
                fileName = FileNameWithPath.Substring(indx, FileNameWithPath.Length - indx);
            return fileName;
        }
        private void pSave()
        {
            try
            {
                // pMapControls();
                SQLServerDAL.DocAttach.Insert(myDocAttach);
            }
            catch
            {
                throw;
            }
        }
        private void pUpdate()
        {
            try
            {
                //  pMapControls();
                SQLServerDAL.DocAttach.Update(myDocAttach);
            }
            catch
            {
                throw;
            }
        }
        private void pDelete()
        {
            try
            {
                //  pMapControls();
                //SQLServerDAL.DocAttach.DeleteByID(myDocAttach.ID);
            }
            catch
            {
                throw;
            }
        }
        private bool fblnValidEntry()
        {
            return true;
        }
        private bool fblnValidDelete()
        {
            return true;
        }
        protected void btDocAttach_CancelButtonClick(object sender, EventArgs e)
        {
            pBacktoGrid();
            lnkClick.PostBackUrl = "";
        }
        private void pBacktoGrid()
        {
            string redirectCode = "<script>window.parent.location.href = 'TabDetails.aspx?MSLNO=" + ViewState[MSLNO].ToString() + "&tab=" + ViewState[TAB_KEY].ToString() + "&MenuID=" + MenuID + "';</script>";
            Response.Write(redirectCode);
        }

        protected void btDocAttach_SubmitButtonClick(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                string lstrStatus = ViewState[STATUS_KEY].ToString();

                pMapControls();

                if (lstrStatus.Equals("Delete"))
                {
                    if (fblnValidDelete())
                    {
                        pDelete();
                        pBacktoGrid();
                        return;
                    }
                    else
                    {
                        btDocAttach.Status = "Deletion not possible...!";
                        return;
                    }
                }

                if (fblnValidEntry())
                {
                    if (lstrStatus.Equals("New") || lstrStatus.Equals("Add"))
                        pSave();

                    if (lstrStatus.Equals("Edit") || lstrStatus.Equals("Modify"))
                        pUpdate();

                    pBacktoGrid();
                }
            }
        }
        protected void btDocAttach_DeleteButtonClick(object sender, EventArgs e)
        {
            ViewState[STATUS_KEY] = "Delete";
            pLockControls();
            lnkClick.PostBackUrl = "";
        }
        protected void btDocAttach_EditButtonClick(object sender, EventArgs e)
        {
            ViewState[STATUS_KEY] = "Modify";
            pUnLockControls();
            lnkClick.PostBackUrl = "";
        }
        protected void lnkClick_Click(object sender, EventArgs e)
        {
            myDocAttach = (Model.DocAttachInfo)ViewState[DETAIL_KEY];
            string redirectCode = "<script>window.open('ViewAttachment.aspx?FileID=" + myDocAttach.ID + "');</script>";
            Response.Write(redirectCode);
            //lnkClick.PostBackUrl = "ViewAttachment.aspx?FileID="+myDocAttach.ID;
        }
    }
}
