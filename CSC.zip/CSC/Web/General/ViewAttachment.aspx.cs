﻿using System;

namespace ISPL.CSC.Web.General
{
    public partial class ViewAttachment : System.Web.UI.Page
    {
        private Model.DocAttachInfo myDocAttach = null;
        private const string DOC_ID_KEY = "FileID";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                myDocAttach = SQLServerDAL.DocAttach.GetDocAttachByID(Convert.ToInt32(Request[DOC_ID_KEY].ToString()), true);

                if (myDocAttach == null)
                    Response.Write("File not found!");
                else
                {
                    Response.ContentType = myDocAttach.ContentType;
                    Response.OutputStream.Write((byte[])myDocAttach.File, 0, Convert.ToInt32(myDocAttach.SizeinKB.ToString()));
                    Response.AddHeader("Content-Disposition", "inline;filename=" + myDocAttach.FileName);
                }
            }
            catch
            {
                Response.Write("File not found!");
            }
        }
    }
}
