﻿using System;
using System.Web;
using System.Web.Caching;

namespace ISPL.CSC.Web
{
    public class EOSOFTErrorModule : IHttpModule
    {
        public void Init(HttpApplication app)
        {
            app.Error += new System.EventHandler(OnError);
        }

        public void OnError(object obj, EventArgs args)
        {
            if (!HttpContext.Current.Request.Url.ToString().Contains(".gif"))
            {
                //Exception exception = HttpContext.Current.Server.GetLastError().GetBaseException();

                //string errorInfo = "<br>Offending URL: " + HttpContext.Current.Request.Url.ToString() +
                //                "<br>Source: " + exception.Source +
                //                "<br>Message: " + exception.Message +
                //                "<br>Stack trace: " + exception.StackTrace;
 

                //SQLServerDAL.General general = new ISPL.CSC.SQLServerDAL.General();
                //long ErrorID = general.InsertError(null, HttpContext.Current.Request.Path, exception);

                //string ErrorPage = "~/Error.aspx?Page=" + HttpContext.Current.Request.Url.LocalPath + "&ErrorID=" + ErrorID;

                //HttpContext.Current.Response.Redirect(ErrorPage, false);
            }
            HttpContext.Current.Server.ClearError();
        }

        public void Dispose() { }
    }
}