﻿using System;
using System.Web;
using System.Web.UI.WebControls;

using ISPL.CSC.Model.Masters;

namespace ISPL.CSC.Web
{
    /// <summary>
    /// Summary description for BasePage
    /// </summary>
    public class BasePage : System.Web.UI.Page
    {
        /// <summary>
        /// Gets or sets the login user info.
        /// </summary>
        /// <value>The login user info.</value>
        public UserInfo LoginUserInfo
        {
            get
            {
                if (ViewState["USER_KEY"] != null)
                    return (Model.Masters.UserInfo)ViewState["USER_KEY"];
                else
                    return null;
            }
            set
            {
                ViewState["USER_KEY"] = value;
            }
        }
        public Model.Masters.BranchInfo LoginBranchInfo
        {
            get
            {
                return (Model.Masters.BranchInfo)Session["BRANCH_KEY"];
            }
        }
        public string BranchType
        {
            get
            {
                Model.Masters.BranchInfo myTmpBranchInfo = (Model.Masters.BranchInfo)Session["BRANCH_KEY"];
                //if (myTmpBranchInfo == null)
                    return "";
                //else
                //    return myTmpBranchInfo.EType;
            }
            set 
            { 

            }
        }
        public string DbKey
        {
            get
            {
                return HttpContext.Current.Session["DB_KEY"].ToString();
            }
            set
            {
                HttpContext.Current.Session["DB_KEY"] = value;
            }

        }

        /// <summary>
        /// Gets or sets the login branch ID.
        /// </summary>
        /// <value>The login branch ID.</value>
        protected static int LoginBranchID
        {
            get;
            set;
        }
        /// <value>The menu ID.</value>
        public int MenuID
        {
            get
            {
                if (ViewState["MENU_KEY"] != null)
                    try
                    {
                        return Convert.ToInt32(ViewState["MENU_KEY"].ToString());
                    }
                    catch
                    {
                        return 0;
                    }
                else if (Request["MenuID"] != null)
                {
                    try
                    {
                        ViewState["MENU_KEY"] = Convert.ToInt32(Request["MenuID"].ToString());

                        return Convert.ToInt32(ViewState["MENU_KEY"].ToString());
                    }
                    catch
                    {
                        ViewState["MENU_KEY"] = 0;
                        return 0;
                    }
                }
                else
                    return 0;
            }
            set
            {
                try
                {
                    ViewState["MENU_KEY"] = Convert.ToInt32(Request["MenuID"].ToString());
                }
                catch
                {
                    ViewState["MENU_KEY"] = 0;
                }
            }
        }
        public BasePage()
        {
            //this.Error += new System.EventHandler(this.Page_Error);
        }
        [System.Web.Services.WebMethodAttribute(), System.Web.Script.Services.ScriptMethodAttribute()]
        public static string[] GetList(string prefixText, int count, string contextKey)
        {
            return WebComponents.List.pGetData(prefixText, contextKey);
        }
        protected override void OnInit(EventArgs e)
        {
            string PageName = this.Page.ToString();

            if (!PageName.EndsWith("pending_aspx") &&
                !PageName.EndsWith("transactionssearch_aspx") &&
                !PageName.EndsWith("dbaudit_aspx") &&
                !PageName.EndsWith("assetdetailslookup_aspx") &&
                !PageName.EndsWith("fullfillmentreports_aspx") &&
                !PageName.EndsWith("consolidatedreport_aspx") &&
                !PageName.EndsWith("excelreport_aspx") &&
                !PageName.EndsWith("query_aspx") &&
                !PageName.EndsWith("report_aspx") &&
                !PageName.EndsWith("registers_aspx") &&
                !PageName.EndsWith("dataupload_aspx"))
            {
                Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
            }

            try
            {
                ProcessFlow.AccountController accountController = new ISPL.CSC.Web.ProcessFlow.AccountController();
                LoginUserInfo = accountController.GetUserInfo(true);
                LoginBranchID = LoginUserInfo.BranchID;

                string sScript = "<script language='javascript' src='" + this.ResolveClientUrl("~/_assets/js/General.js") + "'></script>";
                
                if (!this.Page.ClientScript.IsClientScriptBlockRegistered("GeneralJS"))
                    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "GeneralJS", sScript);

             //  if (this.MenuID != 50269 && this.MenuID != 50045 && this.MenuID != 50010 && this.MenuID != 50186 && this.MenuID != 50294 && this.MenuID != 50298 && this.MenuID != 50296)
             //      pFilterTextBoxes();

                base.OnInit(e);
                //----- Start: URL redirect to Login ----
                //if (!IsPostBack)
                //{                    
                //    if (Request.UrlReferrer == null || !Request.UrlReferrer.ToString().Contains("Login.aspx"))
                //    {
                //        if (Request.UrlReferrer == null || !Request.UrlReferrer.ToString().Contains("EOSOFT.aspx"))
                //            Response.Redirect("~/Login.aspx", true);
                //    }
                //}
                //----- End: URL redirect to Login ----
            }
            catch
            {
                throw;
            }
        }
        protected void Page_Error(Object sender, EventArgs e)
        {
            Exception objErr = Server.GetLastError().GetBaseException();

            string lstrUnique = System.Guid.NewGuid().ToString();

            Cache[lstrUnique] = objErr.Message;

            long ErrorID = SQLServerDAL.General.InsertError(LoginUserInfo, HttpContext.Current.Request.Path, objErr);

            HttpContext.Current.Server.ClearError();

            string ErrorPageName = this.ResolveClientUrl("~/Error.aspx?UNQ=" + lstrUnique + "&ErrorID=" + ErrorID + "&URL=" + Request.Url.PathAndQuery);
            Response.Redirect(ErrorPageName, true);
        }
        private void pFilterTextBoxes()
        {
            foreach (System.Web.UI.Control ctrl in this.Page.Controls)
            {
                pRecursiveFilterControls(ctrl);
            }
        }
        private void pRecursiveFilterControls(System.Web.UI.Control control)
        {
            for (int i = control.Controls.Count - 1; i >= 0; i--)
            {
                pRecursiveFilterControls(control.Controls[i]);
            }

            switch (control.GetType().ToString())
            {
                case "System.Web.UI.WebControls.TextBox":
                    TextBox tb = (TextBox)control;
                    if (tb.TextMode != TextBoxMode.Password)
                        tb.Attributes.Add("onkeypress", "return RestrictChar();");
                    break;
            }
        }
        protected virtual void pBaseLockControls()
        {
            foreach (System.Web.UI.Control ctrl in this.Page.Controls)
            {
                pRecursiveControls(ctrl, "LOCK");
            }
        }
        private void pRecursiveControls(System.Web.UI.Control control, string Flag)
        {
            for (int i = control.Controls.Count - 1; i >= 0; i--)
            {
                pRecursiveControls(control.Controls[i], Flag);
            }

            switch (control.GetType().ToString())
            {
                case "System.Web.UI.WebControls.TextBox":
                    TextBox tb = (TextBox)control;
                    switch (Flag)
                    {
                        case "LOCK":
                            tb.ReadOnly = true;
                            break;
                        case "UNLOCK":
                            tb.ReadOnly = false;
                            break;
                        case "CLEAR":
                            tb.Text = "";
                            break;
                    }
                    tb.ReadOnly = true;
                    break;
            }
        }
    }
}