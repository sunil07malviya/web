﻿using System;
using System.Collections;
using System.Collections.Generic;

using System.Web;
using System.Web.UI.WebControls;

namespace ISPL.CSC.Web.Controls
{
    [Serializable]
    public class LOVBase
    {
        private string _guid;

        public LOVBase(string PageName, string IPAddress)
        {
            this._guid = PageName + "|" + System.Guid.NewGuid().ToString() + "|" + IPAddress;
        }
        public string GUID
        {
            get
            {
                if (_guid == null)
                    return "";
                else
                    return _guid;
            }
            set
            {
                _guid = value;
            }
        }

        public string Query
        {
            get;
            set;
        }
        public string QueryCode
        {
            get;
            set;
        }
        public string Heading
        {
            get;
            set;
        }
        public string MasterMenuID
        {
            get;
            set;
        }
        public string SearchText
        {
            get;
            set;
        }
    }
}