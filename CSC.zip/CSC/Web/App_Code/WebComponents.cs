﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using ISPL.CSC.SQLServerDAL;

namespace ISPL.CSC.Web.WebComponents
{
    public sealed class CleanString
    {
        public static string InputText(string inputString, int maxLength)
        {
            StringBuilder retVal = new StringBuilder();

            if ((inputString != null) && (inputString != string.Empty))
            {
                inputString = inputString.Trim();

                if (inputString.Length > maxLength)
                    inputString.Substring(0, maxLength);

                for (int i = 0; i < inputString.Length; i++)
                {
                    switch (inputString[i])
                    {
                        //						case '"':
                        //							retVal.Append("&quot;");
                        //							break;
                        //
                        //						case '<':
                        //							retVal.Append("&lt;");
                        //							break;
                        //
                        //						case '>':
                        //							retVal.Append("&gt;");
                        //							break;

                        default:
                            retVal.Append(inputString[i]);
                            break;
                    }
                }
                retVal.Replace("'", "''");
            }
            return retVal.ToString();
        }
    }

    public sealed class FormatString
    {
        public static string InputDataType(string strDataType)
        {
            string dataType = null;
            switch (strDataType)
            {
                case "System.Int32":
                    dataType = "{0:####}";
                    break;
                case "System.Double":
                    dataType = "{0:#,###.#0}";
                    break;
                case "System.Decimal":
                    dataType = "{0:c}";
                    break;
                case "System.DateTime":
                    dataType = "{0:dd-MMM-yyyy}";
                    break;
                case "System.String":
                    dataType = "";
                    break;
                default:
                    dataType = "";
                    break;
            }
            return dataType;
        }
    }
    public sealed class Excel
    {
        public static string Populate(string lstrQuery, int llngHideColCount)
        {
            DataTable myTable = SQLServerDAL.General.GetDataTable(lstrQuery);

            if (myTable.Rows.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("<table cellspacing=\"0\" cellpadding=\"4\" rules=\"all\" bordercolor=\"#CCCCCC\" border=\"1\" style=\"color:Black;background-color:White;border-color:#CCCCCC;border-width:1px;border-style:Solid;font-family:Tahoma;font-size:10pt;height:24px;border-collapse:collapse;\">");

                sb.Append(" <tr style=\"color:White;background-color:#005500;font-weight:bold;\">");

                sb.Append(" <td align=\"Center\">");
                sb.Append(" Sl.No. ");
                sb.Append(" </td>");

                for (int llngCol = 0; llngCol < myTable.Columns.Count - llngHideColCount; llngCol++)
                {
                    sb.Append(" <td align=\"Center\">");
                    sb.Append(" " + myTable.Columns[llngCol].ColumnName + "");
                    sb.Append(" </td>");
                }

                sb.Append("</tr>");
                int i = 1;
                foreach (DataRow objDR in myTable.Rows)
                {
                    sb.Append(" <tr class=\"body\"> ");
                    sb.Append(" <td align=\"right\">");
                    sb.Append("" + i + "");
                    sb.Append(" </td> ");

                    for (int llngCol = 0; llngCol < myTable.Columns.Count - llngHideColCount; llngCol++)
                    {
                        switch (myTable.Columns[llngCol].DataType.ToString())
                        {
                            case "System.Int32":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Double":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Decimal":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.DateTime":
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + (objDR[llngCol].ToString().Length == 0 ? "" : Convert.ToDateTime(objDR[llngCol].ToString()).ToString("dd-MMM-yyyy HH:mm:ss")) + "");
                                break;
                            case "System.String":
                                sb.Append(" <td align=\"left\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            default:
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                        }
                        sb.Append(" </td>");
                    }
                    sb.Append(" </tr>");
                    i++;
                }
                sb.Append("</table>");

                return sb.ToString();
            }
            else
                return "No Records Found!";
        }

        public static string PopulateUsingDataView(DataView dv, int llngHideColCount)
        {
            if (dv.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("<table cellspacing=\"0\" cellpadding=\"4\" rules=\"all\" bordercolor=\"#CCCCCC\" border=\"1\" style=\"color:Black;background-color:White;border-color:#CCCCCC;border-width:1px;border-style:Solid;font-family:Tahoma;font-size:10pt;height:24px;border-collapse:collapse;\">");

                sb.Append(" <tr style=\"color:White;background-color:#005500;font-weight:bold;\">");

                sb.Append(" <td align=\"Center\">");
                sb.Append(" Sl.No. ");
                sb.Append(" </td>");

                for (int llngCol = 0; llngCol < dv.Table.Columns.Count - llngHideColCount; llngCol++)
                {
                    sb.Append(" <td align=\"Center\">");
                    sb.Append(" " + dv.Table.Columns[llngCol].ColumnName + "");
                    sb.Append(" </td>");
                }

                sb.Append("</tr>");
                int i = 1;
                foreach (DataRowView objDR in dv)
                {
                    sb.Append(" <tr class=\"body\"> ");
                    sb.Append(" <td align=\"right\">");
                    sb.Append("" + i + "");
                    sb.Append(" </td> ");

                    for (int llngCol = 0; llngCol < dv.Table.Columns.Count - llngHideColCount; llngCol++)
                    {
                        switch (dv.Table.Columns[llngCol].DataType.ToString())
                        {
                            case "System.Int32":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Double":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Decimal":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.DateTime":
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + (objDR[llngCol].ToString().Length == 0 ? "" : Convert.ToDateTime(objDR[llngCol].ToString()).ToString("dd-MMM-yyyy")) + "");
                                break;
                            case "System.String":
                                sb.Append(" <td align=\"left\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            default:
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                        }
                        sb.Append(" </td>");
                    }
                    sb.Append(" </tr>");
                    i++;
                }
                sb.Append("</table>");

                return sb.ToString();
            }
            else
                return "No Records Found!";
        }
    }
    public sealed class Misc
    {
        public static System.Web.UI.Control GetPostBackControl(System.Web.UI.Page page)
        {
            Control control = null;
            string ctrlname = page.Request.Params["__EVENTTARGET"];

            if (ctrlname != null && ctrlname != String.Empty)
            {
                control = page.FindControl(ctrlname);
            }
            // if __EVENTTARGET is null, the control is a button type and we need to // iterate over the form collection to find it 
            else
            {
                string ctrlStr = String.Empty;
                Control c = null;
                foreach (string ctl in page.Request.Form)
                {
                    // handle ImageButton controls ... 
                    if (ctl.EndsWith(".x") || ctl.EndsWith(".y"))
                    {
                        ctrlStr = ctl.Substring(0, ctl.Length - 2);
                        c = page.FindControl(ctrlStr);
                    }
                    else
                    {
                        c = page.FindControl(ctl);
                    }
                    if (c is System.Web.UI.WebControls.Button || c is System.Web.UI.WebControls.ImageButton)
                    {
                        control = c;
                        break;
                    }
                }
            }
            return control;
        }
        public static string GetPageCaption(int MenuID)
        {
            if (MenuID == 0)
                return string.Empty;

            string lstrReturnValue = string.Empty;

            Model.Masters.LOVViewInfo myLOVViewInfo = SQLServerDAL.Masters.LOVView.GetLOVViewInfo(Convert.ToInt32(MenuID));

            lstrReturnValue = myLOVViewInfo.Caption;

            return lstrReturnValue;
        }
        public static void ClearControls(Control control)
        {
            for (int i = control.Controls.Count - 1; i >= 0; i--)
            {
                ClearControls(control.Controls[i]);
            }

            if (!(control is TableCell))
            {
                if (control.GetType().GetProperty("SelectedItem") != null)
                {
                    LiteralControl literal = new LiteralControl();
                    control.Parent.Controls.Add(literal);
                    try
                    {
                        literal.Text = (string)control.GetType().GetProperty("SelectedItem").GetValue(control, null);
                    }
                    catch
                    {
                    }
                    control.Parent.Controls.Remove(control);
                }
                else
                    if (control.GetType().GetProperty("Text") != null)
                    {
                        LiteralControl literal = new LiteralControl();
                        control.Parent.Controls.Add(literal);
                        literal.Text = (string)control.GetType().GetProperty("Text").GetValue(control, null);
                        control.Parent.Controls.Remove(control);
                    }
            }
            return;
        }
    }
    public sealed class Encryption
    {
        /// <summary>
        /// Encrypt string using key provided
        /// </summary>
        /// <param name="plainMessage">String to encrypt</param>
        /// <param name="password">key</param>
        /// <returns>Encrypted string</returns>
        public static string fnEncryptString(string plainMessage, string password)
        {
            try
            {
                TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
                des.IV = new byte[8];
                PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, new byte[0]);
                des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
                MemoryStream ms = new MemoryStream(plainMessage.Length * 2);
                CryptoStream encStream = new CryptoStream(ms, des.CreateEncryptor(),
                CryptoStreamMode.Write);
                byte[] plainBytes = Encoding.UTF8.GetBytes(plainMessage);
                encStream.Write(plainBytes, 0, plainBytes.Length);
                encStream.FlushFinalBlock();
                byte[] encryptedBytes = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(encryptedBytes, 0, (int)ms.Length);
                encStream.Close();

                return Convert.ToBase64String(encryptedBytes);
                //return plainMessage;
            }
            catch
            {
                //				LogMessage("Helper.fnEncryptString", ex.ToString(), false);
                //				return "";
                throw;
            }
        }
        /// <summary>
        /// Decrypt string using key provided
        /// </summary>
        /// <param name="encryptedBase64">String to be decrypted</param>
        /// <param name="password">key</param>
        /// <returns>Decrypted String</returns>
        public static string fnDecryptString(string encryptedBase64, string password)
        {
            try
            {
                TripleDESCryptoServiceProvider des = new TripleDESCryptoServiceProvider();
                des.IV = new byte[8];
                PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, new byte[0]);
                des.Key = pdb.CryptDeriveKey("RC2", "MD5", 128, new byte[8]);
                byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);
                MemoryStream ms = new MemoryStream(encryptedBase64.Length);
                CryptoStream decStream = new CryptoStream(ms, des.CreateDecryptor(),
                CryptoStreamMode.Write);
                decStream.Write(encryptedBytes, 0, encryptedBytes.Length);
                decStream.FlushFinalBlock();
                byte[] plainBytes = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(plainBytes, 0, (int)ms.Length);
                decStream.Close();

                return Encoding.UTF8.GetString(plainBytes);
                //return encryptedBase64;
            }
            catch
            {
                //				LogMessage("Helper.fnDecryptString", ex.ToString(), false);
                //				return "";
                throw;
            }
        }
    }
    public static class List
    {
        public static string[] pGetData(string prefixText, string contextKey)
        {
            string lstrQuery = contextKey;

            DataTable dt = null;
            DataView dv = null;
            try
            {
                StringBuilder sb1 = new StringBuilder();
                sb1.Append(" SELECT	TOP 0 * ");
                sb1.Append(" FROM	(" + lstrQuery + ") T1 ");

                dt = SQLServerDAL.General.GetDataTable(sb1.ToString());

                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT	TOP 10 * ");
                sb.Append("FROM (SELECT	* ");
                sb.Append("FROM	(" + lstrQuery + ") T1 ");
                sb.Append("WHERE	T1.[" + dt.Columns[0].ColumnName + "] LIKE '%" + prefixText.Replace("*", "") + "%' ) T2 ");

                dt = SQLServerDAL.General.GetDataTable(sb.ToString());
                dv = dt.DefaultView;
                dv.Sort = "[" + dt.Columns[0].ColumnName + "] ASC";
            }
            catch
            {
                dt = SQLServerDAL.General.GetDataTable(lstrQuery);
                dv = dt.DefaultView;
                dv.RowFilter = "[" + dt.Columns[0].ColumnName + "] like '%" + prefixText + "%'";
                dv.Sort = "[" + dt.Columns[0].ColumnName + "] ASC";
            }

            int Count = 0;
            List<string> lstItems;
            if (dv.Count >= 10)
                Count = 10;
            else
                Count = dv.Count;

            lstItems = new List<string>(Count);

            if (dv.Count == 0)
            {
                lstItems.Add(AjaxControlToolkit.AutoCompleteExtender.CreateAutoCompleteItem("No Records Found!", "No Records Found!"));
                return lstItems.ToArray();
            }

            for (int i = 0; i < Count; i++)
            {
                DataRowView drv = dv[i];

                if (drv != null)
                {
                    string Value = string.Empty;

                    for (int x = 0; x < dt.Columns.Count - 1; x++)
                    {
                        if (x <= 3)
                        {
                            if (dt.Columns[x].DataType.ToString() == "System.DateTime")
                            {
                                Value += (drv[x] == DBNull.Value ? "" : Convert.ToDateTime(drv[x]).ToString("dd-MMM-yyyy"));
                            }
                            else
                                Value += drv[x].ToString();

                            Value += ((char)9).ToString() + "|" + ((char)9).ToString();
                        }
                    }

                    lstItems.Add(AjaxControlToolkit.AutoCompleteExtender.CreateAutoCompleteItem(Value, drv[dt.Columns.Count - 1].ToString()));
                }
            }

            return lstItems.ToArray();
        }
    }
    public sealed class MessageBox
    {
        public static void Show(string sMsg, System.Web.UI.Page objPage)
        {
            StringBuilder sb = new StringBuilder();
            System.Web.UI.Control oControl;

            char c34 = Convert.ToChar(34);
            char c13 = Convert.ToChar(13);
            sMsg = sMsg.Replace("'", "\\'");
            sMsg = sMsg.Replace(c34.ToString(), "\\" + c34.ToString());
            sMsg = sMsg.Replace(c13.ToString(), "\\n");
            sMsg = "<script language=javascript>alert('" + sMsg + "');</script>";

            sb.Append(sMsg);

            foreach (System.Web.UI.Control t in objPage.Controls)
            {
                if (t.GetType().ToString() == "System.Web.UI.HtmlControls.HtmlForm")
                {
                    oControl = t;
                    oControl.Controls.AddAt(oControl.Controls.Count, new System.Web.UI.LiteralControl(sb.ToString()));
                    break;
                }
            }
        }
    }

    public sealed class Mail
    {
        public static bool SendMail(string strMailFrom, string strMailTo, string strMailCC, string strSubject, string strMailMessage, string strMailType, string strAttachments)
        {
            bool strReturnValue = false;
            System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
            try
            {
                string strSendUsing = ConfigurationSettings.AppSettings["SMTPServer_MailSendUsing"].ToString();
                string strSMTPServer = ConfigurationSettings.AppSettings["SMTPServer_IPorDNSAddress"].ToString();
                string strSMTPServerPort = ConfigurationSettings.AppSettings["SMTPServer_SMTPServerPort"].ToString();
                string strSendUserName = ConfigurationSettings.AppSettings["SMTPServer_SendUserName"].ToString();
                string strSendPassword = ConfigurationSettings.AppSettings["SMTPServer_SendPassword"].ToString();
                string strSMTPAuthenticate = ConfigurationSettings.AppSettings["SMTPServer_SMTPAuthenticate"].ToString();

                // If the mail to address is null then we mail to the "From Address"///
                if (strMailTo.Trim() == "") strMailTo = strMailFrom;

                MailMessage objMail = new MailMessage();

                if (strAttachments != string.Empty)
                {
                    string[] strFiles = strAttachments.Split(";".ToCharArray());

                    foreach (string strFile in strFiles)
                    {
                        System.Net.Mail.Attachment mailAttachment = new System.Net.Mail.Attachment(strFile);
                        objMail.Attachments.Add(mailAttachment);
                    }
                }

                objMail.From = new MailAddress(strMailFrom);

                foreach (string lstrTo in strMailTo.Split(';'))
                {
                    if (reg.IsMatch(lstrTo))
                    {
                        objMail.To.Add(new MailAddress(lstrTo));
                    }
                }

                foreach (string lstrCC in strMailTo.Split(';'))
                {
                    if (reg.IsMatch(lstrCC))
                    {
                        objMail.CC.Add(new MailAddress(lstrCC));
                    }
                }
                objMail.Subject = strSubject;
                objMail.IsBodyHtml = true;
                objMail.Body = strMailMessage;

                SmtpClient client = new SmtpClient();
                client.UseDefaultCredentials = true;
                client.Host = strSMTPServer;
                //client.Host = "mail.infologsolutions.com";
                client.Port = Convert.ToInt32(strSMTPServerPort);
                // client.Port = Convert.ToInt32("25");
                // client.Send("n.sashidhar@infologsolutions.com","udayravi@infologsolutions.com", strSubject, strMailMessage);
                //client.Send(strMailFrom, strMailTo, strSubject, strMailMessage);
                client.Send(objMail);
                strReturnValue = true;
            }
            catch (Exception ex)
            {
                string str = ex.Message.ToString();
                strReturnValue = false;
            }
            return strReturnValue;
        }
    }
}