﻿using System;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using ISPL.CSC.SQLServerDAL.Masters;

namespace ISPL.CSC.Web.ProcessFlow
{
    public class ValidateDocNumber
    {
        public static bool ValidateFormControls(System.Web.UI.Page page, Model.DocNumberParms parm, ref Model.DocNumberParms refparm)
        {
            return ValidateFormControls(page, parm, ref refparm, false);
        }
        public static bool ValidateFormControls(System.Web.UI.Page page, Model.DocNumberParms parm, ref Model.DocNumberParms refparm, bool errMessage)
        {
            string lstrFormat = "", lstrTemp = "";
            bool lblnValidate = false;
            bool matchFound;
            int j, formatSlNo = 0;

            DataTable myTable = SQLServerDAL.AutoNumberHdr.GetJobFormatsByMenuID(parm.MenuSlno, parm.BranchID);

            matchFound = false;
            foreach (DataRow objDR in myTable.Rows)
            {
                if (objDR["TD_JOBFRMT_SLNO"] != System.DBNull.Value)
                {
                    if (Convert.ToInt32(objDR["TD_JOBFRMT_SLNO"].ToString()) != 0)
                    {

                        if (parm.ControlNames.Length > 0)
                        {
                            for (j = 0; j < parm.ControlNames.Length; j++)
                            {
                                string x = parm.ControlTexts[j].ToString();
                                if (objDR["G_FIELDDESC_FLDNOMEN"].ToString() == parm.ControlTexts[j].ToString())
                                {
                                    switch (parm.ControlTypes[j].ToString())
                                    {
                                        case "TextBox":
                                            TextBox tb1 = (TextBox)page.FindControl(parm.ControlNames[j].ToString());
                                            lstrTemp = tb1.Text;
                                            break;

                                        case "DropDownList":
                                            DropDownList ddl = (DropDownList)page.FindControl(parm.ControlNames[j].ToString());
                                            lstrTemp = ddl.SelectedItem.Text;
                                            break;
                                            
                                        case "LOVControl":

                                            string y = parm.ControlNames[j].ToString();

                                            TextBox txtBox = (TextBox)page.FindControl(parm.ControlNames[j].ToString()).FindControl("txtName");
                                            lstrTemp = txtBox.Text;
                                            //Web.Controls.LOVControl lovControl = (Web.Controls.LOVControl)page.FindControl();
                                            //lstrTemp = lovControl.strFirstColumn;
                                            break;
                                    }
                                    if (lstrTemp == objDR["TD_JOBFRMT_GFIELDDESCVAL"].ToString())
                                    {
                                        matchFound = true;
                                        lstrFormat = objDR["TM_JOBFRMT_FORMAT"].ToString();
                                        formatSlNo = Convert.ToInt32(objDR["TM_JOBFRMT_SLNO"].ToString());
                                        break;
                                    }
                                }
                                if (matchFound == true) break;
                            }
                        }
                    }
                }
            }

            if (!matchFound)
            {
                foreach (DataRow objDR in myTable.Rows)
                {
                    if (objDR["TD_JOBFRMT_SLNO"].ToString().Length == 0)
                    {
                        matchFound = true;
                        lstrFormat = objDR["TM_JOBFRMT_FORMAT"].ToString();
                        formatSlNo = Convert.ToInt32(objDR["TM_JOBFRMT_SLNO"].ToString());
                        break;
                    }
                }
            }
            
            TextBox tb = (TextBox)page.FindControl(parm.AutoNumberControl);
            if (matchFound)
            {
                tb.Text = lstrFormat;
                tb.ReadOnly = true; ;
                tb.BackColor = Color.LightGoldenrodYellow;
                refparm.FormatSlno = formatSlNo;
                lblnValidate = true;
            }
            else if (tb.Text.Length == 0 && !errMessage)
            {
                //tb.Text = "Auto number could not be generated!";
                tb.ReadOnly = false;
                refparm.FormatSlno = 0;
                lblnValidate = false;
            }
            else
            {
                tb.ReadOnly = false;
                tb.Text = "";
                tb.BackColor = Color.White;
                refparm.FormatSlno = 0;
                lblnValidate = false;
            }
            parm.AutoNumberControl = tb.ID;
            refparm.AutoNumberControl = tb.ID;
            return lblnValidate;
        }
        public static void UpdateJobCounter(int FormatID)
        {
            string lstrSQL = string.Empty;
            lstrSQL = " UPDATE	TM_EOU_JOBFRMT "
                + " SET		TM_JOBFRMT_COUNTER = TM_JOBFRMT_COUNTER + 1, "
                + "			TM_JOBFRMT_FORMAT = TM_JOBFRMT_PREFIX + CONVERT(VARCHAR(10), TM_JOBFRMT_COUNTER + 1) + TM_JOBFRMT_SUFFIX "
                + " WHERE	TM_JOBFRMT_SLNO = " + FormatID.ToString();

            SQLServerDAL.General.ExecuteNonQuery(lstrSQL);
        }
    }
}
