﻿using System;
using System.Text;

namespace ISPL.CSC.Web.Controls
{
    public class NumericTextBox : System.Web.UI.WebControls.TextBox
    {
        private bool _allowDecimal = true;
        private bool _allowNegative = false;
        private int _decimals = 8;

        public bool AllowDecimal
        {
            get { return _allowDecimal; }
            set { this._allowDecimal = value; }
        }
        public bool AllowNegative
        {
            get { return _allowNegative; }
            set { this._allowNegative = value; }
        }
        public int Decimals
        {
            get { return _decimals; }
            set { this._decimals = value; }
        }
        public override string Text
        {
            get { return (base.Text); }

            set
            {
                try
                {
                    if (value.Length == 0)
                        base.Text = "0";
                    else
                        base.Text = Math.Round(Convert.ToDouble(value), _decimals).ToString();
                }
                catch (Exception ex)
                {
                    base.Text = ex.ToString();

                };
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.Style["text-align"] = "right";
            //base.Width = 100;
            StringBuilder strScript = new StringBuilder();
            strScript.Append("<script language=javascript> function VN" + base.ClientID + "() {");
            strScript.Append(" var lstr = window.document.getElementById('" + base.ClientID + "').value; ");
            strScript.Append(" var keyCode = window.event.keyCode; ");
            strScript.Append(" if ((keyCode >= 48 && keyCode <= 57) || (" + (_allowDecimal ? "true" : "false") + " && keyCode == 46) || (" + (_allowNegative ? "true" : "false") + " && keyCode == 45) || (keyCode == 8)) ");
            strScript.Append(" { ");
            strScript.Append(" if (" + (_allowDecimal ? "true" : "false") + " && keyCode == 46) ");
            strScript.Append(" { ");
            strScript.Append(" if (lstr.indexOf('.', 0) >= 0) ");
            strScript.Append(" { ");
            strScript.Append(" window.event.returnValue = false; ");
            strScript.Append(" return; ");
            strScript.Append(" } ");
            strScript.Append(" } ");

            strScript.Append(" if (" + (_allowDecimal ? "true" : "false") + " && lstr.indexOf('.', 0) >= 0) ");
            strScript.Append(" { ");
            strScript.Append(" var index = lstr.indexOf('.', 0); ");
            strScript.Append(" var str = lstr.substring(index + 1, lstr.length); ");
            strScript.Append(" if (str.length > (" + _decimals.ToString() + "-1)) ");
            strScript.Append(" { ");
            strScript.Append(" window.event.returnValue = false; ");
            strScript.Append(" } ");
            strScript.Append(" } ");

            strScript.Append(" if (" + (_allowNegative ? "true" : "false") + " && keyCode == 45) ");
            strScript.Append(" { ");
            strScript.Append(" if (lstr.length != 0) ");
            strScript.Append(" { ");
            strScript.Append(" window.event.returnValue = false; ");
            strScript.Append(" return; ");
            strScript.Append(" } ");
            strScript.Append(" } ");
            strScript.Append(" } ");
            strScript.Append(" else ");
            strScript.Append(" { ");
            strScript.Append(" window.event.returnValue = false; ");
            strScript.Append(" return; ");
            strScript.Append(" } ");
            strScript.Append(" } ");
            strScript.Append(" </script> ");

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("VNScript" + base.ClientID))
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "VNScript" + base.ClientID, strScript.ToString());
            Attributes.Add("onKeyPress", "VN" + base.ClientID + "()");

            //Newly Added for Theming.
            //base.EnableTheming = true;
            base.OnPreRender(e);

        }

    }
}
