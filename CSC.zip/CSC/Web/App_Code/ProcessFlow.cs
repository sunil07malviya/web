﻿using System.Web;
using System.Web.Security;
using System.Configuration;

using ISPL.CSC.Model.Masters;
using ISPL.CSC.SQLServerDAL.Masters;
using System.Net;
using System.Text;
using System.Xml;
using System.IO;

namespace ISPL.CSC.Web.ProcessFlow
{
    public class AccountController
    {
        private const string DB_KEY = "DB_KEY";
        private const string LOGIN_KEY = "LOGIN_KEY";
        private const string BRANCH_KEY = "BRANCH_KEY";
        private const string URL_DEFAULT = "default.aspx";
        //private const string URL_SIGNIN = "SignIn.aspx";
        private const string URL_ACCOUNTSIGNIN = "CustomerServiceCentre.aspx";
        private const string URL_CHECKPASSWORD = "ChangePassword.aspx";

        public AccountController() { }

        private string URL_SIGNIN()
        {
            string Security = ConfigurationSettings.AppSettings["Security"].ToString();

            if (Security == "LDAP")
                return "SignIn1.aspx";
            else
                return "SignIn.aspx";
        }

        public bool ProcessLogin(string DBName, int BranchID, string UserID, string Password)
        {
            BranchInfo myBranchInfo = SQLServerDAL.Masters.Branch.GetBranchInfoByID(DBName, BranchID);

            UserInfo LoginUserInfo = SQLServerDAL.Masters.User.SignIn(DBName, BranchID, UserID, Password);

            if (LoginUserInfo != null)
            {
                HttpContext.Current.Session[DB_KEY] = DBName;
                HttpContext.Current.Session[LOGIN_KEY] = LoginUserInfo;
                HttpContext.Current.Session[BRANCH_KEY] = myBranchInfo;

                if (FormsAuthentication.GetRedirectUrl(UserID, false).EndsWith(URL_DEFAULT))
                {
                    FormsAuthentication.SetAuthCookie(UserID, false);
                    HttpContext.Current.Response.Redirect(URL_ACCOUNTSIGNIN, true);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(UserID, false);
                    HttpContext.Current.Response.Redirect(FormsAuthentication.GetRedirectUrl(UserID, false), true);
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool ChekPassword(string DBName, int BranchID, string UserID, string Password, int expdays, int pwddays)
        {
            BranchInfo myBranchInfo = SQLServerDAL.Masters.Branch.GetBranchInfoByID(DBName, BranchID);            
            UserInfo LoginUserInfo = SQLServerDAL.Masters.User.SignIn(DBName, BranchID, UserID, Password);

            if (LoginUserInfo != null)
            {
                HttpContext.Current.Session[DB_KEY] = DBName;
                HttpContext.Current.Session[LOGIN_KEY] = LoginUserInfo;
                HttpContext.Current.Session[BRANCH_KEY] = myBranchInfo;

                if (expdays <= pwddays)
                {
                    if (FormsAuthentication.GetRedirectUrl(LoginUserInfo.UserID, false).EndsWith(URL_DEFAULT))
                    {
                        FormsAuthentication.SetAuthCookie(LoginUserInfo.UserID, false);
                        HttpContext.Current.Response.Redirect(URL_CHECKPASSWORD, true);
                    }
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(LoginUserInfo.UserID, false);

                    HttpContext.Current.Response.Redirect(URL_ACCOUNTSIGNIN, true);
                }

                return true;
            }
            return false;
        }

        public bool ProcessLogin(int BranchID, string UserId, string password)
        {
            BranchInfo myBranchInfo = SQLServerDAL.Masters.Branch.GetBranchInfoByID(BranchID);
            
            UserInfo LoginUserInfo = SQLServerDAL.Masters.User.SignIn(BranchID, UserId, password);

            if (LoginUserInfo != null)
            {
                HttpContext.Current.Session[LOGIN_KEY] = LoginUserInfo;
                HttpContext.Current.Session[BRANCH_KEY] = myBranchInfo;

                if (FormsAuthentication.GetRedirectUrl(UserId, false).EndsWith(URL_DEFAULT))
                {
                    FormsAuthentication.SetAuthCookie(UserId, false);

                    HttpContext.Current.Response.Redirect(URL_ACCOUNTSIGNIN, true);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(UserId, false);
                    HttpContext.Current.Response.Redirect(FormsAuthentication.GetRedirectUrl(UserId, false), true);
                }
                return true;
            }
            else
            {
                return false;
            }
        }


        public bool ProcessLoginLDAP(string DBName, int BranchID, string UserID)
        {
            BranchInfo myBranchInfo = SQLServerDAL.Masters.Branch.GetBranchInfoByID(DBName, BranchID);

            UserInfo LoginUserInfo = SQLServerDAL.Masters.User.SignInLDAP(DBName, BranchID, UserID);

            if (LoginUserInfo != null)
            {
                HttpContext.Current.Session[DB_KEY] = DBName;
                HttpContext.Current.Session[LOGIN_KEY] = LoginUserInfo;
                HttpContext.Current.Session[BRANCH_KEY] = myBranchInfo;

                if (FormsAuthentication.GetRedirectUrl(UserID, false).EndsWith(URL_DEFAULT))
                {
                    FormsAuthentication.SetAuthCookie(UserID, false);
                    HttpContext.Current.Response.Redirect(URL_ACCOUNTSIGNIN, true);
                }
                else
                {
                    FormsAuthentication.SetAuthCookie(UserID, false);
                    HttpContext.Current.Response.Redirect(FormsAuthentication.GetRedirectUrl(UserID, false), true);
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        //public string GetBranchType(bool required)
        //{
        //    BranchInfo myBranchInfo = (BranchInfo)HttpContext.Current.Session[BRANCH_KEY];

        //    if (myBranchInfo == null)
        //    {
        //        if (required)
        //            HttpContext.Current.Response.Redirect(URL_SIGNIN(), true);

        //        return null;
        //    }
        //    else
        //        return myBranchInfo.EType;
        //}
        public BranchInfo GetBranchInfo(bool required)
        {
            BranchInfo myBranchInfo = (BranchInfo)HttpContext.Current.Session[BRANCH_KEY];

            if (myBranchInfo == null)
            {
                if (required)
                    HttpContext.Current.Response.Redirect(URL_SIGNIN(), true);

                return null;
            }
            else
                return myBranchInfo;
        }
        public string GetDBName(bool required)
        {
            string myDBName = HttpContext.Current.Session[DB_KEY].ToString();

            if (myDBName == null)
            {
                if (required)
                    HttpContext.Current.Response.Redirect(URL_SIGNIN(), true);

                return null;
            }
            else
                return myDBName;
        }
        public UserInfo GetUserInfo(bool required)
        {
            UserInfo myTmpUserInfo = (UserInfo)HttpContext.Current.Session[LOGIN_KEY];

            if (myTmpUserInfo == null)
            {
                if (required)
                    HttpContext.Current.Response.Redirect(URL_SIGNIN(), true);

                return null;
            }
            else
                return myTmpUserInfo;
        }
        public void LogOut()
        {
            FormsAuthentication.SignOut();
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
        }

        public string PushXMLData(StringBuilder sb)
        {
            string EndPointURL = System.Configuration.ConfigurationManager.AppSettings["EndPointURL"].ToString();
            string EndPointUserID = System.Configuration.ConfigurationManager.AppSettings["EndPointUserID"].ToString();
            string EndPointPassword = System.Configuration.ConfigurationManager.AppSettings["EndPointPassword"].ToString();
            //Stage
            //HttpWebRequest request = CreateWebRequest("https://www.blackberry.com/stagingexchange/soap/MessageServlet?channel=REPAIR_AND_RETURN:srv_eRMA:srv_eRMA_status_update_soap_server", "SRVRANDR", "Cscrr123");
            //Production
            //HttpWebRequest request = CreateWebRequest("https://www.blackberry.com/exchange/soap/MessageServlet?channel=REPAIR_AND_RETURN:srv_eRMA:srv_eRMA_status_update_soap_server", "SRVRANDR", "b2b4rnr");
            
            HttpWebRequest request = CreateWebRequest(EndPointURL, EndPointUserID, EndPointPassword);
                                                       
            XmlDocument soapEnvelopeXml = new XmlDocument();
            soapEnvelopeXml.LoadXml(sb.ToString());

            using (Stream stream = request.GetRequestStream())
            {
                soapEnvelopeXml.Save(stream);
            }
            try
            {
                WebResponse response = request.GetResponse();
                using (StreamReader rd = new StreamReader(response.GetResponseStream()))
                {
                    string soapResult = rd.ReadToEnd();

                    //txtResponse.Text = soapResult;

                    return "Successfully.";
                    
                    //return soapResult;
                }
            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    WebResponse resp = ex.Response;
                    using (StreamReader srd = new StreamReader(resp.GetResponseStream()))
                    {
                        string soapResult = srd.ReadToEnd();

                        //txtResponse.Text = soapResult;
                        return soapResult;
                    }
                }
                else
                {
                    //txtResponse.Text = ex.Message;
                    return "Push XML failed.";
                }
            }
        }

        public HttpWebRequest CreateWebRequest(string endpoint, string user, string pwd)
        {
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(endpoint);
            webRequest.Headers.Add(@"SOAP:Action");
            webRequest.ContentType = "text/xml;charset=\"utf-8\"";
            webRequest.Accept = "text/xml";
            webRequest.Method = "POST";
            if (!string.IsNullOrEmpty(user))
                webRequest.Credentials = new NetworkCredential(user, pwd);
            webRequest.PreAuthenticate = true;
            webRequest.Proxy = WebRequest.DefaultWebProxy;
            webRequest.Timeout = System.Threading.Timeout.Infinite;
            webRequest.KeepAlive = true;
            webRequest.UserAgent = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)";
            return webRequest;
        }
    }
}