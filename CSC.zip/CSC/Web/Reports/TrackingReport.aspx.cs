﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;

namespace ISPL.CSC.Web.Reports
{
    public partial class TrackingReport : BasePage
    {
        private const string TRAN_ID_KEY = "ID";
        private const string STATUS_KEY = "Status";
        private const string COLUMN_COUNT_KEY = "COLUMN_COUNT_KEY";
        private const string PAGE_INDEX_KEY = "PAGE_INDEX_KEY";
        private const string SORT_KEY = "SORTY_KEY";
        private const string DETAIL_KEY = "DETAIL_KEY";
        private const string TABLE_KEY = "TABLE_KEY";
        private const string EXCEL_KEY = "EXCEL_KEY";

        protected void Page_Load(object sender, EventArgs e)
        {
            this.LOVPO.LOVBeforeClick += new EventHandler(LOVPO_LOVBeforeClick);
            this.LOVContanier.LOVBeforeClick += new EventHandler(LOVContanier_LOVBeforeClick);
            this.LOVHAWB.LOVBeforeClick += new EventHandler(LOVHAWB_LOVBeforeClick);
            this.LOVMBl.LOVBeforeClick += new EventHandler(LOVMBl_LOVBeforeClick);
            this.LOVItem.LOVBeforeClick += new EventHandler(LOVItem_LOVBeforeClick);

            if (!IsPostBack)
            {
                ViewState[PAGE_INDEX_KEY] = 0;
                ViewState[SORT_KEY] = "ASC";

            }
            pSetUserControls();
            ddlStatus_SelectedIndexChanged(sender, e);
            // pBindGrid(null, null);
            //if (gvTrackingReport.Rows.Count > 0 && !IsPostBack)
            //{
            //    gvTrackingReport.SelectedIndex = 0;
            //    //gvTrackingReport_SelectedIndexChanged(sender, e);
            //}
        }

        protected void LOVItem_LOVBeforeClick(object sender, EventArgs e)
        {
            if (LOVHAWB.strLastColumn.Length != 0)
            {
                if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVItem.Query = "  SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item "
                                   + " INNER JOIN TD2_EOU_SUPINV ON TD2_EOU_SUPINV_ITEM = ITEMCD "
                                   + " INNER JOIN TM_EOU_SUPINV ON TD2_EOU_SUPINV_TMSLNO = TM_EOU_SUPINV_SLNO "
                                   + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD2_EOU_SUPINV_PONO "
                                   + " INNER JOIN M_CONSIGNOR ON TM_EOU_SUPINV_SUPPLIER = SUPCD "
                                   + " INNER JOIN TD1_EOU_PREALERT ON TD1_PREALERT_SUPINVNO = TD2_EOU_SUPINV_TMSLNO "
                                   + " INNER JOIN TM_EOU_PREALERT ON TM_PREALERT_SLNO = TM_EOU_SUPINV_SLNO "
                                   + " WHERE TM_PO_SLNO = " + LOVPO.strLastColumn + " AND SUPCD = " + LOVSupplier.strLastColumn + " AND TM_PREALERT_SLNO = " + LOVHAWB.strLastColumn;
                }
                else if (LOVSupplier.strLastColumn.Length == 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVItem.Query = "  SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item "
                                   + " INNER JOIN TD2_EOU_SUPINV ON TD2_EOU_SUPINV_ITEM = ITEMCD "
                                   + " INNER JOIN TM_EOU_SUPINV ON TD2_EOU_SUPINV_TMSLNO = TM_EOU_SUPINV_SLNO "
                                   + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD2_EOU_SUPINV_PONO "
                                   + " INNER JOIN M_CONSIGNOR ON TM_EOU_SUPINV_SUPPLIER = SUPCD "
                                   + " INNER JOIN TD1_EOU_PREALERT ON TD1_PREALERT_SUPINVNO = TD2_EOU_SUPINV_TMSLNO "
                                   + " INNER JOIN TM_EOU_PREALERT ON TM_PREALERT_SLNO = TM_EOU_SUPINV_SLNO "
                                   + " WHERE TM_PO_SLNO = " + LOVPO.strLastColumn + " AND TM_PREALERT_SLNO = " + LOVHAWB.strLastColumn;

                }
                else
                    LOVItem.Query = "  SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item "
                                   + " INNER JOIN TD2_EOU_SUPINV ON TD2_EOU_SUPINV_ITEM = ITEMCD "
                                   + " INNER JOIN TM_EOU_SUPINV ON TD2_EOU_SUPINV_TMSLNO = TM_EOU_SUPINV_SLNO "
                                   + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD2_EOU_SUPINV_PONO "
                                   + " INNER JOIN M_CONSIGNOR ON TM_EOU_SUPINV_SUPPLIER = SUPCD "
                                   + " INNER JOIN TD1_EOU_PREALERT ON TD1_PREALERT_SUPINVNO = TD2_EOU_SUPINV_TMSLNO "
                                   + " INNER JOIN TM_EOU_PREALERT ON TM_PREALERT_SLNO = TM_EOU_SUPINV_SLNO "
                                   + " WHERE TM_PREALERT_SLNO = " + LOVHAWB.strLastColumn;
            }
            else if (LOVHAWB.strLastColumn.Length == 0 && LOVMBl.strLastColumn.Length != 0)
            {
                if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVItem.Query = "  SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item "
                                  + " INNER JOIN TD2_EOU_SUPINV ON TD2_EOU_SUPINV_ITEM = ITEMCD "
                                  + " INNER JOIN TM_EOU_SUPINV ON TD2_EOU_SUPINV_TMSLNO = TM_EOU_SUPINV_SLNO "
                                  + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD2_EOU_SUPINV_PONO "
                                  + " INNER JOIN M_CONSIGNOR ON TM_EOU_SUPINV_SUPPLIER = SUPCD "
                                  + " INNER JOIN TD1_EOU_PREALERT ON TD1_PREALERT_SUPINVNO = TD2_EOU_SUPINV_TMSLNO "
                                  + " INNER JOIN TM_EOU_PREALERT ON TM_PREALERT_SLNO = TM_EOU_SUPINV_SLNO "
                                  + " WHERE TM_PO_SLNO = " + LOVPO.strLastColumn + " AND SUPCD = " + LOVSupplier.strLastColumn + " AND TM_PREALERT_SLNO = " + LOVMBl.strLastColumn;

                }
                else if (LOVSupplier.strLastColumn.Length == 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVItem.Query = "  SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item "
                                   + " INNER JOIN TD2_EOU_SUPINV ON TD2_EOU_SUPINV_ITEM = ITEMCD "
                                   + " INNER JOIN TM_EOU_SUPINV ON TD2_EOU_SUPINV_TMSLNO = TM_EOU_SUPINV_SLNO "
                                   + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD2_EOU_SUPINV_PONO "
                                   + " INNER JOIN M_CONSIGNOR ON TM_EOU_SUPINV_SUPPLIER = SUPCD "
                                   + " INNER JOIN TD1_EOU_PREALERT ON TD1_PREALERT_SUPINVNO = TD2_EOU_SUPINV_TMSLNO "
                                   + " INNER JOIN TM_EOU_PREALERT ON TM_PREALERT_SLNO = TM_EOU_SUPINV_SLNO "
                                   + " WHERE TM_PREALERT_SLNO = " + LOVMBl.strLastColumn;
                }

                else
                    LOVItem.Query = "  SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item "
                                    + " INNER JOIN TD2_EOU_SUPINV ON TD2_EOU_SUPINV_ITEM = ITEMCD "
                                    + " INNER JOIN TM_EOU_SUPINV ON TD2_EOU_SUPINV_TMSLNO = TM_EOU_SUPINV_SLNO "
                                    + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD2_EOU_SUPINV_PONO "
                                    + " INNER JOIN M_CONSIGNOR ON TM_EOU_SUPINV_SUPPLIER = SUPCD "
                                    + " INNER JOIN TD1_EOU_PREALERT ON TD1_PREALERT_SUPINVNO = TD2_EOU_SUPINV_TMSLNO "
                                    + " INNER JOIN TM_EOU_PREALERT ON TM_PREALERT_SLNO = TM_EOU_SUPINV_SLNO "
                                    + " WHERE TM_PREALERT_SLNO = " + LOVMBl.strLastColumn;

            }
            else if (LOVHAWB.strLastColumn.Length == 0 && LOVMBl.strLastColumn.Length == 0)
            {
                if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVItem.Query = "SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item INNER JOIN TD_EOU_PO ON TD_PO_ITEMCODE = ITEMCD "
                                    + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD_PO_MSLNO INNER JOIN M_CONSIGNOR ON TM_PO_VENDCODE = SUPCD "
                                    + " WHERE TM_PO_SLNO = " + LOVPO.strLastColumn + " AND SUPCD = " + LOVSupplier.strLastColumn;
                }
                else if (LOVSupplier.strLastColumn.Length == 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVItem.Query = "SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description],ItemCd FROM m_item INNER JOIN TD_EOU_PO ON TD_PO_ITEMCODE = ITEMCD "
                                   + " INNER JOIN TM_EOU_PO ON TM_PO_SLNO = TD_PO_MSLNO INNER JOIN M_CONSIGNOR ON TM_PO_VENDCODE = SUPCD "
                                   + " WHERE TM_PO_SLNO = " + LOVPO.strLastColumn;

                }
                else
                    LOVItem.Query = "SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description] ,ItemCd FROM m_item";

            }
            else
                LOVItem.Query = "SELECT ItemNm as [Item Name], PartCode as [Part Code],ItemDesc as [Description] ,ItemCd FROM m_item";
        }
        protected void LOVMBl_LOVBeforeClick(object sender, EventArgs e)
        {
            if (LOVHAWB.strLastColumn.Length == 0)
            {
                if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVMBl.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date],TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) "
                                    + " inner join td1_eou_prealert on TD1_PREALERT_MSLNO=TM_PREALERT_SLNO inner join td1_eou_supinv on TD1_PREALERT_SUPINVNO = TD1_EOU_SUPINV_TMSLNO "
                                    + " inner join tm_eou_po on  TD1_EOU_SUPINV_PO = tm_po_slno inner join m_consignor on supcd=TD1_PREALERT_SUPCD where tm_po_slno = " + LOVPO.strLastColumn + " and supcd = " + LOVSupplier.strLastColumn;
                }
                else if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length == 0)
                {
                    LOVMBl.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date],TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) inner join td1_eou_prealert on TD1_PREALERT_MSLNO=TM_PREALERT_SLNO inner join m_consignor on supcd=TD1_PREALERT_SUPCD  and supcd = " + LOVSupplier.strLastColumn;
                }
                else if (LOVSupplier.strLastColumn.Length == 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVMBl.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date],TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) "
                                   + " inner join td1_eou_prealert on TD1_PREALERT_MSLNO=TM_PREALERT_SLNO inner join td1_eou_supinv on TD1_PREALERT_SUPINVNO = TD1_EOU_SUPINV_TMSLNO "
                                   + " inner join tm_eou_po on  TD1_EOU_SUPINV_PO = tm_po_slno where tm_po_slno = " + LOVPO.strLastColumn;
                }
                else
                    LOVMBl.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date], TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK)";
            }
            else if (LOVHAWB.strLastColumn.Length != 0)
                LOVMBl.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date], TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) where tm_prealert_slno = " + LOVHAWB.strLastColumn;
            else
                LOVMBl.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date], TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK)";
        }
        protected void LOVHAWB_LOVBeforeClick(object sender, EventArgs e)
        {
            if (LOVMBl.strLastColumn.Length == 0)
            {
                if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVHAWB.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date],TM_PREALERT_HBLNO AS [HBL No],TM_PREALERT_HBLDATE AS [HBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) "
                                    + " inner join td1_eou_prealert on TD1_PREALERT_MSLNO=TM_PREALERT_SLNO inner join td1_eou_supinv on TD1_PREALERT_SUPINVNO = TD1_EOU_SUPINV_TMSLNO "
                                    + " inner join tm_eou_po on  TD1_EOU_SUPINV_PO = tm_po_slno inner join m_consignor on supcd=TD1_PREALERT_SUPCD where tm_po_slno = " + LOVPO.strLastColumn + " and supcd = " + LOVSupplier.strLastColumn;
                }
                else if (LOVSupplier.strLastColumn.Length != 0 && LOVPO.strLastColumn.Length == 0)
                {
                    LOVHAWB.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date],TM_PREALERT_HBLNO AS [HBL No],TM_PREALERT_HBLDATE AS [HBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) inner join td1_eou_prealert on TD1_PREALERT_MSLNO=TM_PREALERT_SLNO inner join m_consignor on supcd=TD1_PREALERT_SUPCD  and supcd = " + LOVSupplier.strLastColumn;
                }
                else if (LOVSupplier.strLastColumn.Length == 0 && LOVPO.strLastColumn.Length != 0)
                {
                    LOVHAWB.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date],TM_PREALERT_HBLNO AS [HBL No],TM_PREALERT_HBLDATE AS [HBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) "
                                   + " inner join td1_eou_prealert on TD1_PREALERT_MSLNO=TM_PREALERT_SLNO inner join td1_eou_supinv on TD1_PREALERT_SUPINVNO = TD1_EOU_SUPINV_TMSLNO "
                                   + " inner join tm_eou_po on  TD1_EOU_SUPINV_PO = tm_po_slno where tm_po_slno = " + LOVPO.strLastColumn;
                }
                else
                    LOVHAWB.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date], TM_PREALERT_HBLNO AS [HBL No],TM_PREALERT_HBLDATE AS [HBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK)";
            }
            else if (LOVMBl.strLastColumn.Length != 0)
                LOVHAWB.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date], TM_PREALERT_MBLNO AS [MBL No],TM_PREALERT_MBLDATE AS [MBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK) where tm_prealert_slno = " + LOVMBl.strLastColumn;
            else
                LOVHAWB.Query = "SELECT TM_PREALERT_SHPMTNO as [Shipment NO],TM_PREALERT_DOCUMENTDATE as [Document Date], TM_PREALERT_HBLNO AS [HBL No],TM_PREALERT_HBLDATE AS [HBL Date],TM_PREALERT_SLNO FROM tm_eou_prealert with (ROWLOCK)";
        }
        protected void LOVContanier_LOVBeforeClick(object sender, EventArgs e)
        {
            if (LOVHAWB.strLastColumn.Length != 0)
            {
                LOVContanier.Query = "SELECT TD2_PREALERT_CONTAINERNO[Container No],TypeCode [Container Type],Description [Container Description],TD2_PREALERT_SLNO FROM M_CONTAINER WITH (ROWLOCK)"
                               + "  INNER JOIN TD2_EOU_PREALERT WITH (ROWLOCK) ON TD2_PREALERT_CONTAINERTYPE = ContainerCode"
                               + " WHERE TD2_PREALERT_MSLNO = " + LOVHAWB.strLastColumn;
            }
            else if (LOVHAWB.strLastColumn.Length == 0 && LOVMBl.strLastColumn.Length != 0)
            {
                LOVContanier.Query = "SELECT TD2_PREALERT_CONTAINERNO[Container No],TypeCode [Container Type],Description [Container Description],TD2_PREALERT_SLNO FROM M_CONTAINER WITH (ROWLOCK)"
                               + "  INNER JOIN TD2_EOU_PREALERT WITH (ROWLOCK) ON TD2_PREALERT_CONTAINERTYPE = ContainerCode"
                               + " WHERE TD2_PREALERT_MSLNO = " + LOVMBl.strLastColumn;
            }
            else
                LOVContanier.Query = "SELECT TD2_PREALERT_CONTAINERNO[Container No],TypeCode [Container Type],Description [Container Description],TD2_PREALERT_SLNO FROM M_CONTAINER WITH (ROWLOCK)"
                               + "  INNER JOIN TD2_EOU_PREALERT WITH (ROWLOCK) ON TD2_PREALERT_CONTAINERTYPE = ContainerCode";

        }
        protected void LOVPO_LOVBeforeClick(object sender, EventArgs e)
        {
            if (LOVSupplier.strLastColumn.Length != 0)
            {
                LOVPO.Query = "SELECT TM_PO_PONO AS [PO No],TM_PO_PODT AS [PO Date],SUPNM [SUPPLIER],TM_PO_SLNO FROM TM_EOU_PO inner join m_consignor on supcd=TM_PO_VENDCODE where supcd= " + LOVSupplier.strLastColumn;
            }
            else
            {
                LOVPO.Query = "SELECT TM_PO_PONO AS [PO No],TM_PO_PODT AS [PO Date],SUPNM [SUPPLIER],TM_PO_SLNO FROM TM_EOU_PO with (ROWLOCK) LEFT OUTER join m_consignor on supcd=TM_PO_VENDCODE ";
            }
        }
        private void pSetUserControls()
        {
            LOVSupplier.Required = false;
            LOVSupplier.Query = "SELECT SUPNM AS [Supplier Name],SUPSNM AS [Short Name],SUPCD FROM M_CONSIGNOR";
            LOVItem.Required = false;
            LOVPO.Required = false;
            LOVHAWB.Required = false;
            LOVMBl.Required = false;
            LOVContanier.Required = false;
            lblMessage.Text = "";
            // btnExcel.Visible = false;
        }
        private void pBindGrid(string sortExpression, string direction)
        {
            string strQuery = null;
            DataTable myTable = null;
            if (ViewState[TABLE_KEY].ToString() != null)
                strQuery = ViewState[TABLE_KEY].ToString();
            else
                strQuery = "";

            myTable = SQLServerDAL.General.GetDataTable(strQuery);

            if (myTable.Rows.Count > 0)
            {
                ViewState[COLUMN_COUNT_KEY] = myTable.Columns.Count;

                gvTrackingReport.DataKeyNames = new string[] { myTable.Columns[myTable.Columns.Count - 1].ColumnName };
                gvTrackingReport.Columns.Clear();
                for (int i = 0; i < myTable.Columns.Count; i++)
                {
                    DataColumn objDC = myTable.Columns[i];

                    if (objDC.ColumnName.Contains("URL"))
                    {
                        HyperLinkField hlField = new HyperLinkField();
                        hlField.Text = "Click Here!";
                        hlField.DataNavigateUrlFormatString = "{0}";
                        hlField.DataNavigateUrlFields = new string[] { objDC.ColumnName };
                        hlField.HeaderText = objDC.ColumnName;
                        hlField.DataTextField = objDC.ColumnName;
                        
                        hlField.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                        hlField.ItemStyle.HorizontalAlign = HorizontalAlign.Center;
                        
                        hlField.HeaderStyle.CssClass = (i == 0 ? "first" : "");
                        hlField.ItemStyle.CssClass = (i == 0 ? "first" : "row");
                        hlField.Target = "_blank";
                        gvTrackingReport.Columns.Add(hlField);
                    }
                    else
                    {
                        BoundField objBC = new BoundField();
                        objBC.DataField = objDC.ColumnName;
                        objBC.HeaderText = objDC.ColumnName;
                        objBC.SortExpression = objDC.ColumnName;
                        objBC.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                        objBC.ItemStyle.HorizontalAlign = HorizontalAlign.Center;

                        objBC.HeaderStyle.CssClass = (i == 0 ? "first" : "");
                        objBC.ItemStyle.CssClass = (i == 0 ? "first" : "row");
                        objBC.DataFormatString = WebComponents.FormatString.InputDataType(objDC.DataType.ToString());

                        if (i > 0)
                        {
                            string lstrDataType = objDC.DataType.ToString();
                            switch (lstrDataType)
                            {
                                case "System.Int32":
                                case "System.Double":
                                case "System.Decimal":
                                    objBC.ItemStyle.CssClass = "money";
                                    break;
                                case "System.DateTime":
                                case "System.String":
                                default:
                                    objBC.ItemStyle.CssClass = "row";
                                    break;
                            }
                        }
                        if (i == myTable.Columns.Count - 1) objBC.Visible = false;
                        gvTrackingReport.Columns.Add(objBC);
                    }
                }

                gvTrackingReport.SelectedIndex = -1;

                if (string.IsNullOrEmpty(sortExpression) && direction == null)
                {
                    sortExpression = myTable.Columns[myTable.Columns.Count - 1].ColumnName;
                    direction = " ASC";
                }
                if (!string.IsNullOrEmpty(sortExpression) && direction != null)
                    myTable.DefaultView.Sort = sortExpression + direction;

                gvTrackingReport.AllowPaging = true;
                gvTrackingReport.AllowSorting = true;

                if (myTable.Rows.Count == 0)
                {
                    gvTrackingReport.AllowPaging = false;
                    gvTrackingReport.AllowSorting = false;
                }
                gvTrackingReport.PageIndex = Convert.ToInt32(ViewState[PAGE_INDEX_KEY].ToString());

                gvTrackingReport.DataSource = myTable;
                //ViewState[DETAIL_KEY] = myTable;
                try
                {
                    gvTrackingReport.DataBind();
                    gvTrackingReport.Columns[gvTrackingReport.Columns.Count - 1].Visible = false;
                }
                catch
                {
                    gvTrackingReport.PageIndex = 0;
                    gvTrackingReport.DataBind();
                }
            }
            else
            {
                gvTrackingReport.DataSource = myTable;
                gvTrackingReport.DataBind();
                lblMessage.Text = "No Records Found";
            }
        }
        private SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;
                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }
        protected void gvTrackingReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvTrackingReport.PageIndex = e.NewPageIndex;

            if (ViewState["SortExpression"] == null)
                ViewState["SortExpression"] = string.Empty;

            pBindGrid(ViewState["SortExpression"].ToString(), GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");

            // pBindGrid(null, null);
        }
        protected void gvTrackingReport_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                string sortExpression = e.SortExpression;
                ViewState["SortExpression"] = sortExpression;

                if (GridViewSortDirection == SortDirection.Ascending)
                {
                    GridViewSortDirection = SortDirection.Descending;
                    pBindGrid(sortExpression, " DESC");
                }
                else
                {
                    GridViewSortDirection = SortDirection.Ascending;
                    pBindGrid(sortExpression, " ASC");
                }
            }
            catch
            {
                throw;
            }
        }
        protected void btnCancel_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("../Reports/TrackingReport.aspx");
        }
        protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            ////////////////////////////////////********By Uday on 15/11/2011***************/////////////////////////////////////

            StringBuilder sbTrackSheet = new StringBuilder();

            sbTrackSheet.Append("Select  DISTINCT SUP.SUPNM [Supplier],TM_PO_PONO [PO No],TM_PREALERT_SHPMTNO [Shipment No], REC.SUPNM[Consignee], CASE TM_PREALERT_SHIPMODE "
           + " WHEN 'A' THEN 'Air' WHEN 'O' THEN 'Sea' WHEN 'S' THEN 'Surface' WHEN 'M' THEN 'Multi-Modal' END [Mode],"
            + "TM_PREALERT_CONSOLTYPE [Consolid Type],TM_PREALERT_NOOFPKGS [PKG S],TM_PREALERT_GROSSWEIGHT[GR WT],TD2_PREALERT_CONTAINERNO [Container No],"
            + " ServiceProvider_Name [FF], Carrier_Name [Carrier], M_Country_Name [Origin],S.PortNm [Shipment Port],D.PortNm[Discharge Port],TM_PREALERT_FINALDEST[Final Dest],"
            + " TM_PREALERT_FLTVSLNO [Vessel Voyage Flight], TM_PREALERT_ETD [ETD],TM_PREALERT_ETA [ETA],TM_PREALERT_HBLNO [HAWB HBL],TM_PREALERT_MBLNO [MAWB MBL],"
            + " TM_PREALERT_SHPMTDATE[Shpmt Date],TM_PREALERT_ARRIVALDATE[Arrival Date],TM_PREALERT_DELDATE [Delv Date],");

            if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                sbTrackSheet.Append("'Yet To Be Shipped' [Status] ");
            else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                sbTrackSheet.Append("'In-Transit' [Status] ");
            else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                sbTrackSheet.Append("'Under Custom Clearance' [Status] ");
            else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                sbTrackSheet.Append("'Out For Delivery' [Status] ");
            else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                sbTrackSheet.Append("'Delivered' [Status] ");
            sbTrackSheet.Append(",URL_ServiceProvider [URL ServiceProvider],URL_Carrier [URL Carrier]");

            sbTrackSheet.Append(
             " ,TM_PREALERT_slno FROM (TM_EOU_PREALERT LEFT OUTER JOIN TD2_EOU_PREALERT ON TM_PREALERT_SLNO = TD2_PREALERT_MSLNO) "
            + " INNER JOIN M_COMPANY_BRANCH ON TM_PREALERT_BRNCD=M_COMPANY_BRANCH_CODE"
            + " LEFT OUTER JOIN TD1_EOU_PREALERT ON TM_PREALERT_SLNO = TD1_PREALERT_MSLNO"
            + " LEFT OUTER JOIN (TM_EOU_SUPINV LEFT OUTER JOIN TD1_EOU_SUPINV ON TM_EOU_SUPINV_SLNO = TD1_EOU_SUPINV_TMSLNO) ON TD1_PREALERT_SUPINVNO =TM_EOU_SUPINV_SLNO"
            + " LEFT OUTER JOIN (TM_EOU_PO INNER JOIN TD_EOU_PO ON TM_PO_SLNO=TD_PO_MSLNO) ON TD1_EOU_SUPINV_PO = TM_PO_SLNO"
            + " LEFT OUTER JOIN M_CONSIGNOR SUP  ON SUP.SUPCD = TM_EOU_SUPINV_SUPPLIER"
            + " LEFT OUTER JOIN M_CONSIGNOR REC ON REC.SUPCD = TM_PREALERT_CONSIGNEE"
            + " LEFT OUTER JOIN M_CARRIER ON CARRIER_CODE=TM_PREALERT_CARRIER "
            + " LEFT OUTER JOIN M_SERVICEPROVIDER ON SERVICEPROVIDER_SLNO = TM_PREALERT_FRIEGHTFORWARDER "
            + " LEFT OUTER JOIN M_COUNTRY ON M_Country_Code = TM_PREALERT_COUNTRY  "
            + " LEFT OUTER JOIN M_PORT S ON S.PortCd = TM_PREALERT_SHPMTPORT  "
            + " LEFT OUTER JOIN M_PORT D ON D.PortCd = TM_PREALERT_DISCHARGEPORT"
            + " LEFT OUTER JOIN M_CONTAINER ON TD2_PREALERT_CONTAINERTYPE = CONTAINERCODE ");
            if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Air")
            {
                sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'A'");
            }
            else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Sea")
            {
                sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'O'");
            }
            else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Surface")
            {
                sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'S'");
            }
            else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Multi-Modal")
            {
                sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'M'");
            }
            else
            {
                sbTrackSheet.Append(" WHERE 1 = 1");
            }

            if (LOVSupplier.strLastColumn.Length != 0)
            {
                sbTrackSheet.Append(" AND SUP.SUPCD = " + Int32.Parse(LOVSupplier.strLastColumn.ToString()));
            }
            if (LOVPO.strLastColumn.Length != 0)
            {
                sbTrackSheet.Append(" AND TM_PO_SLNO = " + Int32.Parse(LOVPO.strLastColumn.ToString()));
            }
            if (LOVHAWB.strLastColumn.Length != 0)
            {
                sbTrackSheet.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVHAWB.strLastColumn.ToString()));
            }
            if (LOVMBl.strLastColumn.Length != 0)
            {
                sbTrackSheet.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVMBl.strLastColumn.ToString()));
            }
            if (LOVContanier.strLastColumn.Length != 0)
            {
                sbTrackSheet.Append(" AND TD2_PREALERT_SLNO = " + Int32.Parse(LOVContanier.strLastColumn.ToString()));
            }
            if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
            {
                sbTrackSheet.Append(" AND TM_PREALERT_SHPMTDATE  IS NULL");
            }
            else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
            {
                sbTrackSheet.Append(" AND TM_PREALERT_ARRIVALDATE  IS NULL AND TM_PREALERT_SHPMTDATE IS NOT NULL ");
            }

            else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
            {
                sbTrackSheet.Append(" AND TM_PREALERT_ARRIVALDATE  IS NOT NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NULL ");
            }
            else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
            {
                sbTrackSheet.Append(" AND TM_PREALERT_DELDATE  IS  NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NOT NULL ");
            }
            else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
            {
                sbTrackSheet.Append(" AND TM_PREALERT_DELDATE IS NOT NULL");
            }
            ////////////////////////////////***********By Uday on 15/11/2011********////////////////////////////////////////

            string lstrQuery = null;

            ViewState[TABLE_KEY] = sbTrackSheet;
            //  gvTrackingReport.Columns.Clear();
            pBindGrid(null, null);
            //ddlReport_SelectedIndexChanged(sender, e);
            PExcelReport();
            // btnExcel.Visible = true;
        }
        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlStatus.SelectedItem.Text == "Yet To Be Shipped")
            {
                LOVHAWB.ReadOnly = true;
                LOVMBl.ReadOnly = true;
                LOVContanier.ReadOnly = true;
            }
            else
            {
                LOVHAWB.ReadOnly = false;
                LOVMBl.ReadOnly = false;
                LOVContanier.ReadOnly = false;
            }
        }

        private void pPopulatetoExcel(string lstrQuery, int llngHideColCount)
        {
            DataTable myTable = SQLServerDAL.General.GetDataTable(lstrQuery);

            if (myTable.Rows.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("<table cellspacing=\"0\" cellpadding=\"4\" rules=\"all\" bordercolor=\"#CCCCCC\" border=\"1\" style=\"color:Black;background-color:White;border-color:#CCCCCC;border-width:1px;border-style:Solid;font-family:Tahoma;font-size:8pt;height:24px;border-collapse:collapse;\">");

                sb.Append(" <tr style=\"color:White;background-color:#005500;font-weight:bold;\">");

                sb.Append(" <td align=\"Center\">");
                sb.Append(" Sl.No. ");
                sb.Append(" </td>");

                for (int llngCol = 0; llngCol < myTable.Columns.Count - llngHideColCount; llngCol++)
                {
                    sb.Append(" <td align=\"Center\">");
                    sb.Append(" " + myTable.Columns[llngCol].ColumnName + "");
                    sb.Append(" </td>");
                }

                sb.Append("</tr>");
                int i = 1;
                foreach (DataRow objDR in myTable.Rows)
                {
                    sb.Append(" <tr class=\"body\"> ");
                    sb.Append(" <td align=\"right\">");
                    sb.Append("" + i + "");
                    sb.Append(" </td> ");

                    for (int llngCol = 0; llngCol < myTable.Columns.Count - llngHideColCount; llngCol++)
                    {
                        switch (myTable.Columns[llngCol].DataType.ToString())
                        {
                            case "System.Int32":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Double":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Decimal":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.DateTime":
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + (objDR[llngCol].ToString().Length == 0 ? "" : Convert.ToDateTime(objDR[llngCol].ToString()).ToString("dd-MMM-yyyy")) + "");
                                break;
                            case "System.String":
                                sb.Append(" <td align=\"left\">");
                                sb.Append("" + objDR[llngCol].ToString() + "");
                                break;
                            default:
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                        }
                        sb.Append(" </td>");
                    }
                    sb.Append(" </tr>");
                    i++;
                }
                sb.Append("</table>");

                Response.Clear();
                Response.ClearContent();
                Response.ClearHeaders();
                Response.Charset = "";
                //Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = "application/vnd.xls";
                Response.AddHeader("content-disposition", "attachment; filename=" + lblHeading.InnerText.ToString() + ".xls");
                Response.Write(sb.ToString());
                Response.End();
            }
            else
                lblMessage.Text = "No Records Found";
        }
        private int pGetHideColCount(string lstrQuery)
        {
            int llngHideColCount = 0;

            llngHideColCount = Convert.ToInt32(SQLServerDAL.General.GetObject(lstrQuery));

            return llngHideColCount;
        }
        protected void btnExcel_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            PExcelReport();
            string lstrQuery = null;
            lstrQuery = Convert.ToString(ViewState[EXCEL_KEY]);
            pPopulatetoExcel(lstrQuery, 1);
        }
        private void PExcelReport()
        {
            string GridQuery = null;
            string lstrQuery = null;
            if (ViewState[TABLE_KEY] == null)
                ViewState[TABLE_KEY] = "NULL STRING";
            GridQuery = ViewState[TABLE_KEY].ToString();
            switch (ddlReport.SelectedItem.Text.ToString())
            {
                case "Shipment":
                    StringBuilder sbTrackSheet = new StringBuilder();

                    sbTrackSheet.Append("Select  DISTINCT SUP.SUPNM [Supplier],TM_PO_PONO [PO No],TD1_EOU_SUPINV_BUYERREF [Buyer Ref No],TM_PREALERT_SHPMTNO [Shipment No], REC.SUPNM[Consignee], CASE TM_PREALERT_SHIPMODE "
                   + " WHEN 'A' THEN 'Air' WHEN 'O' THEN 'Sea' WHEN 'S' THEN 'Surface' WHEN 'M' THEN 'Multi-Modal' END [Mode],"
                    + "TM_PREALERT_CONSOLTYPE [Consolid Type],TM_PREALERT_NOOFPKGS [PKG S],TM_PREALERT_GROSSWEIGHT[GR WT],TD2_PREALERT_CONTAINERNO [Container No],"//TypeCode [Container Type]
                    + " ServiceProvider_Name [FF], Carrier_Name [Carrier], M_Country_Name [Origin],S.PortNm [Shipment Port],D.PortNm[Discharge Port],TM_PREALERT_FINALDEST[Final Dest],"
                    + " TM_PREALERT_FLTVSLNO [Vessel Voyage Flight], TM_PREALERT_ETD [ETD],TM_PREALERT_ETA [ETA],TM_PREALERT_HBLNO [HAWB HBL],TM_PREALERT_MBLNO [MAWB MBL],"
                    + " TM_PREALERT_SHPMTDATE[Shpmt Date],TM_PREALERT_ARRIVALDATE[Arrival Date],TM_PREALERT_DELDATE [Delv Date],");

                    if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                        sbTrackSheet.Append("'Yet To Be Shipped' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                        sbTrackSheet.Append("'In-Transit' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                        sbTrackSheet.Append("'Under Custom Clearance' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                        sbTrackSheet.Append("'Out For Delivery' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                        sbTrackSheet.Append("'Delivered' [Status] ");

                    sbTrackSheet.Append(
                     " ,TM_PREALERT_slno FROM (TM_EOU_PREALERT LEFT OUTER JOIN TD2_EOU_PREALERT ON TM_PREALERT_SLNO = TD2_PREALERT_MSLNO) "
                    + " INNER JOIN M_COMPANY_BRANCH ON TM_PREALERT_BRNCD=M_COMPANY_BRANCH_CODE"
                    + " LEFT OUTER JOIN TD1_EOU_PREALERT ON TM_PREALERT_SLNO = TD1_PREALERT_MSLNO"
                    + " LEFT OUTER JOIN (TM_EOU_SUPINV LEFT OUTER JOIN TD1_EOU_SUPINV ON TM_EOU_SUPINV_SLNO = TD1_EOU_SUPINV_TMSLNO) ON TD1_PREALERT_SUPINVNO =TM_EOU_SUPINV_SLNO"
                    + " LEFT OUTER JOIN (TM_EOU_PO INNER JOIN TD_EOU_PO ON TM_PO_SLNO=TD_PO_MSLNO) ON TD1_EOU_SUPINV_PO = TM_PO_SLNO"
                    + " LEFT OUTER JOIN M_CONSIGNOR SUP  ON SUP.SUPCD = TM_EOU_SUPINV_SUPPLIER"
                    + " LEFT OUTER JOIN M_CONSIGNOR REC ON REC.SUPCD = TM_PREALERT_CONSIGNEE"
                    + " LEFT OUTER JOIN M_CARRIER ON CARRIER_CODE=TM_PREALERT_CARRIER "
                    + " LEFT OUTER JOIN M_SERVICEPROVIDER ON SERVICEPROVIDER_SLNO = TM_PREALERT_FRIEGHTFORWARDER "
                    + " LEFT OUTER JOIN M_COUNTRY ON M_Country_Code = TM_PREALERT_COUNTRY  "
                    + " LEFT OUTER JOIN M_PORT S ON S.PortCd = TM_PREALERT_SHPMTPORT  "
                    + " LEFT OUTER JOIN M_PORT D ON D.PortCd = TM_PREALERT_DISCHARGEPORT"
                    + " LEFT OUTER JOIN M_CONTAINER ON TD2_PREALERT_CONTAINERTYPE = CONTAINERCODE ");
                    if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Air")
                    {
                        sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'A'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Sea")
                    {
                        sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'O'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Surface")
                    {
                        sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'S'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Multi-Modal")
                    {
                        sbTrackSheet.Append(" WHERE TM_PREALERT_SHIPMODE = 'M'");
                    }
                    else
                    {
                        sbTrackSheet.Append(" WHERE 1 = 1");
                    }

                    if (LOVSupplier.strLastColumn.Length != 0)
                    {
                        sbTrackSheet.Append(" AND SUP.SUPCD = " + Int32.Parse(LOVSupplier.strLastColumn.ToString()));
                    }
                    if (LOVPO.strLastColumn.Length != 0)
                    {
                        sbTrackSheet.Append(" AND TM_PO_SLNO = " + Int32.Parse(LOVPO.strLastColumn.ToString()));
                    }
                    if (LOVHAWB.strLastColumn.Length != 0)
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVHAWB.strLastColumn.ToString()));
                    }
                    if (LOVMBl.strLastColumn.Length != 0)
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVMBl.strLastColumn.ToString()));
                    }
                    if (LOVContanier.strLastColumn.Length != 0)
                    {
                        sbTrackSheet.Append(" AND TD2_PREALERT_SLNO = " + Int32.Parse(LOVContanier.strLastColumn.ToString()));
                    }
                    if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_SHPMTDATE  IS NULL");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_ARRIVALDATE  IS NULL AND TM_PREALERT_SHPMTDATE IS NOT NULL ");
                    }

                    else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_ARRIVALDATE  IS NOT NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NULL ");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_DELDATE  IS  NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NOT NULL ");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                    {
                        sbTrackSheet.Append(" AND TM_PREALERT_DELDATE IS NOT NULL");
                    }
                    lstrQuery = sbTrackSheet.ToString();
                    //lstrQuery = GridQuery;
                    break;

                case "Shipment+Invoice":
                    ////////////////////////////////***********If Invoice Details Needed ******//////////////////////////////////////
                    StringBuilder sbTrackSheetwithInv = new StringBuilder();

                    sbTrackSheetwithInv.Append("Select DISTINCT SUP.SUPNM [Supplier],TM_PO_PONO [PO No],TD1_EOU_SUPINV_BUYERREF [Buyer Ref No],TM_PREALERT_SHPMTNO [Shipment No], REC.SUPNM[Consignee], CASE TM_PREALERT_SHIPMODE "
                    + " WHEN 'A' THEN 'Air' WHEN 'O' THEN 'Sea' WHEN 'S' THEN 'Surface' WHEN 'M' THEN 'Multi-Modal' END [Mode],"
                    + " TM_PREALERT_CONSOLTYPE [Consolid Type],TM_PREALERT_NOOFPKGS [PKG S],TM_PREALERT_GROSSWEIGHT[GR WT],TD2_PREALERT_CONTAINERNO [Container No]," //TD2_PREALERT_CONTAINERNO [Container No],"
                    + " ServiceProvider_Name [FF], Carrier_Name [Carrier], M_Country_Name [Origin],S.PortNm [Shipment Port],D.PortNm[Discharge Port],TM_PREALERT_FINALDEST[Final Dest],"
                    + " TM_PREALERT_FLTVSLNO [Vessel Voyage Flight], TM_PREALERT_ETD [ETD],TM_PREALERT_ETA [ETA],TM_PREALERT_HBLNO [HAWB HBL],TM_PREALERT_MBLNO [MAWB MBL],"
                    + " TM_PREALERT_SHPMTDATE[Shpmt Date],TM_PREALERT_ARRIVALDATE[Arrival Date],TM_PREALERT_DELDATE [Delv Date],TM_EOU_SUPINV_INVNO [INV NO],TM_EOU_SUPINV_INVDATE [INV DATE],M_CURRENCY_SNAME [CUR],DBO.InvValue(TM_EOU_SUPINV_INVNO,SUP.SUPNM)[Inv Value], ");

                    if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                        sbTrackSheetwithInv.Append("'Yet To Be Shipped' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                        sbTrackSheetwithInv.Append("'In-Transit' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                        sbTrackSheetwithInv.Append("'Under Custom Clearance' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                        sbTrackSheetwithInv.Append("'Out For Delivery' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                        sbTrackSheetwithInv.Append("'Delivered' [Status] ");
                    sbTrackSheetwithInv.Append(
                     " ,tm_prealert_slno FROM (TM_EOU_PREALERT LEFT OUTER JOIN TD2_EOU_PREALERT ON TM_PREALERT_SLNO = TD2_PREALERT_MSLNO) "
                    + " INNER JOIN M_COMPANY_BRANCH ON TM_PREALERT_BRNCD=M_COMPANY_BRANCH_CODE"
                    + " LEFT OUTER JOIN TD1_EOU_PREALERT ON TM_PREALERT_SLNO = TD1_PREALERT_MSLNO"
                    + " LEFT OUTER JOIN (TM_EOU_SUPINV LEFT OUTER JOIN TD1_EOU_SUPINV ON TM_EOU_SUPINV_SLNO = TD1_EOU_SUPINV_TMSLNO) ON TD1_PREALERT_SUPINVNO =TM_EOU_SUPINV_SLNO "
                        //+ " LEFT OUTER JOIN TD2_EOU_SUPINV ON TM_EOU_SUPINV_SLNO = TD2_EOU_SUPINV_MSLNO "
                    + " LEFT OUTER JOIN (TM_EOU_PO INNER JOIN TD_EOU_PO ON TM_PO_SLNO=TD_PO_MSLNO) ON TD1_EOU_SUPINV_PO = TM_PO_SLNO"
                    + " LEFT OUTER JOIN M_CONSIGNOR SUP  ON SUP.SUPCD = TM_EOU_SUPINV_SUPPLIER"
                    + " LEFT OUTER JOIN M_CONSIGNOR REC ON REC.SUPCD = TM_PREALERT_CONSIGNEE"
                    + " LEFT OUTER JOIN M_CARRIER ON CARRIER_CODE=TM_PREALERT_CARRIER "
                    + " LEFT OUTER JOIN M_SERVICEPROVIDER ON SERVICEPROVIDER_SLNO = TM_PREALERT_FRIEGHTFORWARDER "
                    + " LEFT OUTER JOIN M_COUNTRY ON M_Country_Code = TM_PREALERT_COUNTRY  "
                    + " LEFT OUTER JOIN M_PORT S ON S.PortCd = TM_PREALERT_SHPMTPORT  "
                    + " LEFT OUTER JOIN M_PORT D ON D.PortCd = TM_PREALERT_DISCHARGEPORT"
                    + " LEFT OUTER JOIN M_CURRENCY ON TM_EOU_SUPINV_CURRENCY=M_CURRENCY_CODE"
                    + " LEFT OUTER JOIN M_CONTAINER ON TD2_PREALERT_CONTAINERTYPE = CONTAINERCODE ");
                    if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Air")
                    {
                        sbTrackSheetwithInv.Append(" WHERE TM_PREALERT_SHIPMODE = 'A'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Sea")
                    {
                        sbTrackSheetwithInv.Append(" WHERE TM_PREALERT_SHIPMODE = 'O'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Surface")
                    {
                        sbTrackSheetwithInv.Append(" WHERE TM_PREALERT_SHIPMODE = 'S'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Multi-Modal")
                    {
                        sbTrackSheetwithInv.Append(" WHERE TM_PREALERT_SHIPMODE = 'M'");
                    }
                    else
                    {
                        sbTrackSheetwithInv.Append(" WHERE 1 = 1");
                    }

                    if (LOVSupplier.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithInv.Append(" AND SUP.SUPCD = " + Int32.Parse(LOVSupplier.strLastColumn.ToString()));
                    }
                    if (LOVPO.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PO_SLNO = " + Int32.Parse(LOVPO.strLastColumn.ToString()));
                    }
                    if (LOVHAWB.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVHAWB.strLastColumn.ToString()));
                    }
                    if (LOVMBl.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVMBl.strLastColumn.ToString()));
                    }
                    if (LOVContanier.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithInv.Append(" AND TD2_PREALERT_SLNO = " + Int32.Parse(LOVContanier.strLastColumn.ToString()));
                    }
                    if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_SHPMTDATE  IS NULL");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_ARRIVALDATE  IS NULL AND TM_PREALERT_SHPMTDATE IS NOT NULL ");
                    }

                    else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_ARRIVALDATE  IS NOT NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NULL ");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_DELDATE  IS  NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NOT NULL ");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                    {
                        sbTrackSheetwithInv.Append(" AND TM_PREALERT_DELDATE IS NOT NULL");
                    }
                    ////////////////////////////////***********If Invoice Details Needed******//////////////////////////////////////

                    lstrQuery = sbTrackSheetwithInv.ToString();
                    break;
                case "Shipment+Invoice+Items":
                    ////////////////////////////////***********If Item Details Needed ******//////////////////////////////////////
                    StringBuilder sbTrackSheetwithItem = new StringBuilder();

                    sbTrackSheetwithItem.Append("Select   DISTINCT  SUP.SUPNM [Supplier],TM_PO_PONO [PO No],TD1_EOU_SUPINV_BUYERREF [Buyer Ref No],TM_PREALERT_SHPMTNO [Shipment No], REC.SUPNM[Consignee], CASE TM_PREALERT_SHIPMODE "
                    + " WHEN 'A' THEN 'Air' WHEN 'O' THEN 'Sea' WHEN 'S' THEN 'Surface' WHEN 'M' THEN 'Multi-Modal' END [Mode],"
                    + " TM_PREALERT_CONSOLTYPE [Consolid Type],TM_PREALERT_NOOFPKGS [PKG S],TM_PREALERT_GROSSWEIGHT[GR WT],TD2_PREALERT_CONTAINERNO [Container No],"
                    + " ServiceProvider_Name [FF], Carrier_Name [Carrier], M_Country_Name [Origin],S.PortNm [Shipment Port],D.PortNm[Discharge Port],TM_PREALERT_FINALDEST[Final Dest],"
                    + " TM_PREALERT_FLTVSLNO [Vessel Voyage Flight], TM_PREALERT_ETD [ETD],TM_PREALERT_ETA [ETA],TM_PREALERT_HBLNO [HAWB HBL],TM_PREALERT_MBLNO [MAWB MBL],"
                    + " TM_PREALERT_SHPMTDATE[Shpmt Date],TM_PREALERT_ARRIVALDATE[Arrival Date],TM_PREALERT_DELDATE [Delv Date],TM_EOU_SUPINV_INVNO [INV NO],TM_EOU_SUPINV_INVDATE [INV DATE],M_CURRENCY_SNAME [CUR],PARTCODE, ITEMNM, TD2_EOU_SUPINV_QTY [QTY SHIPPED],UOM,");

                    if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                        sbTrackSheetwithItem.Append("'Yet To Be Shipped' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                        sbTrackSheetwithItem.Append("'In-Transit' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                        sbTrackSheetwithItem.Append("'Under Custom Clearance' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                        sbTrackSheetwithItem.Append("'Out For Delivery' [Status] ");
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                        sbTrackSheetwithItem.Append("'Delivered' [Status] ");

                    sbTrackSheetwithItem.Append(
                     " , tm_prealert_slno FROM (TM_EOU_PREALERT LEFT OUTER JOIN TD2_EOU_PREALERT ON TM_PREALERT_SLNO = TD2_PREALERT_MSLNO) "
                    + " INNER JOIN M_COMPANY_BRANCH ON TM_PREALERT_BRNCD=M_COMPANY_BRANCH_CODE"
                    + " LEFT OUTER JOIN TD1_EOU_PREALERT ON TM_PREALERT_SLNO = TD1_PREALERT_MSLNO"
                    + " LEFT OUTER JOIN (TM_EOU_SUPINV LEFT OUTER JOIN TD1_EOU_SUPINV ON TM_EOU_SUPINV_SLNO = TD1_EOU_SUPINV_TMSLNO) ON TD1_PREALERT_SUPINVNO =TM_EOU_SUPINV_SLNO "
                    + " LEFT OUTER JOIN TD2_EOU_SUPINV ON TM_EOU_SUPINV_SLNO = TD2_EOU_SUPINV_TMSLNO "
                    + " LEFT OUTER JOIN (TM_EOU_PO INNER JOIN TD_EOU_PO ON TM_PO_SLNO=TD_PO_MSLNO) ON TD1_EOU_SUPINV_PO = TM_PO_SLNO"
                    + " LEFT OUTER JOIN M_CONSIGNOR SUP  ON SUP.SUPCD = TM_EOU_SUPINV_SUPPLIER"
                    + " LEFT OUTER JOIN M_CONSIGNOR REC ON REC.SUPCD = TM_PREALERT_CONSIGNEE"
                    + " LEFT OUTER JOIN M_ITEM ON ITEMCD= TD2_EOU_SUPINV_ITEM "
                    + " LEFT OUTER JOIN M_UOM ON m_uom.UOMCD= M_ITEM.UOMCD"
                    + " LEFT OUTER JOIN M_CARRIER ON CARRIER_CODE=TM_PREALERT_CARRIER "
                    + " LEFT OUTER JOIN M_SERVICEPROVIDER ON SERVICEPROVIDER_SLNO = TM_PREALERT_FRIEGHTFORWARDER "
                    + " LEFT OUTER JOIN M_COUNTRY ON M_Country_Code = TM_PREALERT_COUNTRY  "
                    + " LEFT OUTER JOIN M_PORT S ON S.PortCd = TM_PREALERT_SHPMTPORT  "
                    + " LEFT OUTER JOIN M_PORT D ON D.PortCd = TM_PREALERT_DISCHARGEPORT"
                    + " LEFT OUTER JOIN M_CURRENCY ON TM_EOU_SUPINV_CURRENCY=M_CURRENCY_CODE"
                    + " LEFT OUTER JOIN M_CONTAINER ON TD2_PREALERT_CONTAINERTYPE = CONTAINERCODE ");
                    if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Air")
                    {
                        sbTrackSheetwithItem.Append(" WHERE TM_PREALERT_SHIPMODE = 'A'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Sea")
                    {
                        sbTrackSheetwithItem.Append(" WHERE TM_PREALERT_SHIPMODE = 'O'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Surface")
                    {
                        sbTrackSheetwithItem.Append(" WHERE TM_PREALERT_SHIPMODE = 'S'");
                    }
                    else if (ddlModeOfShipment.SelectedItem.Text.ToString() == "Multi-Modal")
                    {
                        sbTrackSheetwithItem.Append(" WHERE TM_PREALERT_SHIPMODE = 'M'");
                    }
                    else
                    {
                        sbTrackSheetwithItem.Append(" WHERE 1 = 1");
                    }

                    if (LOVSupplier.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithItem.Append(" AND SUP.SUPCD = " + Int32.Parse(LOVSupplier.strLastColumn.ToString()));
                    }
                    if (LOVPO.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PO_SLNO = " + Int32.Parse(LOVPO.strLastColumn.ToString()));
                    }
                    if (LOVHAWB.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVHAWB.strLastColumn.ToString()));
                    }
                    if (LOVMBl.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_SLNO = " + Int32.Parse(LOVMBl.strLastColumn.ToString()));
                    }
                    if (LOVContanier.strLastColumn.Length != 0)
                    {
                        sbTrackSheetwithItem.Append(" AND TD2_PREALERT_SLNO = " + Int32.Parse(LOVContanier.strLastColumn.ToString()));
                    }
                    if (ddlStatus.SelectedItem.Text.ToString() == "Yet To Be Shipped")
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_SHPMTDATE  IS NULL");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "In-Transit")
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_ARRIVALDATE  IS NULL AND TM_PREALERT_SHPMTDATE IS NOT NULL ");
                    }

                    else if (ddlStatus.SelectedItem.Text.ToString() == "Under Custom Clearance")
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_ARRIVALDATE  IS NOT NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NULL ");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Out For Delivery")
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_DELDATE  IS  NULL AND TM_PREALERT_CUSTOMSCLEARDATE IS NOT NULL ");
                    }
                    else if (ddlStatus.SelectedItem.Text.ToString() == "Delivered")
                    {
                        sbTrackSheetwithItem.Append(" AND TM_PREALERT_DELDATE IS NOT NULL");
                    }

                    lstrQuery = sbTrackSheetwithItem.ToString();
                    ////////////////////////////////***********If Item Details Needed******//////////////////////////////////////

                    //lstrQuery = sbTrackSheetwithItem.ToString();
                    //////////////////////////////////***********If Item Details Needed******//////////////////////////////////////
                    break;
                case "Contanier":
                    break;
            }
            ViewState[EXCEL_KEY] = lstrQuery;
        }
        protected void gvTrackingReport_PreRender(object sender, EventArgs e)
        {
            try
            {
                if (gvTrackingReport.PageCount == 1)
                    gvTrackingReport.PagerSettings.Visible = true;
                else
                    gvTrackingReport.PagerSettings.Visible = true;
            }
            catch
            {
                throw;
            }
        }
    }
}
