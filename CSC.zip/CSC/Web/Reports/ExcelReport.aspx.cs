﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Text;

using ISPL.CSC.SQLServerDAL;

namespace ISPL.CSC.Web.Reports
{
    public partial class ExcelReport : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            pSetDates();

            if (!IsPostBack)
            {
                pSetUserControls();
                lblReportName.Visible = false;
                ddlReportName.Visible = false;

                switch (MenuID.ToString())
                {
                    case "15":	
                        lblHeading.InnerText = "Packing List";
                        lblModel.Visible = true;
                        lblModel.Text = "Delivery Challan";
                        LOVModel.Visible = true;
                        lblRMA.Visible = false;
                        LOVRMA.Visible = false;
                        pDisplayDate(false);
                        lblDate.Visible = false;
                        ddlDate.Visible = false;
                        break;

                    case "16":
                        lblHeading.InnerText = "RMA Tracker";
                        lblModel.Visible = true;
                        lblModel.Text = "Model No";
                        LOVModel.Visible = true;
                        lblRMA.Visible = true;
                        lblRMA.Text = "RMA No";
                        LOVRMA.Visible = true;
                        pDisplayDate(false);
                        lblDate.Visible = true;
                        ddlDate.Visible = true ;
                        LOVModel.Required = false;
                        LOVRMA.Required = false;
                        break;
 
                    case "18":
                        lblHeading.InnerText = "RMA Order";
                        lblModel.Visible = true;
                        lblModel.Text = "Model No";
                        LOVModel.Visible = true;
                        lblRMA.Visible = false;
                        LOVRMA.Visible = false;
                        pDisplayDate(false);
                        lblDate.Visible = true;
                        ddlDate.Visible = true;
                        LOVModel.Required = false;
                        break;
                    case "19":
                        lblHeading.InnerText = "Exception Handler";
                        lblModel.Visible = false;
                        //lblModel.Text = "Model No";
                        LOVModel.Visible = false;
                        lblRMA.Visible = false;
                        LOVRMA.Visible = false;
                        pDisplayDate(false);
                        lblDate.Visible = false;
                        ddlDate.Visible = false;
                        LOVModel.Required = false;
                        LOVRMA.Required = false;
                        break;

                    case "31":
                        lblHeading.InnerText = "Send Order Detail";
                        lblModel.Visible = false;
                        //lblModel.Text = "Model No";
                        LOVModel.Visible = false;
                        lblRMA.Visible = true;
                        lblRMA.Text = "RMA No";
                        LOVRMA.Visible = true;
                        pDisplayDate(false);
                        lblDate.Visible = true;
                        ddlDate.Visible = true;
                        LOVModel.Required = false;
                        LOVRMA.Required = false;
                        break;

 

                }
                pListDates();
            }
            
            lblStatus.Text = string.Empty;
            //lblStatus.Visible = false;
        }
        private void pSetDates()
        {
            dtpFrom.MinDate = null;
            dtpFrom.MaxDate = dtpTo.ClientID;

            dtpTo.MinDate = dtpFrom.ClientID;
            dtpTo.MaxDate = null;
        }
        private void pDisplayDate(bool flg)
        {
            lblFrom.Visible = flg;
            lblTo.Visible = flg;
            dtpFrom.Visible = flg;
            dtpTo.Visible = flg;
            dtpFrom.Required = flg;
            dtpTo.Required = flg;
        }
        private void pSetUserControls()
        {
            dtpFrom.CalendarDate = "01-" + DateTime.Today.ToString("MMM-yyyy");
            dtpTo.CalendarDate = Convert.ToDateTime("01-" + (DateTime.Today.AddMonths(1)).ToString("MMM-yyyy")).AddDays(-1).ToString("dd-MMM-yyyy");
        }
        private void pListDates()
        {
            ddlDate.Items.Clear();

            switch (MenuID.ToString())
            {
                case "16":
                    ddlDate.Items.Add("All");
                    ddlDate.Items.Add("ReceiptDate");
                   // ddlDate.Items.Add("DCDate");
                    break;

                case "18":
                    ddlDate.Items.Add("All");
                    ddlDate.Items.Add("ConfirmDate");
                    break;

                case "31":
                    ddlDate.Items.Add("All");
                    ddlDate.Items.Add("ConfirmDate");
                    break;
            }
            if (ddlDate.SelectedIndex > 0)
                ddlDate.SelectedIndex = 0;
        }
        protected void ddlDate_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDate.SelectedItem.Text.ToUpper() == "ALL")
                pDisplayDate(false);
            else
                pDisplayDate(true);
        }
        protected void LOVModel_LOVBeforeClick(object sender, EventArgs e)
        {
            StringBuilder sbPO = new StringBuilder();
            switch (MenuID.ToString())
            {
                case "15":
                    sbPO.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(FDHdrSlno,0) > 0 ");
                    break;
                case "16":
                    sbPO.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(OrdSlno,0) > 0 ");
                    break;
                case "18":
                    sbPO.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString());
                    break;
                //case "31":
                //    sbPO.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(OrderSlno,0) > 0 ");
                //    break;
                default:
                    sbPO.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(CartSlno,0) > 0 ");
                    break;


            }
             switch (MenuID.ToString())
            {
                case "16":
                    if (LOVRMA.strFirstColumn != "")
                    {
                        sbPO.Append(" AND [RMANo] = '" + LOVRMA.strFirstColumn.Split('|')[0].Trim() + "'");
                    }
                    break;
                    //  case "31":
                    //if (LOVRMA.strFirstColumn != "")
                    //{
                    //    sbPO.Append(" AND [RMANumber] = '" + LOVRMA.strFirstColumn.Split('|')[0].Trim() + "'");
                    //}
                    //break;
                     
                default:
                    if (LOVRMA.strFirstColumn != "")
                        sbPO.Append(" AND [RMANo] = '" + LOVRMA.strFirstColumn.Split('|')[0].Trim() + "'");
                    break;
            }
             string lstrQuery = string.Empty;
             switch (MenuID.ToString())
             {
                 case "15":
                     lstrQuery = " Select DISTINCT v_PackingList.DCNO as DCNo, v_PackingList.DCDate as DCDate,FDHdrSlno from v_PackingList " + sbPO.ToString();
                     break;
                 case "16":
                     lstrQuery = " Select DISTINCT v_RMATracker.ModelNo as ModelNo, v_RMATracker.ModelDesc as ModelDesc,0 as OrdHdr from v_RMATracker " + sbPO.ToString();
                     //lstrQuery = " Select DISTINCT v_RMATracker1.ModelNo as ModelNo, v_RMATracker1.ModelDesc as ModelDesc,0 as OrdHdr from v_RMATracker1 " + sbPO.ToString();
                     break;
                 case "18":
                     lstrQuery = " Select DISTINCT v_RMAOrder.ModelNo as ModelNo, v_RMAOrder.ModelDesc as ModelDesc,0 as OrdHdr from v_RMAOrder " + sbPO.ToString();
                     break;
                 default:
                     lstrQuery = " Select DISTINCT CARTDETAIL_OUT.MODEL as ModelNo, CARTDETAIL_OUT.MODEL_DESC as ModelDesc,CARTDETAIL_OUT.SlNo as CartSlno  from CARTDETAIL_OUT " + sbPO.ToString();
                     break;
             }
             LOVModel.Query = lstrQuery.ToString();
        }

        protected void LOVRMA_LOVBeforeClick(object sender, EventArgs e)
        {
            StringBuilder sbRMA = new StringBuilder();

            switch (MenuID.ToString())
            {
                case "16":
                    sbRMA.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(OrdSlno,0) > 0 ");
                    break;
                case "31":
                    sbRMA.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(OrderSlno,0) > 0 ");
                    break;
                default:
                    sbRMA.Append(" WHERE BrnCd = " + LoginUserInfo.BranchID.ToString() + " AND ISNULL(OrdSlno,0) > 0 ");
                    break;
            }
            switch (MenuID.ToString())
            {
                case "16":
                    if (LOVModel.strFirstColumn != "")
                    {
                        sbRMA.Append(" AND [ModelNo] = '" + LOVModel.strFirstColumn.Split('|')[0].Trim() + "'");
                    }
                    break;
                default:
                    if (LOVModel.strLastColumn != "")
                        sbRMA.Append(" AND [CartSlno] = " + LOVModel.strLastColumn);
                    break;
            }

            string lstrQuery = string.Empty;

            switch (MenuID.ToString())
            {
                
                case "16":
                    lstrQuery = " Select DISTINCT v_RMATracker.RMANo as RMANo, v_RMATracker.ORDWayBill as ORDWayBill,OrdSlno from v_RMATracker " + sbRMA.ToString();
                    //lstrQuery = " Select DISTINCT v_RMATracker1.RMANo as RMANo, v_RMATracker1.ORDWayBill as ORDWayBill,OrdSlno from v_RMATracker1 " + sbRMA.ToString();
                    break;
                case "31":
                    lstrQuery = " Select DISTINCT v_SendOrder.RMANumber as RMANo,v_SendOrder.OrderModel as MODEL,OrderSlno from v_SendOrder " + sbRMA.ToString();
                    break;
                default:
                    lstrQuery = " Select DISTINCT ORDERHEADER_OUT.RMA_Number as RMANo, ORDERHEADER_OUT.WAYBILL as ORDWayBill,ORDERHEADER_OUT.SlNo as OrdSlno from ORDERHEADER_OUT " + sbRMA.ToString();
                    break;
            }
            LOVRMA.Query = lstrQuery.ToString();
        }

        protected void imgPrint_Click(object sender, ImageClickEventArgs e)
        {
            
            string lstrQuery = string.Empty;
            StringBuilder sb = new StringBuilder();

            switch (MenuID.ToString())
            {
                case "15":
                    lstrQuery = "   SELECT * FROM v_PackingList " + fstrGetWhereCond();
                    pPopulatetoExcel(lstrQuery, pGetHideColCount("SELECT DISTINCT HIDECOLCOUNT FROM v_PackingList"));
                    break;
                case "16":
                    // Below Statements used for multiple records for each RMA and Serial No (based on multiple Symptom & actions)
                    //lstrQuery = "   SELECT * FROM v_RMATracker " + fstrGetWhereCond();
                    //pPopulatetoExcel(lstrQuery, pGetHideColCount("SELECT DISTINCT HIDECOLCOUNT FROM v_RMATracker"));

                    // Below statement used for one record for each RMA & serial No

                    string query = "EXEC Proc_RMATracker " + fstrGetWhereCond();
                    SQLHelper.ExecuteNonQuery(SQLHelper.CONN_STRING(), CommandType.Text, query, null).ToString();
                    pPopulatetoExcel(query, 0);
                    
                    break;
                case "18":
                    lstrQuery = "   SELECT * FROM v_RMAOrder " + fstrGetWhereCond();
                    pPopulatetoExcel(lstrQuery, pGetHideColCount("SELECT DISTINCT HIDECOLCOUNT FROM v_RMAOrder"));
                    break;
                case "19":
                    lstrQuery = "   SELECT * FROM V_Exception_Handler ";
                    pPopulatetoExcel(lstrQuery, pGetHideColCount("SELECT DISTINCT HIDECOLCOUNT FROM V_Exception_Handler"));
                    break;
                case "31":
                    lstrQuery = "   SELECT * FROM v_SendOrder " + fstrGetWhereCond();
                    pPopulatetoExcel(lstrQuery, pGetHideColCount("SELECT DISTINCT HIDECOLCOUNT FROM v_SendOrder"));
                    break; 
            }
        }       
        private void pPopulatetoExcel(string lstrQuery, int llngHideColCount)
        {
            
            DataTable myTable = SQLServerDAL.General.GetDataTable(lstrQuery);
           
                //if (chkTotals.Checked)
                //{

            if (myTable.Rows.Count > 0)//'No records found'
            {
                //DataRow drTotals = myTable.NewRow();//Commented--No need of extra line on reports

                //for (int idrTotals = 0; idrTotals < myTable.Columns.Count; idrTotals++)//changed i to idrTotals
                //{
                //    DataColumn objDC = myTable.Columns[idrTotals];

                //    if (objDC.DataType.ToString() == "System.Double")
                //    {
                //        drTotals[objDC] = myTable.Compute("Sum([" + objDC.ColumnName + "])", "");
                //    }
                //}
                //myTable.Rows.Add(drTotals);

                // }


                StringBuilder sb = new StringBuilder();
                sb.Append("<table cellspacing=\"0\" cellpadding=\"4\" rules=\"all\" bordercolor=\"#CCCCCC\" border=\"1\" style=\"color:Black;background-color:White;border-color:#CCCCCC;border-width:1px;border-style:Solid;font-family:Tahoma;font-size:8pt;height:24px;border-collapse:collapse;\">");

                sb.Append(" <tr style=\"color:White;background-color:#005500;font-weight:bold;\">");

                sb.Append(" <td align=\"Center\">");
                sb.Append(" Sl.No. ");
                sb.Append(" </td>");

                for (int llngCol = 0; llngCol < myTable.Columns.Count - llngHideColCount; llngCol++)
                {
                    sb.Append(" <td align=\"Center\">");
                    sb.Append(" " + myTable.Columns[llngCol].ColumnName + "");
                    sb.Append(" </td>");
                }

                sb.Append("</tr>");
                int i = 1;
                foreach (DataRow objDR in myTable.Rows)
                {
                    sb.Append(" <tr class=\"body\"> ");
                    sb.Append(" <td align=\"right\">");
                    sb.Append("" + i + "");
                    sb.Append(" </td> ");

                    for (int llngCol = 0; llngCol < myTable.Columns.Count - llngHideColCount; llngCol++)
                    {
                        switch (myTable.Columns[llngCol].DataType.ToString())
                        {
                            case "System.Int32":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Double":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.Decimal":
                                sb.Append(" <td align=\"right\">");
                                sb.Append(" " + objDR[llngCol] + "");
                                break;
                            case "System.DateTime":
                                sb.Append(" <td align=\"center\">");
                                sb.Append(" " + (objDR[llngCol].ToString().Length == 0 ? "" : Convert.ToDateTime(objDR[llngCol].ToString()).ToString("dd-MMM-yyyy")) + "");
                                break;
                            case "System.String":
                                sb.Append(" <td align=\"left\">");
                                sb.Append("" + (objDR[llngCol] == DBNull.Value || string.IsNullOrEmpty(objDR[llngCol].ToString()) ? "" : objDR[llngCol].ToString()) + "");
                                break;
                            default:
                                sb.Append(" <td align=\"center\">");
                                sb.Append("" + (objDR[llngCol] == DBNull.Value || string.IsNullOrEmpty(objDR[llngCol].ToString()) ? "" : objDR[llngCol].ToString()) + "");
                                break;
                        }
                        sb.Append(" </td>");
                    }
                    sb.Append(" </tr>");
                    i++;
                }
                sb.Append("</table>");

                Response.Clear();
                Response.ClearContent();
                Response.ClearHeaders();
                Response.Charset = "";
                //Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.ContentType = "application/ms-excel";
                Response.AddHeader("content-disposition", "attachment; filename=" + lblHeading.InnerText.ToString() + ".xls");
                Response.Write(sb.ToString());
                Response.End();
               
            }
            else
            {
                lblStatus.Text = "No Records Found";
                //lblStatus.Visible = true;
            }
        }
        private int pGetHideColCount(string lstrQuery)
        {
            int llngHideColCount = 0;

            llngHideColCount = Convert.ToInt32(SQLServerDAL.General.GetObject(lstrQuery));

            return llngHideColCount;
        }
        private string fstrGetWhereCond()
         {
            StringBuilder sbCondition = new StringBuilder();

            //if (MenuID.ToString() == "16")
            //{
            //    sbCondition.Append( LoginBranchID);


            //    if (LOVRMA.strFirstColumn != "")
            //        sbCondition.Append("," + (LOVRMA.strFirstColumn.Contains("\t") ? LOVRMA.strFirstColumn.Substring(0, LOVRMA.strFirstColumn.IndexOf('\t')) : LOVRMA.strFirstColumn.Trim()));//stored procedure param
            //    else
            //        sbCondition.Append("," + " '' ");

            //    if (LOVModel.strFirstColumn != "")
            //        sbCondition.Append("," +( LOVModel.strFirstColumn.Contains("\t") ? LOVModel.strFirstColumn.Substring(0,LOVModel.strFirstColumn.IndexOf('\t')) : LOVModel.strFirstColumn.Trim()));
            //    else
            //        sbCondition.Append("," + " '' ");

            //     if (dtpFrom.Visible && dtpTo.Visible)
            //         sbCondition.Append(" ,  '" + dtpFrom.CalendarDate + "' , '" + dtpTo.CalendarDate + "'");
            //     else
            //         sbCondition.Append("," + " null , null ");


            //}
            //else if (MenuID.ToString() == "31")
            //{
            //    sbCondition.Append(LoginBranchID);


            //    if (LOVRMA.strFirstColumn != "")
            //        sbCondition.Append("," + (LOVRMA.strFirstColumn.Contains("\t") ? LOVRMA.strFirstColumn.Substring(0, LOVRMA.strFirstColumn.IndexOf('\t')) : LOVRMA.strFirstColumn.Trim()));//stored procedure param
            //    else
            //        sbCondition.Append("," + " '' ");

            //    if (dtpFrom.Visible && dtpTo.Visible)
            //        sbCondition.Append(" ,  '" + dtpFrom.CalendarDate + "' , '" + dtpTo.CalendarDate + "'");
            //    else
            //        sbCondition.Append("," + " null , null ");
            //}
            //else
            //{

                //IFModel Selection
                if (LOVModel.strFirstColumn != "")
                {
                    switch (MenuID.ToString())
                    {
                        case "15":
                            sbCondition.Append(" where [FDHdrSlno] = " + LOVModel.strLastColumn);
                            break;
                        case "16":
                            if (sbCondition.Length > 0)
                                sbCondition.Append(" and [ModelNo] like '%" + LOVModel.strFirstColumn.Trim() + "%'");
                            else
                                sbCondition.Append(" where [ModelNo] like '%" + LOVModel.strFirstColumn.Trim() + "%'");
                            break;


                        case "18":
                            sbCondition.Append(" where [ser status] = 'FD' AND [ModelNo] like '%" + LOVModel.strFirstColumn.Trim() + "%'");
                            break;
                        default:
                            if (sbCondition.Length > 0)
                                sbCondition.Append(" and [ModelNo] like '%" + LOVModel.strFirstColumn.Trim() + "%'");
                            else
                                sbCondition.Append(" where [ModelNo] like '%" + LOVModel.strFirstColumn.Trim() + "%'");
                            break;

                    }
                }

                if (LOVRMA.strFirstColumn != "")
                {
                    switch (MenuID.ToString())
                    {
                        case "16":
                            //if (sbCondition.Length > 0)
                            //    sbCondition.Append(" and [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            //else
                            //    sbCondition.Append(" where [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            //break;
                            if (LOVRMA.strFirstColumn.Length != 0)
                            {
                                if (sbCondition.Length > 0)
                                    sbCondition.Append(" and [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                                else
                                    sbCondition.Append(" where [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            }
                            else
                                sbCondition.Append(" and [RMANo] = '' ");
                            break;

                        case "31":
                            //if (sbCondition.Length > 0)
                            //    sbCondition.Append(" and [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            //else
                            //    sbCondition.Append(" where [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            //break;
                            if (LOVRMA.strFirstColumn.Length != 0)
                            {
                                if (sbCondition.Length > 0)
                                    sbCondition.Append(" and [RMANumber] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                                else
                                    sbCondition.Append(" where [RMANumber] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            }
                            else
                                sbCondition.Append(" and [RMANumber] = '' ");
                            break;

                        default:
                            if (sbCondition.Length > 0)
                                sbCondition.Append(" and [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            else
                                sbCondition.Append(" where [RMANo] like '%" + LOVRMA.strFirstColumn.Trim() + "%'");
                            break;

                    }

                }
                //For Branch  MenuID.ToString() == "16" ||
                if (sbCondition.Length > 0)
                {
                    if (MenuID.ToString() == "15" || MenuID.ToString() == "16" || MenuID.ToString() == "18" || MenuID.ToString() == "31")
                    {
                        sbCondition.Append(" and BrnCd = " + LoginBranchID);
                    }

                    //if (MenuID.ToString() == "16")
                    //{
                    //    sbCondition.Append(" and BrnCd = " + LoginBranchID);
                    //}
                    else
                        sbCondition.Append(" and BrnCd = " + LoginUserInfo.BranchID.ToString());

                }
                else
                {
                    if (MenuID.ToString() == "15")
                    {
                        sbCondition.Append(" where BrnCd = " + LoginBranchID);
                    }
                    if (MenuID.ToString() == "16")
                    {
                        sbCondition.Append(" where BrnCd = " + LoginBranchID);
                    }
                    if (MenuID.ToString() == "18")
                    {
                        sbCondition.Append(" where BrnCd = " + LoginBranchID);
                    }
                    if (MenuID.ToString() == "31")
                    {
                        sbCondition.Append(" where BrnCd = " + LoginBranchID);
                    }
                    //else
                    //    sbCondition.Append(" where BrnCd = " + LoginUserInfo.BranchID.ToString());
                }

                //If Date are selected 
                if (dtpFrom.Visible && dtpTo.Visible)
                {
                    switch (MenuID.ToString())
                    {
                        case "16":
                            sbCondition.Append(fstrGetWhereCondForDate(sbCondition.ToString()));
                            break;
                        case "18":
                            sbCondition.Append(fstrGetWhereCondForDate(sbCondition.ToString()));
                            break;
                        case "31":
                            sbCondition.Append(fstrGetWhereCondForDate(sbCondition.ToString()));
                            break;

                        default:
                            if (sbCondition.Length > 0)
                                sbCondition.Append(" and " + fstrGetDateFieldName(ddlDate.SelectedItem.Text) + " BETWEEN '" + dtpFrom.CalendarDate + "' AND '" + dtpTo.CalendarDate + "'");
                            else
                                sbCondition.Append(" where " + fstrGetDateFieldName(ddlDate.SelectedItem.Text) + " BETWEEN '" + dtpFrom.CalendarDate + "' AND '" + dtpTo.CalendarDate + "'");
                            break;
                    }
                }
            //}
           

            return sbCondition.ToString();
        }
        private string fstrGetWhereCondForDate(string sbCondition)
        {
            if (sbCondition.Length > 0)
                return " and [" + ddlDate.SelectedItem.Text + "] BETWEEN '" + dtpFrom.CalendarDate + "' AND '" + dtpTo.CalendarDate + "'";
            else
                return " where [" + ddlDate.SelectedItem.Text + "] BETWEEN '" + dtpFrom.CalendarDate + "' AND '" + dtpTo.CalendarDate + "'";
        }
        private string fstrGetDateFieldName(string lstrName)
        {
            string strField = "";
            switch (ddlDate.SelectedItem.Text)
            {
                case "ReceiptDate":
                    strField = "[ReceiptDate]";
                    break;
                case "DCDate":
                    strField = "[DCDate]";
                    break;
                case "ConfirmDate":
                    strField = "[ConfirmDate]"; 
                    break;
                //case "Submission Date":
                //    strField = "[Submission Date]";
                //    break;
                //case "Sup Invoice Date":
                //    strField = "[Sup Invoice Date]";
                //    break;
                //case "Shipment Date":
                //    strField = "[Shipment Date]";
                //    break;
                //case "Delivery Date":
                //    strField = "[Delivery Date]";
                //    break;
            }
            return strField;
        }       
        protected void imgCancel_Click(object sender, ImageClickEventArgs e)
        {
            ddlDate.ClearSelection();
            pDisplayDate(false);
            dtpFrom.CalendarDate = string.Empty;
            dtpTo.CalendarDate = string.Empty;
        }
        protected void ddlReportName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlReportName.Visible)
            {
                //if (ddlReportName.SelectedItem.Text == "GL Coding")
                    pDisplayDate(true);                
            }
        }
    }
}
