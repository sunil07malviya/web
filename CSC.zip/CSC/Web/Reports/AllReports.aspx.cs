﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text;

namespace ISPL.CSC.Web.Reports
{
    public partial class AllReports : BasePage
    {
        private const string TRAN_ID_KEY = "TRAN_ID_KEY";

        string sSelectionFormula;
        string sParameter;
        string sFormula;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                pSetUserControls();
                pBindReportNameDDL(MenuID);
            }
        }
        private void pSetUserControls()
        {
            //LOVSignatory.Query = "SELECT M_Signatory_Code [Signatory Code], M_Signatory_Desc1 Desc1, M_Signatory_Desc2 Desc2, M_Signatory_SlNo FROM M_EOU_SIGNATORY ";
            //LOVSignatory.Required = false;

            Model.Masters.MenuInfo myMenuInfo = SQLServerDAL.Masters.Menu.GetMenuInfo(MenuID);

            lblHeading.InnerText = myMenuInfo.Name;
            this.Page.Title = myMenuInfo.Name;

            Model.ReportInfo[] myReportInfos = SQLServerDAL.Report.GetReportInfoByMenuID(MenuID, LoginBranchID);
            ViewState[TRAN_ID_KEY] = myReportInfos[0];

            Model.ReportInfo myReportInfo = myReportInfos[0];

            lblReference.Text = myReportInfo.Caption;

            if (myReportInfo.Enclosure == "Y")
            {
                lstEnclosure.Visible = true;
                lblEnclosures.Visible = true;
            }
            else
            {
                lstEnclosure.Visible = false;
                lblEnclosures.Visible = false;
            }

            switch (MenuID.ToString())
            {
                //case "13":
                //        LOVReferenceNo.Required = true;
                //        LOVReferenceNo.Visible = true;
                       
                //    break;
                //case "50283":
                //    LOVReferenceNo.Required = false;
                //    LOVReferenceNo.Visible = false;
                //    break;
                //case "50320":
                //    LOVReferenceNo.Required = false;
                //    LOVReferenceNo.Visible = false;
                //    break;
                case "13":
                    LOVReferenceNo.Required = true;
                    LOVReferenceNo.Visible = true;

                    string query = string.Empty;

                    query = myReportInfo.Query;
                    query = query.Replace("@BRANCHID", LoginBranchID.ToString());

                    LOVReferenceNo.Query = query;
                    break;
                //case "50077":
                //    lblSignatory.Visible = false;
                //    LOVSignatory.Required = false;
                //    LOVSignatory.Visible = false;
                //    break;
                case "37":
                case "38":
                    lblReference.Visible = false;
                    LOVReferenceNo.Required = false;
                    LOVReferenceNo.Visible = false;
                    break;
                default:
                    LOVReferenceNo.Required = true;
                    query = string.Empty;

                    query = myReportInfo.Query;
                    query = query.Replace("@BRANCHID", LoginBranchID.ToString());

                    LOVReferenceNo.Query = query;
                    break;
            }

            //if (MenuID == 50077)
            //{
            //    lblSignatory.Visible = false;
            //    LOVSignatory.Required = false;
            //    LOVSignatory.Visible = false;
            //}
        }
        private void pDisplayEnclosures(bool flag)
        {
            if (flag)
            {
                string SQL_STRING = " Select M_ENCLR_NAME, M_ENCLR_SLNO from M_EOU_ENCLR where M_ENCLR_BRNCD = " + LoginBranchID.ToString() + " order by M_ENCLR_NAME";


                DataTable myTable = SQLServerDAL.General.GetDataTable(SQL_STRING);

                //				Clear any possible items in the Listbox prior to databinding.
                lstEnclosure.Items.Clear();
                //				Set the DataTextField to the text/data you want to display
                lstEnclosure.DataTextField = "M_ENCLR_NAME";
                //				Set the DataValueField to the Primary Key
                lstEnclosure.DataValueField = "M_ENCLR_SLNO";
                //				Set the DataReader object to the datasource property of the control & bind it				
                lstEnclosure.DataSource = myTable;
                lstEnclosure.DataBind();
            }
            lstEnclosure.Visible = flag;
            lblEnclosures.Visible = flag;
        }
        private void pPrint(bool IsPDF)
        {
            Model.ReportInfo myReportInfo = (Model.ReportInfo)ViewState[TRAN_ID_KEY];

            sParameter = string.Empty;
            int intNoRec;
            int intCtr = 0;
            bool blnIsDirectSale = false;
            string strExtraLines = "";
            string SQL_STRING = string.Empty;

            if (MenuID.ToString() == "13")
            {
                SQL_STRING = "SELECT COUNT (MBL_FD_DTL.Slno) AS noRec FROM MBL_FD_DTL WITH (ROWLOCK) WHERE FD_HDR_SLNO = " + LOVReferenceNo.strLastColumn;
                intNoRec = Convert.ToInt32(SQLServerDAL.General.GetObject(SQL_STRING));
                intCtr = Math.Abs(intNoRec / 3);
            }
            //else if (MenuID.ToString() == "50124")
            //{
            //    SQL_STRING = "select count(TD_DB_Cd) as noRec from TD_EOU_DB WITH (ROWLOCK) where TD_DB_Cd = " + LOVReferenceNo.strLastColumn;
            //    intNoRec = Convert.ToInt32(SQLServerDAL.General.GetObject(SQL_STRING));
            //    intCtr = Math.Abs(intNoRec / 3);
            //    String lstrsql = "[EOSOFT].[SP_DeBondDutyWorkSheet] " + LOVReferenceNo.strLastColumn;
            //    SQLServerDAL.General.ExecuteNonQuery(lstrsql);
            //}
            else
                intCtr = -1;

            switch (intCtr)
            {
                case 1:
                    strExtraLines = "space(44)";
                    sParameter = "{" + strExtraLines + "," + blnIsDirectSale + "}";
                    break;
                case 2:
                    strExtraLines = "space(32)";
                    sParameter = "{" + strExtraLines + "," + blnIsDirectSale + "}";
                    break;
                case 3:
                    strExtraLines = "space(26)";
                    sParameter = "{" + strExtraLines + "," + blnIsDirectSale + "}";
                    break;
                case 4:
                    strExtraLines = "space(20)";
                    sParameter = "{" + strExtraLines + "," + blnIsDirectSale + "}";
                    break;
                case 0:
                    strExtraLines = "space(12)";
                    sParameter = "{" + strExtraLines + "," + blnIsDirectSale + "}";
                    break;
                default:
                    strExtraLines = string.Empty;
                    sParameter = string.Empty;
                    break;
            }

            //1st Report 
            if (MenuID.ToString() == "13")
            {
                string @PreparedBy = LoginUserInfo.UserID;
                sParameter = LoginUserInfo.UserID;
            }
            sFormula = string.Empty;
            sSelectionFormula = "{" + LOVReferenceNo.strLastColumn + "}";

            //if (LOVReferenceNo.strLastColumn.Length > 0 && MenuID != 13 )  //LOVSignatory.strLastColumn.Length > 0 &&
            //    pSaveSignatory(myReportInfo.Signatory);

            if (ddlReportName.SelectedItem.Text.ToUpper() == "ALL")
            {
                for (int i = 1; i < ddlReportName.Items.Count; i++)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.Append("<script language = javascript>");
                    sb.Append("window.open('../Report.aspx?IsPDF=" + (IsPDF ? "1" : "0") + "&ID=" + ddlReportName.Items[i].Value + "&SELFORMULA=" + sSelectionFormula + "&PARAMETER=" + sParameter + "&FORMULA=" + sFormula + "')");
                    sb.Append("</script>");

                    //if (!Page.ClientScript.IsStartupScriptRegistered("report" + ddlReportName.Items[i].Value))
                    //    Page.ClientScript.RegisterStartupScript(this.GetType(), "report" + ddlReportName.Items[i].Value, sb.ToString());
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "report" + ddlReportName.Items[i].Value, sb.ToString(), false);
                }
            }
            else
            {

                StringBuilder sb = new StringBuilder();
                sb.Append("<script language = javascript>");
                sb.Append("window.open('../Report.aspx?IsPDF=" + (IsPDF ? "1" : "0") + "&ID=" + ddlReportName.SelectedValue + "&SELFORMULA=" + sSelectionFormula + "&PARAMETER=" + sParameter + "&FORMULA=" + sFormula + "')");
                sb.Append("</script>");

                //if (!Page.ClientScript.IsStartupScriptRegistered("report"))
                //    Page.ClientScript.RegisterStartupScript(this.GetType(), "report", sb.ToString());
                ScriptManager.RegisterStartupScript(this, this.GetType(), "report", sb.ToString(), false);
            }
        }

        private void pBindReportNameDDL(int MenuID)
        {
            ddlReportName.DataSource = SQLServerDAL.Report.GetReportInfoByMenuID(MenuID, LoginBranchID);
            ddlReportName.DataTextField = "ReportName";
            ddlReportName.DataValueField = "SlNo";
            ddlReportName.DataBind();

            if (ddlReportName.Items.Count != 1)
                ddlReportName.Items.Insert(0, "All");
        }

        private void pSaveEnclosures(string TranType)
        {
            //Enclosures
            if (lstEnclosure.SelectedIndex != -1)
            {
                string lstr = string.Empty;
                foreach (ListItem lstItem in lstEnclosure.Items)
                {
                    if (lstItem.Selected == true)
                    {
                        if (lstr.Length == 0)
                            lstr = lstItem.Value;
                        else
                            lstr += "," + lstItem.Value;
                    }
                }

                SQLServerDAL.General.SaveEnclosures(TranType, Convert.ToInt32(LOVReferenceNo.strLastColumn), lstr.Split(','));
            }
            else
            {

                SQLServerDAL.General.SaveEnclosures(TranType, Convert.ToInt32(LOVReferenceNo.strLastColumn), null);
            }
        }

        //private void pSaveSignatory(string TranType)
        //{

        //    if (LOVSignatory.strLastColumn.Length != 0)
        //        SQLServerDAL.General.UpdateSignatory(TranType, Convert.ToInt32(LOVSignatory.strLastColumn), Convert.ToInt32(LOVReferenceNo.strLastColumn));
        //    else
        //        SQLServerDAL.General.UpdateSignatory(TranType, 0, Convert.ToInt32(LOVReferenceNo.strLastColumn));
        //}

        protected void imgPrint_Click(object sender, ImageClickEventArgs e)
        {
            if (!string.IsNullOrEmpty(LOVReferenceNo.strLastColumn))
                pPrint(false);
            else if (MenuID == 37 || MenuID == 38 || MenuID == 50320)
                pPrint(false);
        }
        protected void btnPDF_Click(object sender, ImageClickEventArgs e)
        {
            if (!string.IsNullOrEmpty(LOVReferenceNo.strLastColumn))
                pPrint(true);
            else if (MenuID == 37 || MenuID == 38 || MenuID == 50320)
                pPrint(true);
        }
        protected void imgCancel_Click(object sender, ImageClickEventArgs e)
        {
            LOVReferenceNo.ClearAll();
            //LOVSignatory.ClearAll();

            ddlReportName.ClearSelection();
        }
    }
}
