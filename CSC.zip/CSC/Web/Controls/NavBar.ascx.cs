﻿using System;
using System.Data;
using System.Web.UI.WebControls;

using ISPL.CSC.Model.Masters;

namespace ISPL.CSC.Web.Controls
{
    public partial class NavBar : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ShowLoggedInArea();
        }
        private void ShowLoggedInArea()
        {
            if (Request.IsAuthenticated != true)
            {
                areaLoggedIn.Visible = false;
                areaLoggedOut.Visible = true;
                ddlFavourites.Visible = false;
            }
            else
            {
                ProcessFlow.AccountController accountController = new ISPL.CSC.Web.ProcessFlow.AccountController();
                BranchInfo myBranch = accountController.GetBranchInfo(false);
                UserInfo myTmpUsrInfo = accountController.GetUserInfo(false);

                if (myBranch == null)
                    myBranch = new BranchInfo();

                if (myTmpUsrInfo == null)
                    myTmpUsrInfo = new UserInfo();

                lblBranch.Text = "Branch:  " + myBranch.ShortName;
                lblUserID.Text = "User:  " + myTmpUsrInfo.UserID;

                areaLoggedIn.Visible = true;
                areaLoggedOut.Visible = false;

                ddlFavourites.Visible = true;

                if (myBranch.BranchID > 0 && !string.IsNullOrEmpty(myTmpUsrInfo.UserID))
                    pLoadFavourites(myTmpUsrInfo.UserID, myBranch.BranchID);
            }
        }
        private void pLoadFavourites(string UserID, int BranchID)
        {
            string lstrQuery = "SELECT G_Favourites_Name, G_Favourites_Value FROM G_Favourites Where G_Favourites_UserID = '" + UserID + "' And G_Favourites_BrnCd = " + BranchID.ToString() + " Order By G_Favourites_Name Asc";
            
            DataTable dt = SQLServerDAL.General.GetDataTable(lstrQuery);

            ddlFavourites.Items.Clear();
            ddlFavourites.Items.Add(new ListItem("-- Favourites --", ""));

            foreach (DataRow dr in dt.Rows)
            {
                ddlFavourites.Items.Add(new ListItem(dr[0].ToString(), dr[1].ToString()));
            }
        }
    }
}