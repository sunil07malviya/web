﻿using System;
using System.Data;
using System.Web.UI;


using ISPL.CSC.Model.Masters;
using ISPL.CSC.SQLServerDAL;
using System.Web.UI.WebControls;

namespace ISPL.CSC.Web.Controls
{
    public partial class LOVPage : BasePage
    {
        private const string QUERY_KEY = "QUERY";

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);

            string strScript1;
            strScript1 = "var myRetValue = new Object(); myRetValue.FirstColumn = document.forms[0].hdnFirstColID.value; myRetValue.LastColumn = document.forms[0].hdnCode.value; ";
            strScript1 += " window.returnValue = myRetValue; window.close(); ";

            btnSubmit.Attributes.Add("onclick", strScript1);
            string strScript2;
            strScript2 = "var myRetValue = new Object(); myRetValue.FirstColumn = ''; myRetValue.LastColumn = ''; ";
            strScript2 += " window.returnValue = myRetValue; window.close(); ";

            btnCancel.Attributes.Add("onclick", strScript2);
            string CacheKey = Request["UNQ"].ToString();
            LOVBase myLOVBase = (LOVBase)this.Cache[Server.HtmlDecode(CacheKey)];

            if (myLOVBase == null)
                return;

            ViewState[QUERY_KEY] = myLOVBase.Query;

            if (String.IsNullOrEmpty(myLOVBase.MasterMenuID))
                lnkAdd.Visible = false;
            else
            {
                LOVViewInfo myLOVViewInfo = SQLServerDAL.Masters.LOVView.GetLOVViewInfo(Convert.ToInt32(myLOVBase.MasterMenuID));

                if (myLOVViewInfo != null)
                {
                    lnkAdd.Visible = true;
                    string lstrURL = this.TemplateSourceDirectory.Remove(this.TemplateSourceDirectory.LastIndexOf("/"), this.TemplateSourceDirectory.Length - this.TemplateSourceDirectory.LastIndexOf("/"));
                    lstrURL += "/" + myLOVViewInfo.Page + "0&MenuID=" + myLOVBase.MasterMenuID + "&_Type=LOV";
                    lnkAdd.Attributes.Add("onclick", "window.open('" + lstrURL + "')");
                }
            }

            pBindDatatoGrid();
        }

        private void pBindDatatoGrid()
        {
            DataTable dt1 = new DataTable();
            string Query = string.Empty;

            try
            {
                if (ViewState[QUERY_KEY] != null)
                    dt1 = General.GetDataTable(ViewState[QUERY_KEY].ToString());
                else
                    dt1 = null;
            }
            catch
            {
            }

            if (dt1 == null)
            {
                return;
            }
            dt1.DefaultView.RowFilter = "";
            ViewState["PageCaption"] = "Total Record(s): " + dt1.Rows.Count.ToString();

            string lstrRowFilter = string.Empty;
            if (txtSearchText.Text.Length != 0)
            {
                string lstrSearchText = txtSearchText.Text.Replace("[", "").Replace("]", "").Trim();

                if (string.IsNullOrEmpty(SortExpression))
                {
                    foreach (DataColumn objDC in dt1.Columns)
                    {
                        switch (objDC.DataType.ToString())
                        {
                            case "System.String":
                                if (lstrRowFilter.Length == 0)
                                    lstrRowFilter = "([" + objDC.ColumnName + "] LIKE '*" + lstrSearchText + "*'";
                                else
                                    lstrRowFilter += " OR [" + objDC.ColumnName + "] LIKE '*" + lstrSearchText + "*'";
                                break;
                            case "System.Int32":
                            case "System.Double":
                                double ltmpNumber = 0;
                                try
                                {
                                    ltmpNumber = Convert.ToDouble(lstrSearchText);
                                }
                                catch
                                {
                                    ltmpNumber = 0;
                                }
                                if (ltmpNumber > 0)
                                {
                                    if (lstrRowFilter.Length == 0)
                                        lstrRowFilter = "([" + objDC.ColumnName + "] = " + lstrSearchText + "";
                                    else
                                        lstrRowFilter += " OR [" + objDC.ColumnName + "] = " + lstrSearchText + "";
                                }
                                break;
                        }
                    }
                }
                else
                {
                    int colIndex = -1;
                    foreach (DataControlField tmpDC in gvDetails.Columns)
                    {
                        if (tmpDC.SortExpression == SortExpression)
                        {
                            colIndex = gvDetails.Columns.IndexOf(tmpDC);
                            break;
                        }
                    }

                    DataColumn objDC = dt1.Columns[colIndex];
                    switch (objDC.DataType.ToString())
                    {
                        case "System.String":
                            lstrRowFilter = "([" + objDC.ColumnName + "] LIKE '*" + lstrSearchText + "*'";
                            break;
                        case "System.Int32":
                        case "System.Double":
                            lstrRowFilter = "([" + objDC.ColumnName + "] = " + lstrSearchText + "";
                            break;
                    }
                }
                lstrRowFilter += lstrRowFilter.Length > 0 ? ")" : "";
                dt1.DefaultView.RowFilter = lstrRowFilter;
            }
            if (dt1.DefaultView.RowFilter.Length != 0)
            {
                ViewState["PageCaption"] += "&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp;&nbsp;Filtered: " + dt1.DefaultView.Count.ToString();
            }
            gvDetails.DataKeyNames = new string[] { dt1.Columns[dt1.Columns.Count - 1].ColumnName };

            gvDetails.Columns.Clear();
            for (int i = 0; i < dt1.Columns.Count - 1; i++)
            {
                DataColumn objDC = dt1.Columns[i];

                BoundField objBC = new BoundField();
                objBC.DataField = objDC.ColumnName;
                objBC.HeaderText = objDC.ColumnName;
                objBC.SortExpression = objDC.ColumnName;

                objBC.HeaderStyle.HorizontalAlign = HorizontalAlign.Center;
                objBC.ItemStyle.HorizontalAlign = HorizontalAlign.Center;

                objBC.HeaderStyle.CssClass = (i == 0 ? "first" : "");
                objBC.ItemStyle.CssClass = (i == 0 ? "first" : "row");

                if (i > 0)
                {
                    string lstrDataType = objDC.DataType.ToString();
                    switch (lstrDataType)
                    {
                        case "System.Int32":
                        case "System.Double":
                        case "System.Decimal":
                            objBC.ItemStyle.CssClass = "money";
                            break;
                        case "System.DateTime":
                        case "System.String":
                        default:
                            objBC.ItemStyle.CssClass = "row";
                            break;
                    }
                }
                objBC.DataFormatString = WebComponents.FormatString.InputDataType(objDC.DataType.ToString());

                objBC.HtmlEncode = false;

                gvDetails.Columns.Add(objBC);
            }
            gvDetails.SelectedIndex = -1;

            if (!string.IsNullOrEmpty(SortExpression) && !string.IsNullOrEmpty(SortDirectionAscOrDesc))
                dt1.DefaultView.Sort = SortExpression + SortDirectionAscOrDesc;

            gvDetails.AllowPaging = true;
            gvDetails.PagerSettings.Visible = false;
            gvDetails.AllowSorting = true;

            if (dt1.DefaultView.Count == 0)
            {
                gvDetails.DataSource = AddDummyData(dt1.Clone());
                gvDetails.SelectedIndex = -1;
            }
            else
                gvDetails.DataSource = dt1.DefaultView;

            if (PageDropDownList.SelectedIndex != -1)
                gvDetails.PageIndex = PageDropDownList.SelectedIndex;

            try
            {
                gvDetails.DataBind();
            }
            catch
            {
                gvDetails.PageIndex = 0;
                gvDetails.DataBind();
            }
        }
        private DataTable AddDummyData(DataTable dt)
        {
            DataRow newRow = dt.NewRow();
            newRow[0] = "No Records Found!";

            dt.Rows.Add(newRow);
            return dt;
        }
        private void imgSearch_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            pBindDatatoGrid();
        }
        protected void gvDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string FirstCol = e.Row.Cells[0].Text; //.t ((LinkButton)e.Row.Cells[0].Controls[0]).Text;
                string Code = gvDetails.DataKeys[e.Row.RowIndex].Value.ToString();

                e.Row.Attributes.Add("onClick", "Select(" + (e.Row.RowIndex + 2).ToString() + ", '" + FirstCol + "' ,'" + Code + "', 'false'); ChangeRowColor('" + e.Row.ClientID + "')");

                e.Row.Attributes.Add("ondblClick", "Select(" + (e.Row.RowIndex + 2).ToString() + ", '" + FirstCol + "' ,'" + Code + "', 'true'); ");
            }
            if (!string.IsNullOrEmpty(SortExpression))
            {
                int cellIndex = -1;
                foreach (DataControlField field in gvDetails.Columns)
                {
                    if (field.SortExpression == SortExpression)
                    {
                        cellIndex = gvDetails.Columns.IndexOf(field);
                        break;
                    }
                }
                if (cellIndex > -1)
                {
                    if (e.Row.RowType == DataControlRowType.Header)
                    {
                        e.Row.Cells[cellIndex].CssClass +=
                            (GridViewSortDirection == SortDirection.Ascending
                            ? " sortasc" : " sortdesc");
                    }
                }
            }
        }
        protected void gvDetails_DataBound(object sender, EventArgs e)
        {
            PageDropDownList.ClearSelection();
            PageDropDownList.Items.Clear();
            for (int i = 0; i < gvDetails.PageCount; i++)
            {
                int pageNumber = i + 1;
                ListItem item = new ListItem(pageNumber.ToString());

                if (i == gvDetails.PageIndex)
                {
                    item.Selected = true;
                }

                PageDropDownList.Items.Add(item);
            }

            int currentPage = gvDetails.PageIndex + 1;

            CurrentPageLabel.Text = //"Page " + currentPage.ToString() +
              " of " + gvDetails.PageCount.ToString();

            lblCaption.Text = ViewState["PageCaption"].ToString();
        }
        protected void gvDetails_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                SortExpression = e.SortExpression;

                if (GridViewSortDirection == SortDirection.Ascending)
                {
                    GridViewSortDirection = SortDirection.Descending;
                    pBindDatatoGrid();
                }
                else
                {
                    GridViewSortDirection = SortDirection.Ascending;
                    pBindDatatoGrid();
                }
            }
            catch
            {
                throw;
            }
        }
        private SortDirection GridViewSortDirection
        {
            get
            {
                if (ViewState["sortDirection"] == null)
                    ViewState["sortDirection"] = SortDirection.Ascending;

                return (SortDirection)ViewState["sortDirection"];
            }
            set { ViewState["sortDirection"] = value; }
        }
        private string SortExpression
        {
            get
            {
                return (ViewState["SortExpression"] == null ? string.Empty : ViewState["SortExpression"].ToString());
            }
            set
            {
                ViewState["SortExpression"] = value;
            }
        }
        private string SortDirectionAscOrDesc
        {
            get
            {
                return (GridViewSortDirection == SortDirection.Ascending ? " ASC" : " DESC");
            }
        }
        protected void gvDetails_PreRender(object sender, System.EventArgs e)
        {
            try
            {
                if (gvDetails.PageCount == 1)
                    gvDetails.PagerSettings.Visible = true;
                else
                    gvDetails.PagerSettings.Visible = true;
            }
            catch
            {
                throw;
            }
        }
        private void btnOK_Click(object sender, System.EventArgs e)
        {
            string strScript1;

            strScript1 = "<script> var myRetValue = new Object(); ";
            strScript1 += "if(document.forms[0].hdnFirstColID.value == 'No Records Found!' && ";
            strScript1 += "document.forms[0].hdnFirstColID.value == '' ){myRetValue.FirstColumn =''}; ";
            strScript1 += "else";
            strScript1 += "{";
            strScript1 += "myRetValue.FirstColumn = document.forms[0].hdnFirstColID.value;";
            strScript1 += "myRetValue.LastColumn = document.forms[0].hdnCode.value; }";
            strScript1 += " window.returnValue = myRetValue; window.close(); </script>";

            Page.ClientScript.RegisterStartupScript(this.GetType(), "OK", strScript1.ToString());
        }
        protected void btnRefresh_Click(object sender, ImageClickEventArgs e)
        {
            txtSearchText.Text = "";
            SortExpression = string.Empty;
            pBindDatatoGrid();
        }
        protected void btnSearch_Click(object sender, ImageClickEventArgs e)
        {
            pBindDatatoGrid();
        }
        protected void gvDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            string lstrCode = string.Empty;
            lstrCode = gvDetails.SelectedDataKey.Value.ToString();

            string lstrFirstColumn = string.Empty;
            LinkButton lb = (LinkButton)gvDetails.SelectedRow.Cells[0].Controls[0];
            if (lb == null)
                lstrFirstColumn = gvDetails.SelectedRow.Cells[1].Text;
            else
                lstrFirstColumn = lb.Text;

            hdnFirstColID.Value = lstrFirstColumn;
            hdnCode.Value = lstrCode.ToString();
        }
        protected void PageDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            pBindDatatoGrid();
        }
        protected void btnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            string strScript1;
            strScript1 = "<script> var myRetValue = new Object(); ";
            strScript1 += "if(document.forms[0].hdnFirstColID.value == 'No Records Found!' && ";
            strScript1 += "document.forms[0].hdnFirstColID.value == '' ){myRetValue.FirstColumn =''}; ";
            strScript1 += "else";
            strScript1 += "{";
            strScript1 += "myRetValue.FirstColumn = document.forms[0].hdnFirstColID.value;";
            strScript1 += "myRetValue.LastColumn = document.forms[0].hdnCode.value; }";
            strScript1 += " window.returnValue = myRetValue; window.close(); </script>";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "OK", strScript1.ToString());

        }
    }
}