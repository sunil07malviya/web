﻿using System;
using System.Web.UI.WebControls;


namespace ISPL.CSC.Web.Controls
{
    public partial class DatePicker1 : System.Web.UI.UserControl
    {
        public event EventHandler AfterClick;

        private void Page_Load(object sender, System.EventArgs e)
        {
            txtDate.Attributes.Add("onblur", "fnValidateDate(this);");
            txtDate.Attributes.Add("onKeyPress", "fnDateKeyPress();");
            //imgCalendar.Attributes.Add("onfocus", "this.");

            //get the current path of the DatePicker cal directory
            string sDatePickerCalPath = this.ResolveClientUrl("~/controls/cal/");
            //string sDatePickerCalPath = "Controls/cal/";
            string sScript;

            //inject a script block to load the CSS from a dynamically set path
            //this has to be done before the JS injection or it breaks
            sScript = "<LINK href='" + sDatePickerCalPath + "popcalendar.css' type='text/css' rel='stylesheet'>";
            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("DatePickerCSS"))
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "DatePickerCSS", sScript);

            //inject a script block to load the JS from a dynamically set path
            sScript = "<script language='javascript' src='" + sDatePickerCalPath + "popCalendar.js'></script>";
            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("DatePickerJavascript"))
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "DatePickerJavascript", sScript);

            //add onlick JS to the calendar image
            if (this.txtDate.AutoPostBack == true)
            {
                //txtEvent.Text = "";
                sScript = "if (" + (this.txtDate.AutoPostBack == true ? "true" : "false") + ") { document.getElementById('" + txtEvent.ClientID + "').value = 'done'; return popUpCalendar(this," + txtDate.ClientID + @", 'dd-mmm-yyyy', '__doPostBack(\'" + txtDate.ClientID + @"\')', '" + sDatePickerCalPath + "', " + MinDate + ", " + MaxDate + "); document.getElementById('" + txtEvent.ClientID + "').value = '';  }";
            }
            else
                sScript = "javascript:return popUpCalendar(this," + txtDate.ClientID + @", 'dd-mmm-yyyy', '', '" + sDatePickerCalPath + "', " + MinDate + ", " + MaxDate + ")";

            imgCalendar.Attributes.Add("onclick", sScript);

            if (TabIndex != 0)
            {
                string sScript1 = "if (event.keyCode == 40) {" + sScript + ";}; ";
                imgCalendar.Attributes.Add("onkeyup", sScript1);
            }
        }
        public void ClearDate()
        {
            txtDate.Text = "";
        }
        public void SetFocus()
        {
            txtDate.Focus();
        }
        // This propery sets/gets the calendar date
        public string CalendarDate
        {
            get
            {
                if (txtDate.Text.Length == 0)
                    return DateTime.MinValue.ToString("dd-MMM-yyyy");
                else
                {
                    try
                    {
                        DateTime tmpDateTime = DateTime.Parse(txtDate.Text);
                        txtDate.Text = tmpDateTime.ToString("dd-MMM-yyyy");
                        return txtDate.Text;
                    }
                    catch
                    {
                        txtDate.Text = "";
                        return DateTime.MinValue.ToString("dd-MMM-yyyy");
                    }
                }
            }
            set
            {
                if (value.Equals(DateTime.MinValue.ToString("dd-MMM-yyyy")))
                    txtDate.Text = "";
                else
                    txtDate.Text = value;
            }
        }
        public System.Web.UI.WebControls.BorderStyle BorderStyle
        {
            get { return txtDate.BorderStyle; }
            set { txtDate.BorderStyle = value; }
        }
        public System.Web.UI.WebControls.FontUnit FontSize
        {
            get { return txtDate.Font.Size; }
            set
            {
                txtDate.Font.Size = value;
                txtEvent.Font.Size = value;
            }
        }
        public Unit Width
        {
            get { return txtDate.Width; }
            set { txtDate.Width = value; }
        }
        public string FontName
        {
            get { return txtDate.Font.Name; }
            set
            {
                txtDate.Font.Name = value;
                txtEvent.Font.Name = value;
            }
        }
        public bool ReadOnly
        {
            set
            {
                imgCalendar.Visible = !value;
                txtDate.ReadOnly = value;
            }
        }
        public string MinDate
        {
            get
            {
                if (ViewState["_mindate"] == null)
                    return "''";
                else if (ViewState["_mindate"].ToString() == string.Empty)
                    return "''";
                else
                {
                    string lstrValue = ViewState["_mindate"].ToString();
                    if (lstrValue.IndexOf("-") > 0 && lstrValue.Length == 11)
                        return "'" + ViewState["_mindate"].ToString() + "'";
                    else
                        return "document.getElementById('" + ViewState["_mindate"].ToString() + "_txtDate').value";
                }
            }
            set { ViewState["_mindate"] = value; }
        }
        public string MaxDate
        {
            get
            {
                if (ViewState["_maxdate"] == null)
                    return "''";
                else if (ViewState["_maxdate"].ToString() == string.Empty)
                    return "''";
                else
                {
                    string lstrValue = ViewState["_maxdate"].ToString();
                    if (lstrValue.IndexOf("-") > 0 && lstrValue.Length == 11)
                        return "'" + ViewState["_maxdate"] + "'";
                    else
                        return "document.getElementById('" + ViewState["_maxdate"] + "_txtDate').value";
                }
            }
            set { this.ViewState["_maxdate"] = value; }
        }

        public bool Required
        {
            get { return rfvDatePicker.Enabled; }
            set { rfvDatePicker.Enabled = value; }
        }
        public short TabIndex
        {
            get
            {
                return txtDate.TabIndex;
            }
            set
            {
                txtDate.TabIndex = value;
                imgCalendar.TabIndex = short.Parse((value + 1).ToString());
            }
            /*get
            {
                return txtDate.TabIndex;
            }
            set
            {
                txtDate.TabIndex = value;
            }
            */
        }
        public bool AutoPostBack
        {
            get { return this.txtDate.AutoPostBack; }
            set { txtDate.AutoPostBack = value; }
        }
        protected void onAfterClick(EventArgs e)
        {
            if (AfterClick != null)
                AfterClick(this, e);
        }
        private void txtEvent_TextChanged(object sender, System.EventArgs e)
        {
            if (txtEvent.Text == "done" && AfterClick != null && txtDate.AutoPostBack == true)
            {
                onAfterClick(e);
                txtEvent.Text = "";
            }
        }
    }
}