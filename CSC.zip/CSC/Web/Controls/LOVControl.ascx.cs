﻿using System;
using System.Text;
using System.Web.UI;

namespace ISPL.CSC.Web.Controls
{
    public partial class LOVControl : System.Web.UI.UserControl
    {
        public event EventHandler LOVBeforeClick;
        public event EventHandler LOVAfterClick;

        private LOVBase myLOVBase;

        private string LBClientID
        {
            get
            {
                return "lb" + txtCode.ClientID;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                Control c = WebComponents.Misc.GetPostBackControl(this.Page);

                if (c != null)
                {
                    if (txtName.ClientID == c.ClientID || btnRefresh.ClientID == c.ClientID)
                        txtName.Focus();
                }
            }

            if (ViewState[LBClientID] == null)
                ViewState[LBClientID] = new LOVBase(this.ClientID, Request.UserHostAddress);

            myLOVBase = (LOVBase)ViewState[LBClientID];

            StringBuilder sb = new StringBuilder();
            sb.Append("<script language='javascript' type='text/javascript'> ");
            sb.Append(" function Select" + txtCode.ClientID + "(source, eventArgs) ");
            sb.Append(" { ");
            sb.Append(" if (eventArgs.get_value() == 'No Records Found!') ");
            sb.Append(" { ");
            sb.Append(" document.getElementById('" + txtCode.ClientID + "').value = ''; ");
            sb.Append(" document.getElementById('" + txtName.ClientID + "').value = ''; ");
            sb.Append(" } ");
            sb.Append(" else ");
            sb.Append(" {  document.getElementById('" + txtCode.ClientID + "').value = eventArgs.get_value();  } ");
            sb.Append(" } ");
            sb.Append(" </script> ");

            StringBuilder sb2 = new StringBuilder();
            sb2.Append("<script language='javascript' type='text/javascript'> ");
            sb2.Append(" function Change" + txtCode.ClientID + "() ");
            sb2.Append(" { ");
            sb2.Append(" document.getElementById('" + txtCode.ClientID + "').value = ''; ");
            sb2.Append(" Hide" + txtCode.ClientID + "(null, null); ");
            sb2.Append(" } ");
            sb2.Append(" </script> ");

            StringBuilder sb3 = new StringBuilder();
            sb3.Append("<script language='javascript' type='text/javascript'> ");
            sb3.Append(" function Show" + txtCode.ClientID + "(source, eventArgs) ");
            sb3.Append(" { ");
            sb3.Append(" document.getElementById('" + txtName.ClientID + "').style.backgroundImage = 'url(" + this.ResolveClientUrl("~/_assets/img/loader-small.gif") + ")'; ");
            sb3.Append(" } ");
            sb3.Append(" </script> ");

            StringBuilder sb4 = new StringBuilder();
            sb4.Append("<script language='javascript' type='text/javascript'> ");
            sb4.Append(" function Hide" + txtCode.ClientID + "(source, eventArgs) ");
            sb4.Append(" { ");
            sb4.Append(" document.getElementById('" + txtName.ClientID + "').style.backgroundImage = 'none'; ");
            sb4.Append(" } ");
            sb4.Append(" </script> ");

            StringBuilder sb5 = new StringBuilder();
            sb5.Append("<script language='javascript' type='text/javascript'> ");
            sb5.Append("var tName, hBCE;");
            sb5.Append("function activateBeforeClickEvent(txtName, btnBeforeClick, hdnBCEvent)");
            sb5.Append("{");
            sb5.Append("tName=txtName.id; bBeforeClick=btnBeforeClick.id; hBCE=hdnBCEvent.id;");
            sb5.Append("if(document.getElementById(hBCE).value.indexOf('ACM') < 0){");
            sb5.Append("document.getElementById(hBCE).value += 'ACM';");
            sb5.Append("focusOnNameTrigger();");
            sb5.Append("btnBeforeClick.click();}");
            sb5.Append("}");
            sb5.Append("function focusOnNameTrigger()");
            sb5.Append("{");
            sb5.Append("if(document.getElementById(hBCE).value.indexOf('FON') >= 0){");
            sb5.Append("window.setTimeout('focusOnName()',500);}");
            sb5.Append("else{");
            sb5.Append("window.setTimeout('focusOnNameTrigger()',0);}");
            sb5.Append("}");
            sb5.Append("function focusOnName()");
            sb5.Append("{");
            sb5.Append(" try { document.getElementById(tName).focus();  } catch(e) {} ");
            sb5.Append("}");
            sb5.Append(" </script> ");

            aceLOVControl.OnClientPopulating = "Show" + txtCode.ClientID;
            aceLOVControl.OnClientShown = "Hide" + txtCode.ClientID;
            aceLOVControl.OnClientPopulated = "Hide" + txtCode.ClientID;
            aceLOVControl.OnClientItemSelected = "Select" + txtCode.ClientID;

            txtName.Attributes.Add("onchange", "Change" + txtCode.ClientID + "();");
            if (ViewState["Title"] == null)
                txtName.Attributes.Add("title", "Select a Value from List");
            else
                txtName.Attributes.Add("title", "Select " + Title);

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ScriptSelect" + txtCode.ClientID))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ScriptSelect" + txtCode.ClientID, sb.ToString(), false);
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ScriptSelect" + txtCode.ClientID, sb.ToString());

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ScriptChange" + txtCode.ClientID))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ScriptChange" + txtCode.ClientID, sb2.ToString(), false);
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ScriptChange" + txtCode.ClientID, sb2.ToString());

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ScriptShow" + txtCode.ClientID))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ScriptShow" + txtCode.ClientID, sb3.ToString(), false);
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ScriptShow" + txtCode.ClientID, sb3.ToString());

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ScriptHide" + txtCode.ClientID))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ScriptHide" + txtCode.ClientID, sb4.ToString(), false);
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ScriptHide" + txtCode.ClientID, sb4.ToString());

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("BeforeClick" + txtCode.ClientID))
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "BeforeClick" + txtCode.ClientID, sb5.ToString(), false);
            //this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "BeforeClick" + txtCode.ClientID, sb5.ToString());

            // Added to cover-up the problem in showing dialogue without post-back - START
            StringBuilder sbShowDialogue = new StringBuilder();
            sbShowDialogue.Append("<script language='javascript'>function fShowDialogue" + txtCode.ClientID + "(){");
            sbShowDialogue.Append("try{");
            sbShowDialogue.Append("if(document.getElementById('" + hdnShowDialogue.ClientID + "').value=='ShowDialogue')");
            sbShowDialogue.Append("{");
            sbShowDialogue.Append("document.getElementById('" + hdnShowDialogue.ClientID + "').value='';");
            sbShowDialogue.Append("setTimeout('fShowDialogue" + txtCode.ClientID + "()',100);");
            sbShowDialogue.Append("document.getElementById('" + txtName.ClientID + "').value = ''; document.getElementById('" + txtCode.ClientID + "').value = ''; var strReturn = new Object(); strReturn = window.showModalDialog('" + this.TemplateSourceDirectory + "/LOVPage.aspx?UNQ=" + myLOVBase.GUID + "',null,'status:no; dialogWidth:500px; dialogHeight:500px; center:yes; edge:raised; dialogHide:true; help:no;'); if (strReturn != null) { document.getElementById('" + txtCode.ClientID + "').value = strReturn.LastColumn; document.getElementById('" + txtName.ClientID + "').value = strReturn.FirstColumn; document.getElementById('" + btnRefresh.ClientID + "').click(); } ");
            sbShowDialogue.Append("}");
            sbShowDialogue.Append("else {setTimeout('fShowDialogue" + txtCode.ClientID + "()',100);}");
            sbShowDialogue.Append("}catch(e){try{setTimeout('fShowDialogue" + txtCode.ClientID + "()',500);}catch(e) {}}");
            sbShowDialogue.Append("}");
            sbShowDialogue.Append("setTimeout('fShowDialogue" + txtCode.ClientID + "()',100);");
            sbShowDialogue.Append("</script>");
            Page.ClientScript.RegisterStartupScript(this.GetType(), "ShowDialogue" + txtCode.ClientID, sbShowDialogue.ToString());
            // Added to cover-up the problem in showing dialogue without post-back - END

            if (LOVBeforeClick == null && LOVAfterClick == null)
            {
                StringBuilder scriptStr1 = new StringBuilder();
                scriptStr1.Append(" document.getElementById('" + txtName.ClientID + "').value = ''; document.getElementById('" + txtCode.ClientID + "').value = ''; var strReturn = new Object(); strReturn = window.showModalDialog('" + this.TemplateSourceDirectory + "/LOVPage.aspx?UNQ=" + myLOVBase.GUID + "',null,'status:no; dialogWidth:500px; dialogHeight:500px; center:yes; edge:raised; dialogHide:true; help:no;'); if (strReturn != null) { document.getElementById('" + txtCode.ClientID + "').value = strReturn.LastColumn; document.getElementById('" + txtName.ClientID + "').value = strReturn.FirstColumn; document.getElementById('" + txtName.ClientID + "').focus(); ");
                scriptStr1.Append(" return false; } else { try { document.getElementById('" + txtName.ClientID + "').focus(); } catch(e) {} return false; } ");

                this.btnLOV.Attributes.Add("onclick", scriptStr1.ToString());
            }
            if (LOVBeforeClick != null)
            {
                txtName.TextChanged -= new EventHandler(txtName_TextChanged);
                txtName.TextChanged += new EventHandler(txtName_TextChanged);
                txtName.Attributes.Add("onfocus", "activateBeforeClickEvent(document.getElementById('" + txtName.ClientID + "'), document.getElementById('" + btnBeforeClick.ClientID + "'), document.getElementById('" + hdnBCEvent.ClientID + "'));");
            }
            else
            {
                txtName.AutoPostBack = false;
            }
            if (LOVAfterClick != null)
            {
                txtName.AutoPostBack = true;
                txtName.TextChanged -= new EventHandler(txtName_TextChanged);
                txtName.TextChanged += new EventHandler(txtName_TextChanged);
            }
            else
            {
                txtName.AutoPostBack = false;
            }
        }
        public string Title
        {
            get { return ViewState[txtCode.ClientID].ToString(); }
            set { ViewState[txtCode.ClientID] = value; }
        }
        protected void txtName_TextChanged(object sender, EventArgs e)
        {
            if (LOVAfterClick != null)
            {
                LOVAfterClick(this, e);
            }
        }
        public string BeforeClickClientID
        {
            get
            {
                return btnBeforeClick.ClientID;
            }
        }
        public string NameClientID
        {
            get
            {
                return txtName.ClientID;
            }
        }
        public string CodeClientID
        {
            get
            {
                return txtCode.ClientID;
            }
        }
        public string strFirstColumn
        {
            get
            {
                return txtName.Text;
            }
            set
            {
                txtName.Text = value;
            }
        }
        public int TextWidth
        {
            set { txtName.Width = value; }
        }
        public void ClearAll()
        {
            txtName.Text = "";
            txtCode.Text = "";
        }
        public string strLastColumn
        {
            get
            {
                return txtCode.Text;
            }
            set
            {
                txtCode.Text = value;
            }
        }
        public bool ReadOnly
        {
            set
            {
                btnLOV.Visible = !value;
                txtName.ReadOnly = value;
            }

            get { return btnLOV.Visible; }
        }
        public bool Required
        {
            set { rfvLOVControl.Enabled = value; }
        }
        public string ServiceMethod
        {
            get
            {
                return aceLOVControl.ServiceMethod;
            }
            set
            {
                aceLOVControl.ServiceMethod = value;
            }
        }
        public string Query
        {
            get
            {
                myLOVBase = (LOVBase)ViewState[LBClientID];

                return myLOVBase.Query;
            }
            set
            {
                if (ViewState[LBClientID] == null)
                    ViewState[LBClientID] = new LOVBase(this.ClientID, Request.UserHostAddress);

                myLOVBase = (LOVBase)ViewState[LBClientID];

                myLOVBase.Query = value;
                aceLOVControl.ContextKey = value;
                ViewState[LBClientID] = myLOVBase;

                Cache.Remove(myLOVBase.GUID);
                Cache.Insert(myLOVBase.GUID, myLOVBase, null, DateTime.Now.AddMinutes(10), new TimeSpan(0, 0, 0));
            }
        }
        public string QueryCode
        {
            get
            {
                myLOVBase = (LOVBase)ViewState[LBClientID];

                return myLOVBase.QueryCode;
            }
            set
            {
                if (ViewState[LBClientID] == null)
                    ViewState[LBClientID] = new LOVBase(this.ClientID, Request.UserHostAddress);

                myLOVBase = (LOVBase)ViewState[LBClientID];

                myLOVBase.QueryCode = value;

                Model.LOVQueryInfo myTmpInfo = SQLServerDAL.LOVQuery.GetLOVQueryByCode(value);
                string tmpQuery = (myTmpInfo == null ? string.Empty : myTmpInfo.Query);
                if (tmpQuery.Contains("@pBrnCd") || tmpQuery.Contains("BRANCHID") || tmpQuery.Contains("@SITEID") || tmpQuery.Contains("@SITECODE"))
                {
                    ProcessFlow.AccountController accountController = new ISPL.CSC.Web.ProcessFlow.AccountController();
                    //string AppType = accountController.GetAppType(true);
                    string AppType = string.Empty;

                    Model.Masters.BranchInfo myTmpBranchInfo = accountController.GetBranchInfo(true);

                    tmpQuery = tmpQuery.Replace("@pBrnCd", myTmpBranchInfo.BranchID.ToString());
                    tmpQuery = tmpQuery.Replace("@BRANCHID", myTmpBranchInfo.BranchID.ToString());

                    //if (AppType == "S")
                    //{
                    //    Model.Masters.SiteInfo myTmpSiteInfo = accountController.GetSiteInfo(true);

                    //    tmpQuery = tmpQuery.Replace("@SITEID", myTmpSiteInfo.SlNo.ToString());
                    //    tmpQuery = tmpQuery.Replace("@SITECODE", myTmpSiteInfo.SlNo.ToString());
                    //}
                }

                myLOVBase.Query = tmpQuery;
                aceLOVControl.ContextKey = myLOVBase.Query;
                ViewState[LBClientID] = myLOVBase;

                Cache.Remove(myLOVBase.GUID);
                Cache.Insert(myLOVBase.GUID, myLOVBase, null, DateTime.Now.AddMinutes(10), new TimeSpan(0, 0, 0));
            }
        }
        public string Heading
        {
            get
            {
                myLOVBase = (LOVBase)ViewState[LBClientID];

                return myLOVBase.Heading;
            }
            set
            {
                if (ViewState[LBClientID] == null)
                    ViewState[LBClientID] = new LOVBase(this.ClientID, Request.UserHostAddress);

                myLOVBase = (LOVBase)ViewState[LBClientID];

                myLOVBase.Heading = value;
                ViewState[LBClientID] = myLOVBase;

                Cache.Remove(myLOVBase.GUID);
                Cache.Insert(myLOVBase.GUID, myLOVBase, null, DateTime.Now.AddMinutes(10), new TimeSpan(0, 0, 0));
            }
        }
        public string MasterMenuID
        {
            get
            {
                myLOVBase = (LOVBase)ViewState[LBClientID];

                return myLOVBase.MasterMenuID;
            }
            set
            {
                if (ViewState[LBClientID] == null)
                    ViewState[LBClientID] = new LOVBase(this.ClientID, Request.UserHostAddress);

                myLOVBase = (LOVBase)ViewState[LBClientID];

                myLOVBase.MasterMenuID = value;
                ViewState[LBClientID] = myLOVBase;

                Cache.Remove(myLOVBase.GUID);
                Cache.Insert(myLOVBase.GUID, myLOVBase, null, DateTime.Now.AddMinutes(10), new TimeSpan(0, 0, 0));
            }
        }
        public short TabIndex
        {
            get { return txtName.TabIndex; }
            set
            {
                txtName.TabIndex = value;
                btnLOV.TabIndex = short.Parse((value + 1).ToString());
            }
        }
        public int Columns
        {
            get { return this.txtName.Columns; }
            set { this.txtName.Columns = value; }
        }
        public void SetFocus()
        {
            txtName.Focus();
        }
        public void ButtonFocus()
        {
            btnLOV.Focus();
        }
        protected void onLOVBeforeClick(EventArgs e)
        {
            if (LOVBeforeClick != null)
                LOVBeforeClick(this, e);
        }
        protected void onLOVAfterClick(object sender, EventArgs e)
        {
            if (LOVAfterClick != null && txtCode.Text.Trim().Length == 0)
                LOVAfterClick(sender, e);
        }
        protected void btnLOV_Click(object sender, System.Web.UI.ImageClickEventArgs e)
        {
            if (LOVBeforeClick != null)
                onLOVBeforeClick(e);

            hdnShowDialogue.Value = "ShowDialogue";
        }
        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            if (LOVAfterClick != null)
                onLOVAfterClick(sender, e);
        }
        protected void btnBeforeClick_Click(object sender, EventArgs e)
        {
            if (LOVBeforeClick != null)
                onLOVBeforeClick(e);

            hdnBCEvent.Value += "FON";
        }
        protected void btn1_Click(object sender, EventArgs e)
        {
            if (LOVBeforeClick != null)
                onLOVBeforeClick(e);
        }
    }
}