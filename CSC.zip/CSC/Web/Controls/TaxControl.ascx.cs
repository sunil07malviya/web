﻿using System;
using System.Data;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using ISPL.CSC.SQLServerDAL;
//using ISPL.CSC.SQLServerDAL.

namespace ISPL.CSC.Web.Controls
{
    public partial class TaxControl : System.Web.UI.UserControl
    {
        private const string DUTY_DETAILS_KEY = "DUTY_DETAILS_KEY";

        public int BranchID
        {
            get
            {
                if (ViewState["BranchID"] == null)
                    return 0;
                else
                    return Convert.ToInt32(ViewState["BranchID"].ToString());
            }
            set { ViewState["BranchID"] = value; }
        }
        public string TranType
        {
            get
            {
                if (ViewState["TranType"] == null)
                    return string.Empty;
                else
                    return ViewState["TranType"].ToString();
            }
            set { ViewState["TranType"] = value; }
        }
        public int TranDSlNo
        {
            get
            {
                if (ViewState["TranDSlNo"] == null)
                    return 0;
                else
                    return Convert.ToInt32(ViewState["TranDSlNo"].ToString());
            }
            set { ViewState["TranDSlNo"] = value; }
        }
        public int TranMSlNo
        {
            get
            {
                if (ViewState["TranMSlNo"] == null)
                    return 0;
                else
                    return Convert.ToInt32(ViewState["TranMSlNo"].ToString());
            }
            set { ViewState["TranMSlNo"] = value; }
        }
        public DateTime TranDate
        {
            get
            {
                if (ViewState["TranDate"] == null)
                    return DateTime.MinValue;
                else
                    return Convert.ToDateTime(ViewState["TranDate"].ToString());
            }
            set { ViewState["TranDate"] = value; }
        }
        public int SMDutyCalcSlNo
        {
            get
            {
                if (ViewState["SMDutyCalcSlNo"] == null)
                    return 0;
                else
                    return Convert.ToInt32(ViewState["SMDutyCalcSlNo"].ToString());
            }
            set { ViewState["SMDutyCalcSlNo"] = value; }
        }
        public string AssblValueClientID
        {
            get
            {
                if (ViewState["AssblValueClientID"] == null)
                    return null;
                else
                    return ViewState["AssblValueClientID"].ToString();
            }
            set { ViewState["AssblValueClientID"] = value; }
        }
        public double TotalDutyPercent
        {
            get
            {
                double dblTemp = 0;
                TextBox tbTotalDutyPercent = (TextBox)this.FindControl("ntbTotalDutyPer");

                if (tbTotalDutyPercent != null)
                    dblTemp = Convert.ToDouble(tbTotalDutyPercent.Text);
                else if (ViewState["TotalDutyPercent"] != null)
                    dblTemp = Convert.ToDouble(ViewState["TotalDutyPercent"].ToString());

                return dblTemp;
            }
            set { ViewState["TotalDutyPercent"] = value; }
        }
        public double TotalDutyAmount
        {
            get
            {
                double dblTemp = 0;
                TextBox tbTotalDutyAmount = (TextBox)this.FindControl("ntbTotalDutyAmt");

                if (tbTotalDutyAmount != null)
                    dblTemp = Convert.ToDouble(tbTotalDutyAmount.Text);
                else if (ViewState["TotalDutyAmount"] != null)
                    dblTemp = Convert.ToDouble(ViewState["TotalDutyAmount"].ToString());

                ViewState["TotalDutyAmount"] = dblTemp;

                return dblTemp;
            }
            set { ViewState["TotalDutyAmount"] = value; }
        }
        public string TotalDutyFormulae
        {
            get
            {
                string dblTemp = string.Empty;
                TextBox tbTotalDutyFormulae = (TextBox)this.FindControl("ntbTotalDutyFormulae");

                if (tbTotalDutyFormulae != null)
                    dblTemp = tbTotalDutyFormulae.Text;
                else if (ViewState["TotalDutyFormulae"] != null)
                    dblTemp = ViewState["TotalDutyFormulae"].ToString();

                ViewState["TotalDutyFormulae"] = dblTemp;

                return dblTemp;
            }
            set { ViewState["TotalDutyFormulae"] = value; }
        }
        public string DutyAmounts
        {
            get
            {
                TextBox tbDutyAmt = (TextBox)this.FindControl("txtDutyAmt");

                if (tbDutyAmt == null)
                    return string.Empty;
                else
                    return tbDutyAmt.Text;
            }
            set
            {
                TextBox tbDutyAmt = (TextBox)this.FindControl("txtDutyAmt");
                if (tbDutyAmt != null)
                    tbDutyAmt.Text = value;
            }
        }
        public string DutyPercents
        {
            get
            {
                TextBox tbDutyPer = (TextBox)this.FindControl("txtDutyPer");
                if (tbDutyPer == null)
                    return string.Empty;
                else
                    return tbDutyPer.Text;
            }
            set
            {
                TextBox tbDutyPer = (TextBox)this.FindControl("txtDutyPer");
                if (tbDutyPer != null)
                    tbDutyPer.Text = value;
            }
        }
        public string DutySlNos
        {
            get
            {
                TextBox tbDutySlNo = (TextBox)this.FindControl("txtDutySlNo");
                if (tbDutySlNo == null)
                    return string.Empty;
                else
                    return tbDutySlNo.Text;
            }
            set
            {
                TextBox tbDutySlNo = (TextBox)this.FindControl("txtDutySlNo");
                if (tbDutySlNo != null)
                    tbDutySlNo.Text = value;
            }
        }
        public double AssessableValue1
        {
            get
            {
                if (ViewState["AssessableValue"] == null)
                    return 100;
                else
                    return Convert.ToDouble(ViewState["AssessableValue"].ToString());
            }
            set { ViewState["AssessableValue"] = value; }
        }

        public double AssessableValue
        {
            get
            {
                if (ViewState["AssessableValue"] == null)
                {
                    double dblTemp = 0;

                    if (AssblValueClientID != null)
                    {
                        TextBox txtTemp = (TextBox)this.Parent.FindControl(AssblValueClientID);

                        if (txtTemp != null)
                        {
                            if (txtTemp.Text == "")
                                txtTemp.Text = "0";

                            dblTemp = Convert.ToDouble(txtTemp.Text);
                        }
                    }

                    ViewState["AssessableValue"] = dblTemp;
                }

                return Convert.ToDouble(ViewState["AssessableValue"].ToString());
            }
            set { ViewState["AssessableValue"] = value; }
        }

        public bool ReadOnly
        {
            get
            {
                if (ViewState["ReadOnly"] == null)
                    return true;
                else
                    return Convert.ToBoolean(ViewState["ReadOnly"].ToString());
            }
            set
            {
                ViewState["ReadOnly"] = value;
                pToggleControls(value);
            }
        }
        public DataTable DutyTable
        {
            get
            {
                if (ViewState[DUTY_DETAILS_KEY] == null)
                    return null;
                else
                    return (DataTable)ViewState[DUTY_DETAILS_KEY];
            }
            set { ViewState[DUTY_DETAILS_KEY] = value; }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            pCreateControls();
        }
        private void pToggleControls(bool Flag)
        {
            foreach (Control ctrl in taxControls.Controls)
            {
                if (ctrl.GetType() == typeof(Web.Controls.NumericTextBox))
                {
                    Web.Controls.NumericTextBox ntb = (Web.Controls.NumericTextBox)ctrl;
                    if (ntb.ID == "ntbTotalDutyPer" || ntb.ID == "ntbTotalDutyAmt" || ntb.ID.IndexOf("ntbDutyAmount") >= 0)
                        ntb.ReadOnly = true;
                    //ntb.Attributes["readonly"] = "true";
                    else
                        ntb.ReadOnly = Flag;
                    //ntb.Attributes["readonly"] = Flag.ToString();
                }
            }
        }
        private void pCreateControls()
        {
            //SQLServerDAL.Transactions.TranDutyCalc trandutycalc = new SQLServerDAL.Transactions.TranDutyCalc();
            //SQLServerDAL.Transactions.TaxDutyCalc taxdutycalc = new SQLServerDAL.Transactions.TaxDutyCalc();

            DataTable myTable = new DataTable();
            //if (TranDSlNo == 0)
            //    myTable = trandutycalc.GetTranDutyCalcDataTableNew(BranchID, TranType, TranDate);
            //else 
            //    myTable = trandutycalc.GetTranDutyCalcDataTable(BranchID, TranType, TranDSlNo);

            //if (TranType == "IST" || TranType == "OST" || TranType == "SC" || TranType == "C" || TranType == "V")
            //{
            //    if (SMDutyCalcSlNo > 0 && TranDSlNo == 0)
            //        myTable = taxdutycalc.GetTAXDutyCalcDataTableBySMDutyCalcSlNo(BranchID, SMDutyCalcSlNo);
            //    else if (TranDSlNo == 0)
            //        myTable = taxdutycalc.GetTranDutyCalcDataTableNew(BranchID, TranType, TranDate);
            //    else
            //        myTable = taxdutycalc.GetTaxDutyCalcDataTable(BranchID, TranType, TranDSlNo);
            //}
            //else
            //{
            //    if (SMDutyCalcSlNo > 0 && TranDSlNo == 0)
            //        myTable = trandutycalc.GetTranDutyCalcDataTableBySMDutyCalcSlNo(BranchID, SMDutyCalcSlNo);
            //    else if (TranDSlNo == 0)
            //        myTable = trandutycalc.GetTranDutyCalcDataTableNew(BranchID, TranType, TranDate);
            //    else
            //        myTable = trandutycalc.GetTranDutyCalcDataTable(BranchID, TranType, TranDSlNo);
            //}

            DutyTable = myTable;
            taxControls.Controls.Clear();

            for (int i = 0; i < myTable.Rows.Count; i++)
            {
                DataRow objDR = myTable.Rows[i];
                LiteralControl lt = new LiteralControl("<br>");
                for (int j = 0; j < myTable.Columns.Count; j++)
                {
                    DataColumn objDC = myTable.Columns[j];
                    string colDataType = objDC.DataType.ToString();
                    if (colDataType == "System.String")
                    {
                        Label lbl = new Label();
                        lbl.ID = "lbl" + i.ToString() + j.ToString();
                        lbl.Text = objDR[objDC].ToString();
                        lbl.Font.Bold = false;
                        lbl.ForeColor = System.Drawing.Color.FromArgb(0, 102, 204);

                        switch (objDC.ColumnName)
                        {
                            case "Duty Description":
                                lbl.Width = 100;
                                break;
                            case "Classification":
                                //lbl.Width = 50;
                                break;
                            default:
                                lbl.Visible = false;
                                break;
                        }
                        taxControls.Controls.Add(lbl);
                        if (lbl.Visible) taxControls.Controls.Add(new LiteralControl("&nbsp;&nbsp;"));
                    }
                    else if (colDataType == "System.Int32" && objDC.ColumnName == "T_DUTYCALC_SLNO")
                    {
                        TextBox tb = new TextBox();
                        tb.ID = "tbslno" + i.ToString();
                        tb.Text = objDR[objDC].ToString();
                        tb.Style.Add("visibility", "hidden");
                        tb.Style.Add("width", "0px");

                        taxControls.Controls.Add(tb);
                        //taxControls.Controls.Add(new LiteralControl("&nbsp;"));
                    }
                    else if (colDataType == "System.Int32" && objDC.ColumnName == "T_TAXCALC_SLNO")
                    {
                        TextBox tb = new TextBox();
                        tb.ID = "tbslno" + i.ToString();
                        tb.Text = objDR[objDC].ToString();
                        tb.Style.Add("visibility", "hidden");
                        tb.Style.Add("width", "0px");

                        taxControls.Controls.Add(tb);
                        //taxControls.Controls.Add(new LiteralControl("&nbsp;"));
                    }
                    else
                    {
                        if (colDataType == "System.Double" && objDC.ColumnName == "Percent")
                        {
                            Web.Controls.NumericTextBox nmTB1 = new Web.Controls.NumericTextBox();
                            nmTB1.ID = "nmtb" + i.ToString() + j.ToString();
                            nmTB1.Text = objDR[objDC].ToString();
                            nmTB1.Width = 50;
                            nmTB1.ReadOnly = this.ReadOnly;

                            nmTB1.Attributes.Add("OnBlur", "CalculateDutyAmount(" + i.ToString() + ")");

                            taxControls.Controls.Add(nmTB1);
                            taxControls.Controls.Add(new LiteralControl("&nbsp;"));

                            TextBox nnnn = new TextBox();
                            nnnn.ID = "temp" + i.ToString();
                            nnnn.Text = objDR["Formulae"].ToString().Replace("Assbl Value", AssessableValue.ToString());
                            nnnn.Style.Add("visibility", "hidden");
                            nnnn.Style.Add("width", "0px");

                            taxControls.Controls.Add(nnnn);
                            //taxControls.Controls.Add(new LiteralControl("&nbsp;"));
                        }
                        else if ((colDataType == "System.Double" || colDataType == "System.Int32") && objDC.ColumnName == "Amount")
                        {
                            Web.Controls.NumericTextBox nmTB2 = new Web.Controls.NumericTextBox();
                            nmTB2.ID = "ntbDutyAmount" + i.ToString() + j.ToString();
                            nmTB2.Text = Math.Round(Convert.ToDouble(objDR[objDC]), 4).ToString();
                            nmTB2.ForeColor = System.Drawing.Color.FromArgb(0, 102, 204);
                            nmTB2.Width = 90;
                            nmTB2.ReadOnly = this.ReadOnly;

                            taxControls.Controls.Add(nmTB2);
                            //taxControls.Controls.Add(new LiteralControl("&nbsp;"));
                        }
                    }
                }
                taxControls.Controls.Add(lt);
            }
            taxControls.Controls.Add(new LiteralControl("<br>"));
            Label lblTotal = new Label();
            lblTotal.ID = "lblTotal";
            lblTotal.Text = "Total : ";
            lblTotal.ForeColor = System.Drawing.Color.FromArgb(0, 102, 204);
            lblTotal.Font.Bold = true;
            lblTotal.Width = 100;
            taxControls.Controls.Add(lblTotal);
            taxControls.Controls.Add(new LiteralControl("&nbsp;&nbsp;"));

            TextBox ntb = new TextBox();
            ntb.ID = "ntbTotalDutyPer";
            ntb.Width = 50;
            ntb.Attributes["onfocus"] = "this.blur();";
            //ntb.Attributes["text-align"] = "right";
            ntb.Style.Add("text-align", "right");
            ntb.Text = TotalDutyPercent.ToString();
            taxControls.Controls.Add(ntb);
            taxControls.Controls.Add(new LiteralControl("&nbsp;&nbsp;"));

            TextBox ntb1 = new TextBox();
            ntb1.ID = "ntbTotalDutyAmt";
            ntb1.Width = 90;
            ntb1.Attributes["onfocus"] = "this.blur();";
            //ntb1.Attributes["text-align"] = "right";
            ntb1.Style.Add("text-align", "right");
            ntb1.Text = TotalDutyAmount.ToString();
            taxControls.Controls.Add(ntb1);

            TextBox ntb2 = new TextBox();
            ntb2.ID = "ntbTotalDutyFormulae";
            ntb2.ReadOnly = true;
            ntb2.Width = 90;
            ntb2.ReadOnly = ReadOnly;
            ntb2.Text = TotalDutyFormulae;
            ntb2.Style.Add("visibility", "hidden");
            ntb2.Width = 0;
            taxControls.Controls.Add(ntb2);

            TextBox tbDutyPer = new TextBox();
            tbDutyPer.ID = "txtDutyPer";
            tbDutyPer.Style.Add("visibility", "hidden");
            tbDutyPer.Width = 0;

            TextBox tbDutyAmt = new TextBox();
            tbDutyAmt.ID = "txtDutyAmt";
            tbDutyAmt.Style.Add("visibility", "hidden");
            tbDutyAmt.Width = 0;

            TextBox tbDutySlNo = new TextBox();
            tbDutySlNo.ID = "txtDutySlNo";
            tbDutySlNo.Style.Add("visibility", "hidden");
            tbDutySlNo.Width = 0;

            taxControls.Controls.Add(tbDutyPer);
            taxControls.Controls.Add(tbDutyAmt);
            taxControls.Controls.Add(tbDutySlNo);

            for (int i = 0; i < myTable.Rows.Count; i++)
            {
                TextBox nnMain = (TextBox)taxControls.FindControl("temp" + i.ToString());
                nnMain.Text = nnMain.Text.Replace("Assbl Value", AssessableValue.ToString()).Trim();

                for (int j = i + 1; j < myTable.Rows.Count; j++)
                {
                    TextBox nnTT = (TextBox)taxControls.FindControl("temp" + j.ToString());
                    nnTT.Text = nnTT.Text.Replace(myTable.Rows[i]["Duty Description"].ToString(), myTable.Rows[i]["Amount"].ToString());
                }
            }
            for (int i = 0; i < myTable.Rows.Count; i++)
            {
                TextBox nnn = (TextBox)taxControls.FindControl("temp" + i.ToString());
                nnn.Text = nnn.Text.Trim();

                if (DutyAmounts == string.Empty)
                    DutyAmounts = myTable.Rows[i]["Amount"].ToString();
                else
                    DutyAmounts += ":" + myTable.Rows[i]["Amount"];

                if (DutyPercents == string.Empty)
                    DutyPercents = myTable.Rows[i]["Percent"].ToString();
                else
                    DutyPercents += ":" + myTable.Rows[i]["Percent"];

                if (TranType == "IST" || TranType == "OST" || TranType == "SC" || TranType == "C" || TranType == "V")
                {
                    if (DutySlNos == string.Empty)
                        DutySlNos = myTable.Rows[i]["T_TAXCALC_SLNO"].ToString();
                    else
                        DutySlNos += ":" + myTable.Rows[i]["T_TAXCALC_SLNO"];
                }
                else
                {
                    if (DutySlNos == string.Empty)
                        DutySlNos = myTable.Rows[i]["T_DUTYCALC_SLNO"].ToString();
                    else
                        DutySlNos += ":" + myTable.Rows[i]["T_DUTYCALC_SLNO"];
                }
            }
            pRegisterClientScript();

            pToggleControls(ReadOnly);
        }
        private void pRegisterClientScript()
        {
            double AssblValue = 0;

            AssblValue = AssessableValue == 0 ? 100 : AssessableValue;
            DataTable myTable = DutyTable;
            int rowCount = myTable.Rows.Count;

            StringBuilder sb = new StringBuilder();

            sb.Append("<script type='text/javascript' language='javascript'>");
            sb.Append("function CalculateDutyAmount(cntr)\n");
            sb.Append("{\n");
            sb.Append(" var assblVal = document.getElementById('" + AssblValueClientID + "').value;\n");
            //sb.Append(" var assblVal = " + AssblValue.ToString() + ";\n");
            sb.Append(" var ltmpChangedValue = '" + this.ClientID + "'+'_temp' + cntr;");
            sb.Append(" var tempForm = new Array(" + rowCount.ToString() + ");\n");
            sb.Append(" var tempValues = new Array(" + rowCount.ToString() + ");\n");
            sb.Append(" var tempDutyDesc = new Array(" + rowCount.ToString() + ");\n");
            sb.Append(" var tempDutyAmt = new Array(" + rowCount.ToString() + ");\n");
            sb.Append(" var tempOper = new Array(" + rowCount.ToString() + ");\n");
            //Appended on 4 Aug 2010 to eliminate Tax breakups from Totoal Duty (below one line)
            sb.Append(" var tempTaxType = new Array(" + rowCount.ToString() + ");\n");

            for (int i = 0; i < myTable.Rows.Count; i++)
            {
                sb.Append(" tempForm[" + i.ToString() + "] = '" + myTable.Rows[i]["Formulae"].ToString() + "';\n");

                sb.Append(" tempDutyDesc[" + i.ToString() + "] = '" + myTable.Rows[i]["Duty Description"].ToString().Trim() + "';\n");

                sb.Append(" tempOper[" + i.ToString() + "] = '" + myTable.Rows[i]["Operator"].ToString() + "';\n");

                sb.Append(" tempDutyAmt[" + i.ToString() + "] = document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount" + i.ToString() + "2').value;\n");

                //Appended on 4 Aug 2010 to eliminate Tax breakups from Totoal Duty (below one line)
                //  sb.Append(" tempTaxType[" + i.ToString() + "] = '" + myTable.Rows[i]["Tax_Type"].ToString().Trim() + "';\n");

                sb.Append(" tempValues[" + i.ToString() + "] = tempForm[" + i.ToString() + "].toString().replace('Assbl Value', assblVal);\n");
            }

            sb.Append(" var lll = document.getElementById(ltmpChangedValue).value;\n");
            sb.Append(" var tmp = lll.split('+');\n");
            sb.Append(" var value = 0;\n");
            sb.Append(" for(i = 0; i < tmp.length; i++)\n");
            sb.Append(" { value = value + parseFloat(tmp[i]); }\n");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_temp' + cntr).value = value;\n");

            sb.Append(" if (tmp.Length > 0)  { \n");
            sb.Append(" switch(tempOper[cntr])   {  \n");
            sb.Append(" case '%': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value) * parseFloat(value) / 100;\n");
            sb.Append(" break;\n");
            sb.Append(" case '+': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value.trim()) + parseFloat(value);\n");
            sb.Append(" break;\n");
            sb.Append(" case '-': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(value) - parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value);\n");
            sb.Append(" break;\n");
            sb.Append(" case '/': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(value) / parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value);\n");
            sb.Append(" break;\n");
            sb.Append(" case '*': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(value) * parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value);\n");
            sb.Append(" break;\n");
            sb.Append(" } } \n");
            sb.Append(" else { \n");
            sb.Append(" switch(tempOper[cntr]) { \n ");
            sb.Append(" case '%': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value) * (document.getElementById(ltmpChangedValue).value) / 100;\n");
            sb.Append(" break;\n");
            sb.Append(" case '+': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value) + (document.getElementById(ltmpChangedValue).value);\n");
            sb.Append(" break;\n");
            sb.Append(" case '-': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById(ltmpChangedValue).value) - (document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value);\n");
            sb.Append(" break;\n");
            sb.Append(" case '/': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById(ltmpChangedValue).value) / (document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value);\n");
            sb.Append(" break;\n");
            sb.Append(" case '*': ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = parseFloat(document.getElementById(ltmpChangedValue).value) * (document.getElementById('" + this.ClientID + "'+'_nmtb' + cntr + '1').value);\n");
            sb.Append(" break;\n } \n }");
            //TODO: ROUNDING
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value = Math.round(document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value * 10000) / 10000;\n");
            sb.Append(" tempDutyAmt[cntr] = parseFloat(document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + cntr + '2').value);\n");

            for (int i = 0; i < myTable.Rows.Count; i++)
            {
                sb.Append(" tempValues[" + i.ToString() + "] = tempForm[" + i.ToString() + "].toString().replace('Assbl Value', assblVal);\n");
            }

            sb.Append(" for(i = 0; i < tempForm.length; i++)\n");
            sb.Append(" { \n");
            sb.Append(" tempValues[i] = tempValues[i].toString().replace('Assbl Value', assblVal);\n");
            sb.Append(" for(j = i + 1; j < tempForm.length; j++)\n");
            sb.Append(" { \n");
            sb.Append(" tempValues[j] = tempValues[j].toString().replace(tempDutyDesc[i], tempDutyAmt[i]);\n");
            sb.Append(" }\n  }");

            for (int i = 0; i < myTable.Rows.Count; i++)
            {
                sb.Append(" document.getElementById('" + this.ClientID + "'+'_temp" + i.ToString() + "').value = tempValues[" + i.ToString() + "];\n");
            }

            sb.Append(" for(i = cntr + 1; i < tempForm.length; i++) {\n");
            sb.Append("    CalculateDutyAmount(i);  } ");

            sb.Append(" var totalDutyAmt = 0, totalDutyPer = 0; totalDutyFormulae = '';\n");
            sb.Append(" for(i = 0; i < tempForm.length; i++) {\n");

            //Appended on 4 Aug 2010 to eliminate Tax breakups from Totoal Duty (below one line)
            // sb.Append("if(tempTaxType[i]=='EXD' ||tempTaxType[i]=='CD' || tempTaxType[i]=='SAD' || tempTaxType[i]=='EEC' ||tempTaxType[i]=='EHC' ||tempTaxType[i]=='CEC' ||tempTaxType[i]=='CHC')\n");                            
            sb.Append(" totalDutyAmt = totalDutyAmt + parseFloat(document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + i + '2').value);");
            sb.Append(" if (totalDutyFormulae == '') \n");
            sb.Append(" totalDutyFormulae = document.getElementById('" + this.ClientID + "'+'_nmtb' + i + '1').value; \n");
            sb.Append(" else \n");
            sb.Append(" totalDutyFormulae = totalDutyFormulae + '+' + document.getElementById('" + this.ClientID + "'+'_nmtb' + i + '1').value;\n");
            sb.Append(" } totalDutyPer = totalDutyAmt / assblVal * 100;  ");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbTotalDutyPer').innerText = Math.round(totalDutyPer * 10000) / 10000;");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbTotalDutyAmt').innerText = Math.round(totalDutyAmt * 10000) / 10000;");
            sb.Append(" document.getElementById('" + this.ClientID + "'+'_ntbTotalDutyFormulae').value = totalDutyFormulae;");
            sb.Append(" GetValues(); }");
            sb.Append(" </script>");

            StringBuilder sb1 = new StringBuilder();
            sb1.Append(" <script type='text/javascript' language='javascript'>");
            sb1.Append(" function GetValues() {\n");
            sb1.Append(" var Percent = '', Amount = '', SlNo = '';");
            sb1.Append(" for(i = 0; i < " + myTable.Rows.Count + "; i++)");
            sb1.Append(" {\n");
            sb1.Append(" if (Percent.length == 0)\n");
            sb1.Append(" Percent = document.getElementById('" + this.ClientID + "'+'_nmtb' + i + '1').value;\n");
            sb1.Append(" else\n");
            sb1.Append(" Percent = Percent + ':' + document.getElementById('" + this.ClientID + "'+'_nmtb' + i + '1').value;\n");
            sb1.Append(" if (Amount.length == 0)\n");
            sb1.Append(" Amount = document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + i + '2').value;\n");
            sb1.Append(" else\n");
            sb1.Append(" Amount = Amount + ':' + document.getElementById('" + this.ClientID + "'+'_ntbDutyAmount' + i + '2').value;\n");
            sb1.Append(" if (SlNo.length == 0)\n");
            sb1.Append(" SlNo = document.getElementById('" + this.ClientID + "'+'_tbslno' + i).value;\n");
            sb1.Append(" else\n");
            sb1.Append(" SlNo = SlNo + ':' + document.getElementById('" + this.ClientID + "'+'_tbslno' + i).value;\n");
            sb1.Append(" }\n");
            sb1.Append(" document.getElementById('" + this.ClientID + "'+'_txtDutyPer').value = Percent;\n");
            sb1.Append(" document.getElementById('" + this.ClientID + "'+'_txtDutyAmt').value = Amount;\n");
            sb1.Append(" document.getElementById('" + this.ClientID + "'+'_txtDutySlNo').value = SlNo;\n");

            // sb1.Append("if(isNaN(document.getElementById('" + this.ClientID + "'+'_txtDutyPer').value))\n");
            // sb1.Append("{\n");            
            // sb1.Append(" document.getElementById('" + this.ClientID + "'+'_txtDutyPer').value = '0';\n");
            // sb1.Append("}\n");

            sb1.Append(" }\n");
            sb1.Append(" </script>\n");

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("GetValues"))
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "GetValues", sb1.ToString());

            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("DutyPart"))
                this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "DutyPart", sb.ToString());

            //btnItemDetails.SubmitAttributes("onclick", "CalculateDutyAmount(0);");
        }
    }
}
