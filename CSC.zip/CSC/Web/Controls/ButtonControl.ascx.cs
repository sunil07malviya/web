﻿using System;
using System.Web.UI;

using ISPL.CSC.Model.Masters;

namespace ISPL.CSC.Web.Controls
{
    public partial class ButtonControl : System.Web.UI.UserControl
    {
        private const string MNU_KEY = "MENU";

        public event EventHandler EditButtonClick;
        public event EventHandler DeleteButtonClick;
        public event EventHandler CancelButtonClick;
        public event EventHandler SubmitButtonClick;
        private string _buttonclicked;
        private bool _deleteButtonVisible = true;
        private bool _editButtonVisible = true;
        private bool _submitButtonVisible = true;
        private bool _cancelButtonVisible = true;

        public int MenuID
        {
            get
            {
                if (ViewState[MNU_KEY] == null)
                    return 0;
                else
                    return Convert.ToInt32(ViewState[MNU_KEY]);
            }
            set
            {
                ViewState[MNU_KEY] = value;
            }
        }
        public short TabIndex
        {
            get
            {
                return imgEdit.TabIndex;
            }
            set
            {
                imgEdit.TabIndex = value;
                imgDelete.TabIndex = short.Parse((value + 1).ToString());
                imgSubmit.TabIndex = short.Parse((value + 2).ToString());
                imgCancel.TabIndex = short.Parse((value + 3).ToString());
            }
        }
        public string ButtonClicked
        {
            get { return _buttonclicked; }
            set
            {
                this._buttonclicked = value;
                pFixToolBar(value, MenuID);
            }
        }
        public string Status
        {
            get { return lblStatus.Text; }
            set { this.lblStatus.Text = value; }
        }
        public bool EditButtonVisible
        {
            get { return _editButtonVisible; }
            set { this._editButtonVisible = value; }
        }
        public bool CancelButtonVisible
        {
            get { return _cancelButtonVisible; }
            set { this._cancelButtonVisible = value; }
        }
        public bool DeleteButtonVisible
        {
            get { return _deleteButtonVisible; }
            set { this._deleteButtonVisible = value; }
        }
        public bool SubmitButtonVisible
        {
            get { return _submitButtonVisible; }
            set { this._submitButtonVisible = value; }
        }

        public string CancelOnClientClick
        {
            get { return imgCancel.OnClientClick; }
            set { this.imgCancel.OnClientClick = value; }
        }
        public string UpdProgressClientID
        {
            get
            {
                if (ViewState["UpdProgressClientID"] == null)
                    return string.Empty;
                else
                    return ViewState["UpdProgressClientID"].ToString();
            }
            set
            {
                ViewState["UpdProgressClientID"] = value;
            }
        }
        private void Page_Load(object sender, System.EventArgs e)
        {
            pFixToolBar(ButtonClicked, MenuID);

            imgEdit.Attributes["onclick"] = "javascript:fnHideMenu(true);";
            imgDelete.Attributes["onclick"] = "javascript:fnHideMenu(true);";
            imgSubmit.Attributes["onclick"] = "javascript:fnHideMenu(true);";
            imgCancel.Attributes["onclick"] = "javascript:fnHideMenu(true);";

            //imgSubmit.Attributes.Add("OnClick", "if (Page_ClientValidate()) { document.getElementById('" + UpdProgressClientID + "').style.display='inline'; " + Page.ClientScript.GetPostBackEventReference(imgSubmit, null) + "; }");
            if (!string.IsNullOrEmpty(UpdProgressClientID))
                imgSubmit.Attributes.Add("OnClick", "if (Page_ClientValidate()) { try { document.getElementById('" + UpdProgressClientID + "').style.display='inline'; } catch(e) { }; }");

            //string sScriptPath = "/Web/_assets/js/";

            //string lstrScript = "<script src='" + sScriptPath + "General.js' type='text/javascript' language='javascript'></script>";
            //if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ButtonControlScript"))
            //    this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "ButtonControlScript", lstrScript);
        }
        private void pFixToolBar(string lstrStatus, int lintMenuID)
        {
            ProcessFlow.AccountController accountController = new Web.ProcessFlow.AccountController();

            UserInfo LoginUserInfo = accountController.GetUserInfo(true);
            UserMenuAccessInfo myUserMenuAccessInfo = SQLServerDAL.Masters.UserMenuAccess.GetButtonStatus(LoginUserInfo.BranchID, lintMenuID, LoginUserInfo.UserID);

            imgCancel.Visible = true;
            lblStatus.Text = lstrStatus;

            if (myUserMenuAccessInfo == null && !LoginUserInfo.UserID.ToUpper().Equals("ADMIN"))
            {
                imgEdit.Visible = false;
                imgDelete.Visible = false;
                imgSubmit.Visible = false;
                return;
            }
            switch (lstrStatus)
            {
                case "Add":
                    lblStatus.Text = "Adding details...";
                    imgEdit.Visible = false;
                    imgDelete.Visible = false;
                    imgSubmit.Visible = true;
                    break;

                case "Modify":
                    lblStatus.Text = "Modifying details...";
                    imgEdit.Visible = false;
                    imgDelete.Visible = false;
                    imgSubmit.Visible = true;
                    break;

                case "Edit":
                    lblStatus.Text = "Editing details...";
                    imgSubmit.Visible = false;

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgEdit.Visible = (myUserMenuAccessInfo.EditFlag.Equals("Y") ? true : false);
                    else
                        imgEdit.Visible = true;

                    imgEdit.Visible = (_editButtonVisible ? imgEdit.Visible : false);

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgDelete.Visible = (myUserMenuAccessInfo.DeleteFlag.Equals("Y") ? true : false);
                    else
                        imgDelete.Visible = true;

                    imgDelete.Visible = (_deleteButtonVisible ? imgDelete.Visible : false);
                    break;

                case "Delete":
                    lblStatus.Text = "Are you sure you want to delete details...?";
                    imgSubmit.Visible = true;
                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgSubmit.Visible = (myUserMenuAccessInfo.DeleteFlag.Equals("Y") ? true : false);
                    else
                        imgSubmit.Visible = true;

                    imgEdit.Visible = false;
                    imgDelete.Visible = false;
                    break;

                case "Save":
                    lblStatus.Text = "Are you sure you want to save details...?";
                    imgSubmit.Visible = false;

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgEdit.Visible = (myUserMenuAccessInfo.EditFlag.Equals("Y") ? true : false);
                    else
                        imgEdit.Visible = true;

                    imgEdit.Visible = (_editButtonVisible ? imgEdit.Visible : false);

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgDelete.Visible = (myUserMenuAccessInfo.EditFlag.Equals("Y") ? true : false);
                    else
                        imgDelete.Visible = true;

                    imgDelete.Visible = (_deleteButtonVisible ? imgDelete.Visible : false);
                    break;

                case "Cancel":

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgEdit.Visible = (myUserMenuAccessInfo.EditFlag.Equals("Y") ? true : false);
                    else
                        imgEdit.Visible = true;

                    imgEdit.Visible = (_editButtonVisible ? imgEdit.Visible : false);

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgDelete.Visible = (myUserMenuAccessInfo.DeleteFlag.Equals("Y") ? true : false);
                    else
                        imgDelete.Visible = true;

                    imgDelete.Visible = (_deleteButtonVisible ? imgDelete.Visible : false);

                    imgSubmit.Visible = false;
                    break;

                case "View":
                    lblStatus.Text = "Viewing details...";

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgEdit.Visible = (myUserMenuAccessInfo.EditFlag.Equals("Y") ? true : false);
                    else
                        imgEdit.Visible = true;

                    imgEdit.Visible = (_editButtonVisible ? imgEdit.Visible : false);

                    imgSubmit.Visible = false;

                    if (!LoginUserInfo.UserID.Equals("Admin"))
                        imgDelete.Visible = (myUserMenuAccessInfo.DeleteFlag.Equals("Y") ? true : false);
                    else
                        imgDelete.Visible = true;

                    imgDelete.Visible = (_deleteButtonVisible ? imgDelete.Visible : false);
                    break;
                case "Lock":
                    lblStatus.Text = "Locking the details...";
                    imgEdit.Visible = false;
                    imgDelete.Visible = false;
                    imgSubmit.Visible = false;
                    imgCancel.Visible = true;
                    break;
            }
        }
        protected void OnEditButtonClick(EventArgs e)
        {
            if (EditButtonClick != null)
                EditButtonClick(this, e);
        }
        protected void OnDeleteButtonClick(EventArgs e)
        {
            if (DeleteButtonClick != null)
                DeleteButtonClick(this, e);
        }
        protected void OnCancelButtonClick(EventArgs e)
        {
            if (CancelButtonClick != null)
                CancelButtonClick(this, e);
        }
        protected void OnSubmitButtonClick(EventArgs e)
        {
            if (SubmitButtonClick != null)
                SubmitButtonClick(this, e);
        }
        protected void imgEdit_Click(object sender, ImageClickEventArgs e)
        {
            ButtonClicked = "Modify";
            lblStatus.Text = ButtonClicked;
            pFixToolBar(ButtonClicked, MenuID);
            OnEditButtonClick(e);
        }
        protected void imgDelete_Click(object sender, ImageClickEventArgs e)
        {
            ButtonClicked = "Delete";
            lblStatus.Text = ButtonClicked;
            pFixToolBar(ButtonClicked, MenuID);
            OnDeleteButtonClick(e);
        }
        protected void imgSubmit_Click(object sender, ImageClickEventArgs e)
        {
            OnSubmitButtonClick(e);
        }
        protected void imgCancel_Click(object sender, ImageClickEventArgs e)
        {
            lblStatus.Text = "Cancel";
            OnCancelButtonClick(e);
        }
        public void CancelAttributes(string key, string values)
        {
            imgCancel.Attributes.Add(key, values);
        }
        public void SubmitAttributes(string key, string values)
        {
            imgSubmit.Attributes.Add(key, values);
        }
        public void EditAttributes(string key, string values)
        {
            imgEdit.Attributes.Add(key, values);
        }
        public void DeleteAttributes(string key, string values)
        {
            imgDelete.Attributes.Add(key, values);
        }
        public string SubmitOnClientClick
        {
            set { imgSubmit.OnClientClick = value; }
        }
    }
}