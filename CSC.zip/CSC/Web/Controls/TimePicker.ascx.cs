﻿using System;
using System.Web.UI.WebControls;

namespace ISPL.CSC.Web.Controls
{
    public partial class TimePicker : System.Web.UI.UserControl
    {
        private void Page_Load(object sender, System.EventArgs e)
        {
        }
        public bool ReadOnly
        {
            set
            {
                ddlHour.Enabled = !value;
                ddlMinutes.Enabled = !value;
            }
        }
        public void ClearTime()
        {
            ddlHour.ClearSelection();
            ddlMinutes.ClearSelection();
        }
        public short TabIndex
        {
            get { return ddlHour.TabIndex; }
            set
            {
                ddlHour.TabIndex = value;
                ddlMinutes.TabIndex = short.Parse((value + 1).ToString());
            }
        }
        public string Time
        {
            get
            {
                string lstrTemp = string.Empty;

                if (ddlHour.SelectedValue == "--" || ddlMinutes.SelectedValue == "--")
                    lstrTemp = "00:00";
                else
                    lstrTemp = ddlHour.SelectedValue + ":" + ddlMinutes.SelectedValue;

                return lstrTemp;
            }
            set
            {
                if (value.Equals(DateTime.MinValue.ToString("dd-MMM-yyyy")))
                {
                    ddlHour.ClearSelection();
                    ddlMinutes.ClearSelection();
                }
                else
                {
                    string lstrTemp = value;

                    string[] lstrTokens = lstrTemp.Split(":".ToCharArray());

                    ddlHour.ClearSelection();
                    ddlMinutes.ClearSelection();
                    if (lstrTokens.Length == 2)
                    {
                        ListItem lstHour = ddlHour.Items.FindByValue(lstrTokens[0]);
                        if (lstHour != null)
                            lstHour.Selected = true;

                        ListItem lstMinute = ddlMinutes.Items.FindByValue(lstrTokens[1]);
                        if (lstMinute != null)
                            lstMinute.Selected = true;
                    }
                }
            }
        }
        /*
        public string Time
        {
            get
            {
                string strTemp = string.Empty;

                strTemp = ddlHour.SelectedItem.Value + ":" + ddlMinutes.SelectedItem.Value + " " + ddlAMPM.SelectedItem.Value;

                return strTemp;
            }
            set
            {
                if (value.Equals(DateTime.MinValue.ToString("dd-MMM-yyyy")))
                {
                    ddlHour.SelectedIndex = -1;
                    ddlMinutes.SelectedIndex = -1;
                    ddlAMPM.SelectedIndex = -1;
                }
                else
                {
                    ListItem lstHour = ddlHour.Items.FindByValue(value);
                    if (lstHour != null)
                        lstHour.Selected = true;

                    ListItem lstMinute = ddlMinutes.Items.FindByValue(value);
                    if (lstMinute != null)
                        lstMinute.Selected = true;

                    ListItem lstAMPM = ddlAMPM.Items.FindByValue(value);
                    if (lstAMPM != null)
                        lstAMPM.Selected = true;
                }
            }
        }
        public bool ReadOnly
        {
            set 
            {
                ddlHour.Enabled = !value;
                ddlMinutes.Enabled = !value;
                ddlAMPM.Enabled = !value;
            }
        }
*/
    }
}